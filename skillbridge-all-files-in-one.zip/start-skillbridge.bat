@echo off
title SkillBridge AI - Full Stack Platform
echo ========================================================
echo   Starting SkillBridge AI Multi-Agent Platform
echo ========================================================
cd /d "%~dp0"

REM Use portable Node if present in local tools directory, otherwise use system PATH
if exist "%USERPROFILE%\.gemini\antigravity\scratch\tools\node-v20.18.0-win-x64\node.exe" (
    set "PATH=%USERPROFILE%\.gemini\antigravity\scratch\tools\node-v20.18.0-win-x64;%PATH%"
)

echo Starting server on http://localhost:5000 ...
start "" http://localhost:5000
node server/index.js
pause
