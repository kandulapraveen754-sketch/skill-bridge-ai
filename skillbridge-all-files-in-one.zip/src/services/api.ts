const API_BASE = '/api';

export async function fetchJson(endpoint: string, options: RequestInit = {}) {
  try {
    const res = await fetch(`${API_BASE}${endpoint}`, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...(options.headers || {})
      }
    });

    if (!res.ok) {
      const errorText = await res.text();
      let errObj;
      try {
        errObj = JSON.parse(errorText);
      } catch (e) {
        errObj = { error: errorText || `HTTP ${res.status}` };
      }
      throw new Error(errObj.error || `HTTP ${res.status}`);
    }

    return await res.json();
  } catch (err: any) {
    console.error(`API Call failed: ${endpoint}`, err);
    throw err;
  }
}

// System
export const getHealth = () => fetchJson('/health');

// Auth
export const apiLogin = (email?: string, password?: string) =>
  fetchJson('/auth/login', {
    method: 'POST',
    body: JSON.stringify({ email, password })
  });

export const apiRegister = (userData: any) =>
  fetchJson('/auth/register', {
    method: 'POST',
    body: JSON.stringify(userData)
  });

// Student & Readiness
export const getStudentProfile = (studentId = 'std-alex-chen') =>
  fetchJson(`/student/profile?studentId=${encodeURIComponent(studentId)}`);

export const updateStudentProfile = (profileData: any) =>
  fetchJson('/student/profile', {
    method: 'PUT',
    body: JSON.stringify(profileData)
  });

export const getReadinessScore = (studentId = 'std-alex-chen') =>
  fetchJson(`/student/readiness?studentId=${encodeURIComponent(studentId)}`);

export const completeMission = (missionId: string, studentId = 'std-alex-chen') =>
  fetchJson('/student/missions/complete', {
    method: 'POST',
    body: JSON.stringify({ missionId, studentId })
  });

// Careers Catalog
export const getCareers = () => fetchJson('/careers');

// Agent 1: Skill Gap Detector
export const analyzeSkillGap = (studentId = 'std-alex-chen', targetCareerId?: string) =>
  fetchJson('/agents/skill-gap/analyze', {
    method: 'POST',
    body: JSON.stringify({ studentId, targetCareerId })
  });

// Agent 2: Personalized Learning Agent
export const getPersonalizedRoadmap = (studentId = 'std-alex-chen', targetCareerId?: string) =>
  fetchJson('/agents/learning/roadmap', {
    method: 'POST',
    body: JSON.stringify({ studentId, targetCareerId })
  });

export const explainConcept = (topic: string, difficulty = 'Beginner', context = '') =>
  fetchJson('/agents/learning/explain', {
    method: 'POST',
    body: JSON.stringify({ topic, difficulty, context })
  });

export const toggleLessonCompletion = (lessonId: string, studentId = 'std-alex-chen') =>
  fetchJson('/agents/learning/complete-lesson', {
    method: 'POST',
    body: JSON.stringify({ lessonId, studentId })
  });

export const triggerWeaknessRecovery = (weakTopic: string, studentId = 'std-alex-chen', failedQuestionDetails?: any) =>
  fetchJson('/agents/learning/weakness-recovery', {
    method: 'POST',
    body: JSON.stringify({ weakTopic, studentId, failedQuestionDetails })
  });

// Agent 3: Skill Verification Agent
export const getQuiz = (skillName: string, difficulty = 'Intermediate') =>
  fetchJson(`/agents/verification/quiz?skillName=${encodeURIComponent(skillName)}&difficulty=${encodeURIComponent(difficulty)}`);

export const submitQuiz = (payload: { skillName: string; answers: Record<string, number>; quiz: any; studentId?: string }) =>
  fetchJson('/agents/verification/submit', {
    method: 'POST',
    body: JSON.stringify(payload)
  });

// Agent 4: Opportunity Finder Agent
export const getOpportunities = (filters: {
  category?: string;
  isRemote?: boolean;
  isBeginnerFriendly?: boolean;
  search?: string;
  studentId?: string;
} = {}) => {
  const params = new URLSearchParams();
  if (filters.category && filters.category !== 'all') params.append('category', filters.category);
  if (filters.isRemote !== undefined) params.append('isRemote', String(filters.isRemote));
  if (filters.isBeginnerFriendly !== undefined) params.append('isBeginnerFriendly', String(filters.isBeginnerFriendly));
  if (filters.search) params.append('search', filters.search);
  if (filters.studentId) params.append('studentId', filters.studentId);
  return fetchJson(`/agents/opportunities?${params.toString()}`);
};

export const getOpportunitySafetyBridge = (opportunityId: string) =>
  fetchJson(`/agents/opportunities/${encodeURIComponent(opportunityId)}/safety-bridge`);

// Agent 5: Scam Detection Agent
export const analyzeScam = (payload: { text?: string; url?: string; companyName?: string; studentId?: string }) =>
  fetchJson('/agents/scam/analyze', {
    method: 'POST',
    body: JSON.stringify(payload)
  });

export const getScamHistory = (studentId = 'std-alex-chen') =>
  fetchJson(`/agents/scam/history?studentId=${encodeURIComponent(studentId)}`);

// Agent 6: Career Guidance Agent
export const auditResume = (payload: { resumeText: string; targetCareerTitle?: string; studentId?: string }) =>
  fetchJson('/agents/career/resume-audit', {
    method: 'POST',
    body: JSON.stringify(payload)
  });

export const getInterviewQuestions = (payload: { targetCareerTitle?: string; questionType?: string; count?: number }) =>
  fetchJson('/agents/career/interview-questions', {
    method: 'POST',
    body: JSON.stringify(payload)
  });

export const evaluateInterview = (payload: { question: string; studentAnswer: string; targetRole?: string }) =>
  fetchJson('/agents/career/evaluate-interview', {
    method: 'POST',
    body: JSON.stringify(payload)
  });

// Intelligence Hub & Assistant
export const runHubWorkflow = (studentId = 'std-alex-chen', targetCareerId?: string) =>
  fetchJson('/agents/hub/workflow', {
    method: 'POST',
    body: JSON.stringify({ studentId, targetCareerId })
  });

export const sendChatMessage = (payload: { message: string; studentId?: string; conversationHistory?: any[] }) =>
  fetchJson('/agents/assistant/chat', {
    method: 'POST',
    body: JSON.stringify(payload)
  });

export const getAgentActivities = () => fetchJson('/agents/activities');

// Exportable Career Readiness Report
export const getCareerReport = (studentId = 'std-alex-chen') =>
  fetchJson(`/report/career-readiness?studentId=${encodeURIComponent(studentId)}`);
