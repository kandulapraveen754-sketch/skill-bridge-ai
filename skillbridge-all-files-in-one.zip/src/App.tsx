import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { AgentProvider } from './context/AgentContext';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { AgentActivityPanel } from './components/AgentActivityPanel';

// Pages
import { LandingPage } from './pages/LandingPage';
import { LoginPage } from './pages/LoginPage';
import { OnboardingPage } from './pages/OnboardingPage';
import { DashboardPage } from './pages/DashboardPage';
import { IntelligenceHubPage } from './pages/IntelligenceHubPage';
import { SkillGapPage } from './pages/SkillGapPage';
import { LearningCenterPage } from './pages/LearningCenterPage';
import { SkillVerificationPage } from './pages/SkillVerificationPage';
import { OpportunityCenterPage } from './pages/OpportunityCenterPage';
import { SafetyCenterPage } from './pages/SafetyCenterPage';
import { CareerCenterPage } from './pages/CareerCenterPage';
import { ProfilePage } from './pages/ProfilePage';
import { SettingsPage } from './pages/SettingsPage';
import { Menu } from 'lucide-react';

const MainLayout: React.FC = () => {
  const { student, isAuthenticated, login } = useAuth();
  const [currentPage, setCurrentPage] = useState<string>('dashboard');
  const [isActivityPanelOpen, setIsActivityPanelOpen] = useState<boolean>(false);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState<boolean>(false);
  const [safetyCheckPayload, setSafetyCheckPayload] = useState<any>(null);

  const handleQuickDemo = async () => {
    await login('alex.chen@university.edu', 'demo1234');
    setCurrentPage('dashboard');
  };

  const handleOpportunitySafetyCheck = (opp: any) => {
    setSafetyCheckPayload({
      organization: opp.organization,
      url: opp.url,
      payloadText: `Opportunity: ${opp.title}\nCompany: ${opp.organization}\nCompensation: ${opp.stipend}\nURL: ${opp.url}\nDetails: ${opp.description}\nEligibility: ${opp.eligibility}`
    });
    setCurrentPage('safety');
  };

  // If user visits landing, render landing
  if (currentPage === 'landing' || (!isAuthenticated && currentPage === 'landing')) {
    return (
      <LandingPage
        onNavigate={setCurrentPage}
        onQuickDemoLogin={handleQuickDemo}
      />
    );
  }

  // If on login or onboarding pages
  if (currentPage === 'login') {
    return <LoginPage onNavigate={setCurrentPage} />;
  }

  if (currentPage === 'onboarding') {
    return <OnboardingPage onNavigate={setCurrentPage} />;
  }

  return (
    <div className="min-h-screen bg-navy-950 flex flex-col">
      {/* Top Navbar */}
      <Navbar
        currentPage={currentPage}
        onNavigate={setCurrentPage}
        onOpenActivityPanel={() => setIsActivityPanelOpen(true)}
      />

      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar */}
        <Sidebar
          currentPage={currentPage}
          onNavigate={setCurrentPage}
          isOpenMobile={isMobileSidebarOpen}
          onCloseMobile={() => setIsMobileSidebarOpen(false)}
        />

        {/* Mobile floating sidebar toggle */}
        <div className="lg:hidden fixed bottom-4 right-4 z-30">
          <button
            onClick={() => setIsMobileSidebarOpen(true)}
            className="p-3.5 rounded-full bg-brand-600 text-white shadow-glow-blue flex items-center justify-center"
            title="Open Menu"
          >
            <Menu className="w-5 h-5" />
          </button>
        </div>

        {/* Main Content Area */}
        <main className="flex-1 lg:pl-64 overflow-y-auto p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full">
          {currentPage === 'dashboard' && <DashboardPage onNavigate={setCurrentPage} />}
          {currentPage === 'assistant' && <IntelligenceHubPage onNavigate={setCurrentPage} />}
          {currentPage === 'skill-gap' && <SkillGapPage onNavigate={setCurrentPage} />}
          {currentPage === 'learning' && <LearningCenterPage onNavigate={setCurrentPage} />}
          {currentPage === 'verification' && <SkillVerificationPage onNavigate={setCurrentPage} />}
          {currentPage === 'opportunities' && (
            <OpportunityCenterPage
              onNavigate={setCurrentPage}
              onCheckOpportunitySafety={handleOpportunitySafetyCheck}
            />
          )}
          {currentPage === 'safety' && (
            <SafetyCenterPage
              onNavigate={setCurrentPage}
              initialPayload={safetyCheckPayload}
            />
          )}
          {currentPage === 'career' && <CareerCenterPage onNavigate={setCurrentPage} />}
          {currentPage === 'profile' && <ProfilePage onNavigate={setCurrentPage} />}
          {currentPage === 'settings' && <SettingsPage onNavigate={setCurrentPage} />}
        </main>
      </div>

      {/* Global Slide-Over Multi-Agent Activity Panel */}
      <AgentActivityPanel
        isOpen={isActivityPanelOpen}
        onClose={() => setIsActivityPanelOpen(false)}
        onNavigateAgent={setCurrentPage}
      />
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <AgentProvider>
        <MainLayout />
      </AgentProvider>
    </AuthProvider>
  );
}
