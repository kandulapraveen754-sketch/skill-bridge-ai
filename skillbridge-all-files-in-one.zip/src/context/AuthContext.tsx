import React, { createContext, useContext, useState, useEffect } from 'react';
import { Student } from '../types';
import { apiLogin, apiRegister, getStudentProfile, updateStudentProfile } from '../services/api';

interface AuthContextType {
  student: Student | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email?: string, password?: string) => Promise<void>;
  register: (userData: any) => Promise<void>;
  logout: () => void;
  refreshStudent: () => Promise<void>;
  updateProfile: (data: Partial<Student>) => Promise<void>;
  isDemoAccount: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [student, setStudent] = useState<Student | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);

  useEffect(() => {
    // Auto-login with sample demo student on initial load for frictionless evaluation
    const savedToken = localStorage.getItem('skb_token');
    const savedStudentId = localStorage.getItem('skb_student_id') || 'std-alex-chen';

    getStudentProfile(savedStudentId)
      .then(res => {
        if (res.student) {
          setStudent(res.student);
          setIsAuthenticated(true);
        }
      })
      .catch(err => {
        console.warn('Initial session fetch failed:', err);
      })
      .finally(() => {
        setIsLoading(false);
      });
  }, []);

  const login = async (email?: string, password?: string) => {
    setIsLoading(true);
    try {
      const res = await apiLogin(email, password);
      if (res.student) {
        setStudent(res.student);
        setIsAuthenticated(true);
        localStorage.setItem('skb_token', res.token);
        localStorage.setItem('skb_student_id', res.student.id);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (userData: any) => {
    setIsLoading(true);
    try {
      const res = await apiRegister(userData);
      if (res.student) {
        setStudent(res.student);
        setIsAuthenticated(true);
        localStorage.setItem('skb_token', res.token);
        localStorage.setItem('skb_student_id', res.student.id);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    localStorage.removeItem('skb_token');
    setStudent(null);
    setIsAuthenticated(false);
  };

  const refreshStudent = async () => {
    if (!student) return;
    try {
      const res = await getStudentProfile(student.id);
      if (res.student) {
        setStudent(res.student);
      }
    } catch (err) {
      console.error('Failed to refresh student profile:', err);
    }
  };

  const updateProfile = async (data: Partial<Student>) => {
    if (!student) return;
    try {
      const res = await updateStudentProfile({ ...student, ...data });
      if (res.student) {
        setStudent(res.student);
      }
    } catch (err) {
      console.error('Failed to update student profile:', err);
      throw err;
    }
  };

  const isDemoAccount = student?.id === 'std-alex-chen';

  return (
    <AuthContext.Provider
      value={{
        student,
        isAuthenticated,
        isLoading,
        login,
        register,
        logout,
        refreshStudent,
        updateProfile,
        isDemoAccount
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
