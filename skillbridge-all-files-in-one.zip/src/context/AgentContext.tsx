import React, { createContext, useContext, useState, useEffect } from 'react';
import { AgentActivity } from '../types';
import { getAgentActivities } from '../services/api';

interface AgentContextType {
  activities: AgentActivity[];
  activeAgent: string | null;
  setActiveAgent: (agent: string | null) => void;
  refreshActivities: () => Promise<void>;
  addLocalActivity: (activity: Omit<AgentActivity, 'id' | 'timestamp'>) => void;
  isAiDemoMode: boolean;
  setIsAiDemoMode: (val: boolean) => void;
}

const AgentContext = createContext<AgentContextType | undefined>(undefined);

export const AgentProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activities, setActivities] = useState<AgentActivity[]>([]);
  const [activeAgent, setActiveAgent] = useState<string | null>(null);
  const [isAiDemoMode, setIsAiDemoMode] = useState<boolean>(true);

  const refreshActivities = async () => {
    try {
      const res = await getAgentActivities();
      if (res.activities) {
        setActivities(res.activities);
      }
    } catch (err) {
      console.warn('Failed to load agent activities:', err);
    }
  };

  useEffect(() => {
    refreshActivities();
    const interval = setInterval(refreshActivities, 10000); // 10s auto-poll
    return () => clearInterval(interval);
  }, []);

  const addLocalActivity = (activity: Omit<AgentActivity, 'id' | 'timestamp'>) => {
    const newEntry: AgentActivity = {
      id: `act-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      timestamp: new Date().toISOString(),
      ...activity
    };
    setActivities(prev => [newEntry, ...prev.slice(0, 49)]);
  };

  return (
    <AgentContext.Provider
      value={{
        activities,
        activeAgent,
        setActiveAgent,
        refreshActivities,
        addLocalActivity,
        isAiDemoMode,
        setIsAiDemoMode
      }}
    >
      {children}
    </AgentContext.Provider>
  );
};

export const useAgent = () => {
  const context = useContext(AgentContext);
  if (!context) {
    throw new Error('useAgent must be used within an AgentProvider');
  }
  return context;
};
