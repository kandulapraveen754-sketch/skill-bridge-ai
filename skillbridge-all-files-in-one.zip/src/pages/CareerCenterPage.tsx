import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useAgent } from '../context/AgentContext';
import { auditResume, getInterviewQuestions, evaluateInterview } from '../services/api';
import { ResumeAudit } from '../types';
import { 
  Compass, 
  FileText, 
  MessageSquare, 
  Sparkles, 
  CheckCircle2, 
  AlertCircle, 
  ArrowRight, 
  Send,
  Award,
  RefreshCw,
  Code2
} from 'lucide-react';

interface CareerCenterPageProps {
  onNavigate: (page: string) => void;
}

export const CareerCenterPage: React.FC<CareerCenterPageProps> = ({ onNavigate }) => {
  const { student } = useAuth();
  const { setActiveAgent } = useAgent();

  const [activeTab, setActiveTab] = useState<'resume' | 'interview'>('resume');

  // Resume State
  const [resumeText, setResumeText] = useState<string>(
    `Alex Chen | alex.chen@university.edu | github.com/alexchen-dev
EDUCATION:
B.Tech in Computer Science & Engineering - State Institute of Technology (2023 - 2027)

PROJECTS:
- Emotion Detection Model: Worked on an AI model to detect emotions in text messages using Python and machine learning algorithms.
- Student Portal: Built a website for student course management using React and Node.js. Handled login and course enrollments.
- Database Optimizer: Helped optimize database queries in team project.

SKILLS:
Python, JavaScript, React, Git, Linux, SQL, Data Structures.`
  );
  const [resumeAuditReport, setResumeAuditReport] = useState<ResumeAudit | null>(null);
  const [auditing, setAuditing] = useState<boolean>(false);

  // Interview State
  const [interviewType, setInterviewType] = useState<'technical' | 'behavioral'>('technical');
  const [interviewQuestions, setInterviewQuestions] = useState<any[]>([]);
  const [activeQuestionIdx, setActiveQuestionIdx] = useState<number>(0);
  const [studentAnswer, setStudentAnswer] = useState<string>('');
  const [interviewEvaluation, setInterviewEvaluation] = useState<any>(null);
  const [evaluating, setEvaluating] = useState<boolean>(false);
  const [loadingQuestions, setLoadingQuestions] = useState<boolean>(false);

  useEffect(() => {
    setActiveAgent('Career Guidance Agent (Agent 6)');
    loadInterviewQuestions('technical');
  }, [student, setActiveAgent]);

  const handleAuditResume = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!resumeText.trim()) return;
    setAuditing(true);
    try {
      const res = await auditResume({
        resumeText,
        targetCareerTitle: student?.targetCareerTitle || 'Software Engineer',
        studentId: student?.id
      });
      if (res.audit) setResumeAuditReport(res.audit);
    } finally {
      setAuditing(false);
    }
  };

  const loadInterviewQuestions = async (type: 'technical' | 'behavioral') => {
    setLoadingQuestions(true);
    setInterviewEvaluation(null);
    setStudentAnswer('');
    try {
      const res = await getInterviewQuestions({
        targetCareerTitle: student?.targetCareerTitle || 'AI / Machine Learning Engineer',
        questionType: type,
        count: 2
      });
      if (res.questions) {
        setInterviewQuestions(res.questions);
        setActiveQuestionIdx(0);
      }
    } finally {
      setLoadingQuestions(false);
    }
  };

  const handleEvaluateAnswer = async (e: React.FormEvent) => {
    e.preventDefault();
    const currentQ = interviewQuestions[activeQuestionIdx];
    if (!currentQ || !studentAnswer.trim()) return;

    setEvaluating(true);
    try {
      const res = await evaluateInterview({
        question: currentQ.question,
        studentAnswer,
        targetRole: student?.targetCareerTitle
      });
      if (res.feedback) {
        setInterviewEvaluation(res.feedback);
      }
    } finally {
      setEvaluating(false);
    }
  };

  const currentQ = interviewQuestions[activeQuestionIdx];

  return (
    <div className="space-y-6 sm:space-y-8 animate-fadeIn">
      {/* Header */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-cyan-950/80 via-slate-900 to-navy-900 border border-cyan-500/30 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
              Agent 6 • Career & Interview Prep
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight mt-1 flex items-center space-x-3">
            <Compass className="w-7 h-7 text-cyan-400" />
            <span>Career Guidance Center</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 max-w-xl mt-1">
            ATS resume audits with metric-driven bullet rewrites and AI mock interviews with STAR feedback.
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex space-x-2 bg-slate-900 p-1.5 rounded-2xl border border-slate-800">
          <button
            onClick={() => setActiveTab('resume')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 ${
              activeTab === 'resume'
                ? 'bg-cyan-600 text-white shadow-glow-blue'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Resume ATS Scanner</span>
          </button>
          <button
            onClick={() => setActiveTab('interview')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 ${
              activeTab === 'interview'
                ? 'bg-cyan-600 text-white shadow-glow-blue'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>Mock Interview Practice</span>
          </button>
        </div>
      </div>

      {/* TAB 1: RESUME AUDITOR */}
      {activeTab === 'resume' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 animate-fadeIn">
          {/* Input Column (Col 5) */}
          <div className="lg:col-span-5 space-y-4">
            <div className="p-6 rounded-2xl glass-panel border border-slate-800 space-y-4">
              <h3 className="font-bold text-sm text-white">Paste Resume Text</h3>
              <p className="text-xs text-slate-400">
                Agent 6 audits your resume against ATS algorithms and target role requirements.
              </p>

              <form onSubmit={handleAuditResume} className="space-y-4">
                <textarea
                  rows={14}
                  value={resumeText}
                  onChange={e => setResumeText(e.target.value)}
                  placeholder="Paste your plain text resume here..."
                  className="w-full p-3 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white font-mono placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                />

                <button
                  type="submit"
                  disabled={auditing}
                  className="w-full py-3 rounded-xl text-xs font-bold bg-cyan-600 hover:bg-cyan-500 text-white transition-colors flex items-center justify-center space-x-2"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>{auditing ? 'Auditing Resume against ATS...' : 'Run ATS Audit & Bullet Rewrites'}</span>
                </button>
              </form>
            </div>
          </div>

          {/* Results Column (Col 7) */}
          <div className="lg:col-span-7 space-y-4">
            {resumeAuditReport ? (
              <div className="p-6 rounded-2xl glass-panel border border-slate-800 space-y-5 animate-fadeIn">
                {/* Score Banner */}
                <div className="flex items-center justify-between pb-4 border-b border-slate-800">
                  <div>
                    <span className="text-xs font-semibold text-slate-400">ATS Keyword & Metric Score</span>
                    <div className="text-4xl font-black text-white mt-0.5">
                      {resumeAuditReport.overallScore} <span className="text-sm font-normal text-slate-500">/ 100</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className={`px-2.5 py-1 rounded text-xs font-bold ${
                      resumeAuditReport.overallScore >= 80 ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' :
                      resumeAuditReport.overallScore >= 60 ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' :
                      'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                    }`}>
                      {resumeAuditReport.overallScore >= 80 ? 'ATS Optimized' : 'Needs Quantified Impact'}
                    </span>
                  </div>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed bg-slate-900/60 p-3.5 rounded-xl border border-slate-800">
                  {resumeAuditReport.atsSummary}
                </p>

                {/* Keyword Match Tags */}
                {resumeAuditReport.keywordAnalysis && (
                  <div className="space-y-2">
                    <div className="text-xs font-bold text-slate-300">
                      Target Job Keywords Checked:
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {resumeAuditReport.keywordAnalysis.keywords.map(kw => (
                        <span
                          key={kw.keyword}
                          className={`px-2.5 py-1 rounded text-xs font-medium border flex items-center space-x-1 ${
                            kw.present 
                              ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30' 
                              : 'bg-slate-800/80 text-slate-400 border-slate-700'
                          }`}
                        >
                          <span>{kw.present ? '✓' : '✗'}</span>
                          <span>{kw.keyword}</span>
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Missing Sections */}
                {resumeAuditReport.missingSections && resumeAuditReport.missingSections.length > 0 && (
                  <div className="p-3.5 rounded-xl bg-amber-950/20 border border-amber-500/30 text-xs space-y-1.5">
                    <div className="font-bold text-amber-300 flex items-center space-x-1.5">
                      <AlertCircle className="w-3.5 h-3.5" />
                      <span>Missing Critical Sections:</span>
                    </div>
                    <ul className="list-disc list-inside text-slate-300 space-y-1 text-[11px]">
                      {resumeAuditReport.missingSections.map((sec, idx) => (
                        <li key={idx}>{sec}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Before and After Bullet Rewrites */}
                <div className="space-y-3 pt-2">
                  <h4 className="font-bold text-xs uppercase tracking-wider text-slate-300">
                    High-Impact Metric Rewrites (X-Y-Z Formula)
                  </h4>
                  <div className="space-y-3">
                    {(resumeAuditReport.bulletRewrites || []).map((rw, idx) => (
                      <div key={idx} className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2 text-xs">
                        <div className="text-rose-400">
                          <strong className="text-[10px] uppercase font-bold text-slate-500 block">Before (Weak):</strong>
                          <span className="line-through">{rw.before}</span>
                        </div>
                        <div className="text-emerald-300 font-medium">
                          <strong className="text-[10px] uppercase font-bold text-emerald-500 block">After (High-Impact):</strong>
                          <span>{rw.after}</span>
                        </div>
                        <div className="text-[10px] text-slate-400 font-mono pt-1">
                          💡 {rw.critique}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-16 text-center text-slate-400 text-xs glass-panel rounded-2xl flex flex-col items-center justify-center space-y-2">
                <FileText className="w-10 h-10 text-slate-600" />
                <div>Click <strong>Run ATS Audit & Bullet Rewrites</strong> to analyze the sample resume above.</div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 2: MOCK INTERVIEW SIMULATOR */}
      {activeTab === 'interview' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 animate-fadeIn">
          {/* Question & Practice Column (Col 7) */}
          <div className="lg:col-span-7 space-y-4">
            <div className="p-6 rounded-2xl glass-panel border border-slate-800 space-y-5">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center space-x-2">
                  <span className="text-xs font-bold text-cyan-400">Mock Interview Room</span>
                </div>
                <div className="flex space-x-2">
                  <button
                    onClick={() => {
                      setInterviewType('technical');
                      loadInterviewQuestions('technical');
                    }}
                    className={`px-3 py-1 rounded-lg text-xs font-semibold ${
                      interviewType === 'technical' ? 'bg-cyan-600 text-white' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Technical
                  </button>
                  <button
                    onClick={() => {
                      setInterviewType('behavioral');
                      loadInterviewQuestions('behavioral');
                    }}
                    className={`px-3 py-1 rounded-lg text-xs font-semibold ${
                      interviewType === 'behavioral' ? 'bg-cyan-600 text-white' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Behavioral (STAR)
                  </button>
                </div>
              </div>

              {loadingQuestions ? (
                <div className="py-12 text-center text-slate-400 text-xs">Preparing realistic questions...</div>
              ) : currentQ ? (
                <div className="space-y-4">
                  {/* Current Question */}
                  <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
                    <div className="text-[10px] font-bold uppercase tracking-wider text-cyan-400">
                      Question {activeQuestionIdx + 1} of {interviewQuestions.length} ({interviewType}):
                    </div>
                    <div className="text-sm font-semibold text-white leading-relaxed">
                      {currentQ.question}
                    </div>
                    <div className="text-[11px] text-slate-400 pt-1">
                      <strong className="text-slate-300">Interviewer is evaluating: </strong>
                      {currentQ.evaluating}
                    </div>
                  </div>

                  {/* Student Answer Box */}
                  <form onSubmit={handleEvaluateAnswer} className="space-y-3">
                    <label className="block text-xs font-semibold text-slate-300">
                      Your Response:
                    </label>
                    <textarea
                      rows={6}
                      value={studentAnswer}
                      onChange={e => setStudentAnswer(e.target.value)}
                      placeholder="Type your interview answer here. For behavioral questions, structure by Situation -> Task -> Action -> Result..."
                      className="w-full p-3.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                    />

                    <div className="flex items-center justify-between">
                      <div className="flex space-x-2">
                        {interviewQuestions.map((_, idx) => (
                          <button
                            key={idx}
                            type="button"
                            onClick={() => {
                              setActiveQuestionIdx(idx);
                              setInterviewEvaluation(null);
                            }}
                            className={`w-7 h-7 rounded-lg text-xs font-bold ${
                              activeQuestionIdx === idx ? 'bg-cyan-600 text-white' : 'bg-slate-800 text-slate-400'
                            }`}
                          >
                            Q{idx + 1}
                          </button>
                        ))}
                      </div>

                      <button
                        type="submit"
                        disabled={evaluating || !studentAnswer.trim()}
                        className="px-5 py-2.5 rounded-xl text-xs font-bold bg-cyan-600 hover:bg-cyan-500 text-white disabled:opacity-40 transition-colors flex items-center space-x-1.5"
                      >
                        <Send className="w-3.5 h-3.5" />
                        <span>{evaluating ? 'Evaluating Answer...' : 'Submit to AI Interviewer'}</span>
                      </button>
                    </div>
                  </form>
                </div>
              ) : null}
            </div>
          </div>

          {/* Feedback Column (Col 5) */}
          <div className="lg:col-span-5 space-y-4">
            {interviewEvaluation ? (
              <div className="p-6 rounded-2xl glass-panel border border-slate-800 space-y-4 animate-fadeIn">
                <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                  <h3 className="font-bold text-sm text-white">AI Evaluation & STAR Rubric</h3>
                  <span className={`px-2.5 py-0.5 rounded text-xs font-bold ${
                    interviewEvaluation.score >= 80 ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-500/20 text-amber-400'
                  }`}>
                    Score: {interviewEvaluation.score}/100
                  </span>
                </div>

                <div className="text-xs font-semibold text-slate-300">
                  Verdict: <span className="text-cyan-300">{interviewEvaluation.verdict}</span>
                </div>

                {/* Strengths */}
                <div className="space-y-1">
                  <div className="text-[11px] font-bold text-emerald-400">Strengths:</div>
                  <ul className="list-disc list-inside text-xs text-slate-300 space-y-0.5">
                    {(interviewEvaluation.strengths || []).map((s: string, idx: number) => (
                      <li key={idx}>{s}</li>
                    ))}
                  </ul>
                </div>

                {/* Improvements */}
                <div className="space-y-1">
                  <div className="text-[11px] font-bold text-amber-400">Areas for Growth:</div>
                  <ul className="list-disc list-inside text-xs text-slate-300 space-y-0.5">
                    {(interviewEvaluation.areasForImprovement || []).map((a: string, idx: number) => (
                      <li key={idx}>{a}</li>
                    ))}
                  </ul>
                </div>

                {/* Exemplary Model Answer */}
                {interviewEvaluation.modelAnswer && (
                  <div className="p-3.5 rounded-xl bg-slate-950 text-xs text-slate-300 border border-slate-800 space-y-1">
                    <div className="text-[10px] font-bold uppercase tracking-wider text-cyan-400">
                      Exemplary Senior Candidate Answer:
                    </div>
                    <p className="text-[11px] text-slate-300 italic leading-relaxed">
                      "{interviewEvaluation.modelAnswer}"
                    </p>
                  </div>
                )}
              </div>
            ) : (
              <div className="p-12 text-center text-slate-400 text-xs glass-panel rounded-2xl flex flex-col items-center justify-center space-y-2">
                <MessageSquare className="w-10 h-10 text-slate-600" />
                <div>Type and submit an answer on the left to receive constructive STAR evaluation and ideal sample answers.</div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
