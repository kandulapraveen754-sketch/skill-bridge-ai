import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { useAgent } from '../context/AgentContext';
import { sendChatMessage, runHubWorkflow } from '../services/api';
import { ChatMessage } from '../types';
import { 
  Bot, 
  Send, 
  Sparkles, 
  Layers, 
  ArrowRight, 
  Activity, 
  ShieldAlert, 
  CheckCircle2, 
  GraduationCap, 
  Radar, 
  Briefcase,
  Play,
  RotateCcw
} from 'lucide-react';

interface IntelligenceHubPageProps {
  onNavigate: (page: string) => void;
}

export const IntelligenceHubPage: React.FC<IntelligenceHubPageProps> = ({ onNavigate }) => {
  const { student } = useAuth();
  const { setActiveAgent, addLocalActivity } = useAgent();

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome-1',
      sender: 'assistant',
      text: `Hello ${student?.name || 'there'}! I am **SkillBridge Assistant**, your central AI coordinator.\n\nI can coordinate across all six specialized agents:\n- **Skill Gap Detector** (analyze missing skills)\n- **Learning Agent** (create customized roadmaps)\n- **Verification Agent** (run skill quizzes)\n- **Opportunity Finder** (match internships)\n- **Scam Detector** (verify suspicious offers)\n- **Career Guidance** (audit resumes & mock interviews)\n\nWhat career goal or question are we tackling today?`,
      routedAgent: 'SkillBridge Intelligence Hub',
      timestamp: new Date().toISOString()
    }
  ]);

  const [inputMessage, setInputMessage] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [workflowRunning, setWorkflowRunning] = useState(false);
  const [workflowResult, setWorkflowResult] = useState<any>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setActiveAgent('SkillBridge Intelligence Hub');
  }, [setActiveAgent]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = async (textToSend?: string) => {
    const text = textToSend || inputMessage;
    if (!text.trim() || isSending) return;

    const userMsg: ChatMessage = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      text,
      timestamp: new Date().toISOString()
    };

    setMessages(prev => [...prev, userMsg]);
    setInputMessage('');
    setIsSending(true);

    try {
      const res = await sendChatMessage({
        message: text,
        studentId: student?.id,
        conversationHistory: messages
      });

      if (res.reply) {
        setMessages(prev => [...prev, res.reply]);
        addLocalActivity({
          agent: res.reply.routedAgent || 'SkillBridge Assistant',
          action: 'Conversational Query Handled',
          status: 'success',
          summary: `Synthesized guidance for: "${text.substring(0, 35)}..."`
        });
      }
    } catch (err: any) {
      setMessages(prev => [
        ...prev,
        {
          id: `err-${Date.now()}`,
          sender: 'assistant',
          text: `I encountered an error coordinating agents: ${err.message}. Please try again.`,
          timestamp: new Date().toISOString()
        }
      ]);
    } finally {
      setIsSending(false);
    }
  };

  const handleRunFullWorkflow = async () => {
    setWorkflowRunning(true);
    setWorkflowResult(null);
    try {
      const res = await runHubWorkflow(student?.id, student?.targetCareerId);
      if (res.result) {
        setWorkflowResult(res.result);
        setMessages(prev => [
          ...prev,
          {
            id: `wf-${Date.now()}`,
            sender: 'assistant',
            text: `🎯 **End-to-End Career Launchpad Workflow Completed!**\n\nI coordinated **Agent 1** (Skill Gap) → **Agent 2** (Roadmap) → **Agent 4** (Opportunities) → **Agent 6** (Career Guidance).\n\n- Readiness Match: **${res.result.consolidatedInsights.readinessMatch}%**\n- Priority Learning Focus: **${res.result.consolidatedInsights.priorityFocus.join(', ')}**\n- First Lesson: **${res.result.consolidatedInsights.firstLessonToStart}**`,
            routedAgent: 'SkillBridge Intelligence Hub',
            timestamp: new Date().toISOString()
          }
        ]);
      }
    } finally {
      setWorkflowRunning(false);
    }
  };

  const samplePrompts = [
    "I want to become an AI Engineer, where should I start?",
    "Is an internship asking for ₹2,500 deposit legit?",
    "Test my Python skills with a quick quiz",
    "Find beginner-friendly remote internships"
  ];

  return (
    <div className="space-y-6 sm:space-y-8 animate-fadeIn">
      {/* Header */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-brand-950 via-slate-900 to-navy-900 border border-brand-500/30 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-brand-500/20 text-brand-300 border border-brand-500/30">
              Intelligence Hub & Coordinator
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight mt-1 flex items-center space-x-3">
            <Bot className="w-7 h-7 text-brand-400" />
            <span>SkillBridge Assistant</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 max-w-xl mt-1">
            Natural conversational guide that automatically delegates tasks to the 6 specialized AI agents.
          </p>
        </div>

        {/* Master Workflow Button */}
        <button
          onClick={handleRunFullWorkflow}
          disabled={workflowRunning}
          className="px-4 py-2.5 rounded-xl text-xs font-bold bg-gradient-to-r from-brand-600 via-blue-600 to-purple-600 hover:from-brand-500 hover:to-purple-500 text-white shadow-glow-blue transition-all flex items-center space-x-2"
        >
          <Play className="w-3.5 h-3.5 fill-white" />
          <span>{workflowRunning ? 'Orchestrating 6 Agents...' : 'Run Full Launchpad Workflow'}</span>
        </button>
      </div>

      {/* Multi-Agent Workflow Visualizer (if triggered) */}
      {workflowResult && (
        <div className="p-6 rounded-2xl bg-slate-900 border border-brand-500/40 space-y-4 animate-fadeIn">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <div className="text-xs font-bold text-brand-300 flex items-center space-x-2">
              <Layers className="w-4 h-4 text-brand-400" />
              <span>Multi-Agent Execution Pipeline Output</span>
            </div>
            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              ALL STEPS SUCCESSFUL
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {workflowResult.steps.map((st: any, idx: number) => (
              <div key={idx} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5 text-xs">
                <div className="flex items-center justify-between text-[10px] text-slate-400">
                  <span className="font-bold text-brand-400">Step {idx + 1}</span>
                  <span className="text-emerald-400 font-semibold">✓ Completed</span>
                </div>
                <div className="font-bold text-white text-[11px]">{st.agent}</div>
                <div className="text-[10px] text-slate-400">{st.task}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Conversational Assistant Window */}
      <div className="p-6 rounded-2xl glass-panel border border-slate-800 flex flex-col h-[600px]">
        {/* Messages Stream */}
        <div className="flex-1 overflow-y-auto space-y-4 pr-2">
          {messages.map(msg => {
            const isUser = msg.sender === 'user';
            return (
              <div 
                key={msg.id} 
                className={`flex items-start space-x-3 ${isUser ? 'justify-end' : 'justify-start'}`}
              >
                {!isUser && (
                  <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-brand-600 to-purple-600 flex items-center justify-center text-white shrink-0 shadow-sm mt-0.5">
                    <Bot className="w-4 h-4" />
                  </div>
                )}

                <div className={`max-w-2xl rounded-2xl p-4 text-xs space-y-2 leading-relaxed ${
                  isUser 
                    ? 'bg-brand-600 text-white rounded-tr-none' 
                    : 'bg-slate-900 border border-slate-800 text-slate-200 rounded-tl-none'
                }`}>
                  {/* Routed Agent Pill (if assistant message) */}
                  {!isUser && msg.routedAgent && (
                    <div className="flex items-center space-x-1.5 text-[10px] text-brand-400 font-mono pb-1 border-b border-slate-800">
                      <span className="w-1.5 h-1.5 rounded-full bg-brand-400"></span>
                      <span>Delegated to: <strong>{msg.routedAgent}</strong></span>
                    </div>
                  )}

                  <div className="whitespace-pre-line text-xs">
                    {msg.text}
                  </div>

                  <div className="text-[9px] text-slate-500 font-mono text-right">
                    {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </div>
                </div>

                {isUser && (
                  <div className="w-8 h-8 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-white shrink-0 text-xs font-bold mt-0.5">
                    {student?.name?.charAt(0) || 'U'}
                  </div>
                )}
              </div>
            );
          })}

          {isSending && (
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-brand-600 to-purple-600 flex items-center justify-center text-white shrink-0">
                <Bot className="w-4 h-4 animate-spin" />
              </div>
              <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 text-xs text-slate-400 flex items-center space-x-2">
                <span className="w-2 h-2 rounded-full bg-brand-400 animate-ping"></span>
                <span>Coordinating specialized agents and synthesizing response...</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Suggested Prompt Chips */}
        <div className="py-2 flex flex-wrap gap-1.5 border-t border-slate-800/80">
          {samplePrompts.map(prompt => (
            <button
              key={prompt}
              onClick={() => handleSendMessage(prompt)}
              className="px-2.5 py-1 rounded-lg text-[11px] bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 transition-colors"
            >
              💬 {prompt}
            </button>
          ))}
        </div>

        {/* Chat Input Bar */}
        <form onSubmit={e => { e.preventDefault(); handleSendMessage(); }} className="flex gap-2 pt-2">
          <input
            type="text"
            value={inputMessage}
            onChange={e => setInputMessage(e.target.value)}
            placeholder="Ask SkillBridge Assistant anything about skills, roadmaps, quizzes, scams, or career..."
            className="flex-1 px-4 py-3 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-brand-500"
          />

          <button
            type="submit"
            disabled={isSending || !inputMessage.trim()}
            className="px-5 py-3 rounded-xl text-xs font-bold bg-brand-600 hover:bg-brand-500 text-white disabled:opacity-40 shadow-glow-blue transition-colors flex items-center space-x-1.5"
          >
            <span>Send</span>
            <Send className="w-3.5 h-3.5" />
          </button>
        </form>
      </div>
    </div>
  );
};
