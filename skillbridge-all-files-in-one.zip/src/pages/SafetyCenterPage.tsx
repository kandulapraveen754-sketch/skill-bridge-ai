import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useAgent } from '../context/AgentContext';
import { analyzeScam, getScamHistory } from '../services/api';
import { ScamAnalysisReport } from '../types';
import { 
  ShieldAlert, 
  ShieldCheck, 
  AlertTriangle, 
  Search, 
  ExternalLink, 
  Lock, 
  CheckCircle2, 
  XCircle, 
  HelpCircle, 
  Sparkles,
  Info,
  Clock,
  Send
} from 'lucide-react';

interface SafetyCenterPageProps {
  onNavigate: (page: string) => void;
  initialPayload?: any;
}

export const SafetyCenterPage: React.FC<SafetyCenterPageProps> = ({ onNavigate, initialPayload }) => {
  const { student } = useAuth();
  const { setActiveAgent } = useAgent();

  const [inputMode, setInputMode] = useState<'text' | 'url'>('text');
  const [jobText, setJobText] = useState<string>('');
  const [targetUrl, setTargetUrl] = useState<string>('');
  const [companyName, setCompanyName] = useState<string>('');

  const [analyzing, setAnalyzing] = useState<boolean>(false);
  const [analysisReport, setAnalysisReport] = useState<ScamAnalysisReport | null>(null);
  const [history, setHistory] = useState<ScamAnalysisReport[]>([]);

  useEffect(() => {
    setActiveAgent('Scam Detection Agent (Agent 5)');
    if (student) {
      getScamHistory(student.id).then(res => {
        if (res.history) setHistory(res.history);
      });
    }

    if (initialPayload) {
      if (initialPayload.payloadText) setJobText(initialPayload.payloadText);
      if (initialPayload.url) setTargetUrl(initialPayload.url);
      if (initialPayload.organization) setCompanyName(initialPayload.organization);
    }
  }, [student, initialPayload, setActiveAgent]);

  const handleAnalyze = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!jobText.trim() && !targetUrl.trim()) return;

    setAnalyzing(true);
    try {
      const res = await analyzeScam({
        text: jobText,
        url: targetUrl,
        companyName,
        studentId: student?.id
      });

      if (res.report) {
        setAnalysisReport(res.report);
        setHistory(prev => [res.report, ...prev]);
      }
    } finally {
      setAnalyzing(false);
    }
  };

  const handleQuickSampleScam = () => {
    setJobText("Urgent Remote Data Entry & AI Labeler. Earn ₹45,000/month typing documents 2 hours daily. Free brand new laptop provided upon payment of ₹2,500 refundable security deposit. Contact recruiter immediately on Telegram: @hr_fasttrack_agent. Only 2 spots left today!");
    setCompanyName("FastTrack Global Solutions");
    setTargetUrl("https://telegram.me/hr_fasttrack_agent");
  };

  return (
    <div className="space-y-6 sm:space-y-8 animate-fadeIn">
      {/* Header */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-rose-950/80 via-slate-900 to-navy-900 border border-rose-500/30 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-rose-500/20 text-rose-300 border border-rose-500/30">
              Agent 5 • Fraud Shield
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight mt-1 flex items-center space-x-3">
            <ShieldAlert className="w-7 h-7 text-rose-400" />
            <span>Scam Detection Agent</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 max-w-xl mt-1">
            Protect yourself from fake internships, registration fees, phantom training companies, and identity theft.
          </p>
        </div>

        <button
          onClick={handleQuickSampleScam}
          className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-rose-600/30 hover:bg-rose-600/50 text-rose-200 border border-rose-500/40 transition-colors flex items-center space-x-1.5"
        >
          <AlertTriangle className="w-3.5 h-3.5" />
          <span>Load Known Scam Specimen</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Input Form (Col 6) */}
        <div className="lg:col-span-6 space-y-4">
          <div className="p-6 rounded-2xl glass-panel border border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-sm text-white">Analyze Opportunity or Message</h3>
              <div className="flex space-x-1.5 bg-slate-900 p-1 rounded-xl border border-slate-800 text-xs">
                <button
                  type="button"
                  onClick={() => setInputMode('text')}
                  className={`px-3 py-1 rounded-lg font-medium transition-all ${
                    inputMode === 'text' ? 'bg-rose-600 text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Text / Message
                </button>
                <button
                  type="button"
                  onClick={() => setInputMode('url')}
                  className={`px-3 py-1 rounded-lg font-medium transition-all ${
                    inputMode === 'url' ? 'bg-rose-600 text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  URL Only
                </button>
              </div>
            </div>

            <form onSubmit={handleAnalyze} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 pb-1">
                  Company / Organization Name (Optional)
                </label>
                <input
                  type="text"
                  value={companyName}
                  onChange={e => setCompanyName(e.target.value)}
                  placeholder="e.g. Acme Tech Solutions Ltd"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 pb-1">
                  Posting or Recruiter Message Text
                </label>
                <textarea
                  rows={5}
                  value={jobText}
                  onChange={e => setJobText(e.target.value)}
                  placeholder="Paste WhatsApp message, LinkedIn offer, Telegram text, or job description..."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 pb-1">
                  Website / Application Link (Optional)
                </label>
                <input
                  type="text"
                  value={targetUrl}
                  onChange={e => setTargetUrl(e.target.value)}
                  placeholder="https://... (or Telegram link)"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
                />
              </div>

              <button
                type="submit"
                disabled={analyzing}
                className="w-full py-3 rounded-xl text-xs font-bold bg-gradient-to-r from-rose-600 to-pink-600 hover:from-rose-500 hover:to-pink-500 text-white shadow-glow-rose transition-all flex items-center justify-center space-x-2"
              >
                <span>{analyzing ? 'Scanning for Fraud Patterns...' : 'Run Comprehensive Risk Analysis'}</span>
                <ShieldAlert className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>

        {/* Results Column (Col 6) */}
        <div className="lg:col-span-6 space-y-4">
          {analysisReport ? (
            <div className="p-6 rounded-2xl glass-panel border border-slate-800 space-y-5 animate-fadeIn">
              {/* Risk Category Header */}
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center space-x-2">
                  <span className={`px-3 py-1 rounded-full text-xs font-bold border uppercase tracking-wider ${analysisReport.riskBadge}`}>
                    {analysisReport.riskCategory.replace('_', ' ')}
                  </span>
                  <span className="text-xs text-slate-400">Risk Score: {analysisReport.riskScore}/100</span>
                </div>
                <div className="text-[10px] text-slate-500 font-mono">
                  Confidence: {analysisReport.confidencePercentage}%
                </div>
              </div>

              {/* WHY Suspicious Explanation */}
              <div className="space-y-1.5">
                <div className="text-xs font-bold text-slate-200">AI Diagnostic Explanation:</div>
                <p className="text-xs text-slate-300 leading-relaxed bg-slate-900/60 p-3.5 rounded-xl border border-slate-800">
                  {analysisReport.whySuspicious}
                </p>
              </div>

              {/* Detected Red Flags */}
              {analysisReport.detectedRedFlags && analysisReport.detectedRedFlags.length > 0 && (
                <div className="space-y-2">
                  <div className="text-xs font-bold text-rose-400">
                    Detected Red Flags ({analysisReport.detectedRedFlags.length}):
                  </div>
                  <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                    {analysisReport.detectedRedFlags.map((rf, idx) => (
                      <div key={idx} className="p-3 rounded-xl bg-rose-950/20 border border-rose-500/30 text-xs space-y-1">
                        <div className="font-bold text-rose-300 flex items-center space-x-1.5">
                          <AlertTriangle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                          <span>{rf.name}</span>
                        </div>
                        <p className="text-[11px] text-slate-300">{rf.explanation}</p>
                        <div className="text-[10px] text-slate-400 font-mono">
                          Trigger match: [{rf.triggerKeywords?.join(', ')}]
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Actionable Safety Checklist */}
              <div className="space-y-2 pt-2 border-t border-slate-800">
                <div className="text-xs font-bold text-slate-200">Recommended Safety Precautions:</div>
                <ul className="space-y-1.5 text-xs text-slate-300">
                  {(analysisReport.safetyChecklist || []).map((step, idx) => (
                    <li key={idx} className="flex items-start space-x-2">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                      <span>{step}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Ethical Disclaimer */}
              <div className="p-3 rounded-xl bg-slate-950 text-[10px] text-slate-400 border border-slate-800/80 leading-relaxed">
                <strong className="text-slate-300">Notice: </strong>
                {analysisReport.disclaimer}
              </div>
            </div>
          ) : (
            <div className="p-12 text-center text-slate-400 text-xs glass-panel rounded-2xl flex flex-col items-center justify-center space-y-3 min-h-[300px]">
              <ShieldAlert className="w-10 h-10 text-slate-600" />
              <div>Paste a job description or click <strong>Load Known Scam Specimen</strong> above to test Agent 5.</div>
            </div>
          )}
        </div>
      </div>

      {/* History Table */}
      {history.length > 0 && (
        <div className="p-6 rounded-2xl glass-panel border border-slate-800 space-y-4">
          <h3 className="font-bold text-sm text-white">Previous Scan History</h3>
          <div className="space-y-2">
            {history.map(item => (
              <div key={item.id} className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between text-xs">
                <div>
                  <div className="font-semibold text-slate-200 line-clamp-1">
                    {item.companyName || 'Unknown Entity'} • "{item.targetText.substring(0, 40)}..."
                  </div>
                  <div className="text-[10px] text-slate-400 pt-0.5">
                    Scanned: {new Date(item.analyzedAt).toLocaleDateString()}
                  </div>
                </div>

                <div className="flex items-center space-x-3">
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${item.riskBadge}`}>
                    {item.riskCategory} ({item.riskScore}/100)
                  </span>
                  <button
                    onClick={() => setAnalysisReport(item)}
                    className="text-brand-400 hover:underline text-[11px] font-semibold"
                  >
                    View Report
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
