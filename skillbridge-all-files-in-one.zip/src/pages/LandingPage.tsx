import React from 'react';
import { 
  Radar, 
  GraduationCap, 
  CheckCircle2, 
  Briefcase, 
  ShieldAlert, 
  Compass, 
  ArrowRight, 
  Sparkles, 
  ShieldCheck, 
  Bot, 
  Check, 
  Layers, 
  Award,
  Zap
} from 'lucide-react';

interface LandingPageProps {
  onNavigate: (page: string) => void;
  onQuickDemoLogin: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onNavigate, onQuickDemoLogin }) => {
  const agents = [
    {
      num: '01',
      id: 'skill-gap',
      title: 'Skill Gap Detector',
      subtitle: 'Career Differential Analysis',
      icon: Radar,
      color: 'from-blue-500/20 to-blue-600/10 text-blue-400 border-blue-500/30',
      badge: 'Agent 1',
      description: 'Compares your actual knowledge against target career benchmarks. Pinpoints exact missing and weak competencies with high-priority learning order.'
    },
    {
      num: '02',
      id: 'learning',
      title: 'Personalized Learning Agent',
      subtitle: 'Dynamic Roadmaps & Tutoring',
      icon: GraduationCap,
      color: 'from-purple-500/20 to-purple-600/10 text-purple-400 border-purple-500/30',
      badge: 'Agent 2',
      description: 'Generates daily, weekly, and monthly curricula. Explains tough concepts simply, curates free YouTube videos, and includes an interactive Weakness Recovery System.'
    },
    {
      num: '03',
      id: 'verification',
      title: 'Skill Verification Agent',
      subtitle: 'Objective Knowledge Proof',
      icon: CheckCircle2,
      color: 'from-emerald-500/20 to-emerald-600/10 text-emerald-400 border-emerald-500/30',
      badge: 'Agent 3',
      description: 'Evaluates real hands-on ability with timed quizzes, coding tests, and problem-solving. Issues cryptographic SkillBridge verification badges for score >= 80%.'
    },
    {
      num: '04',
      id: 'opportunities',
      title: 'Opportunity Finder Agent',
      subtitle: 'Curated Fellowships & Internships',
      icon: Briefcase,
      color: 'from-amber-500/20 to-amber-600/10 text-amber-400 border-amber-500/30',
      badge: 'Agent 4',
      description: 'Scans genuine internships, hackathons, and scholarships matched directly against your verified profile. Filters for beginner-friendly programs with 1-click safety checks.'
    },
    {
      num: '05',
      id: 'safety',
      title: 'Scam Detection Agent',
      subtitle: 'Student Fraud Protection',
      icon: ShieldAlert,
      color: 'from-rose-500/20 to-rose-600/10 text-rose-400 border-rose-500/30',
      badge: 'Agent 5',
      description: 'Analyzes suspicious job postings, WhatsApp/Telegram messages, and registration fees. Explains WHY an offer is suspicious with clear evidence and verification checklists.'
    },
    {
      num: '06',
      id: 'career',
      title: 'Career Guidance Agent',
      subtitle: 'ATS Resume & Mock Interviews',
      icon: Compass,
      color: 'from-cyan-500/20 to-cyan-600/10 text-cyan-400 border-cyan-500/30',
      badge: 'Agent 6',
      description: 'Audits resumes for ATS keywords, rewrites bullet points with measurable metrics (X-Y-Z formula), and conducts interactive technical & HR mock interviews.'
    }
  ];

  const workflowSteps = [
    { step: '1', title: 'Target Goal', desc: 'Choose your dream career (AI Engineer, Full-Stack, DevOps, etc.)' },
    { step: '2', title: 'Detect Gaps', desc: 'Agent 1 computes your knowledge gap against industry standards' },
    { step: '3', title: 'Learn & Practice', desc: 'Agent 2 builds a personalized roadmap with free top-tier videos' },
    { step: '4', title: 'Prove Skills', desc: 'Agent 3 tests actual proficiency and issues verified badges' },
    { step: '5', title: 'Match & Protect', desc: 'Agent 4 finds internships; Agent 5 shields you from fake fees' },
    { step: '6', title: 'Get Hired', desc: 'Agent 6 optimizes your resume & prepares you for interviews' }
  ];

  return (
    <div className="min-h-screen bg-navy-950 text-slate-100 selection:bg-brand-600 selection:text-white">
      {/* Top Navigation */}
      <nav className="border-b border-slate-800/80 bg-navy-950/80 backdrop-blur-md sticky top-0 z-50 px-6 py-4 flex items-center justify-between max-w-7xl mx-auto">
        <div className="flex items-center space-x-3 cursor-pointer" onClick={() => onNavigate('landing')}>
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-brand-600 via-blue-600 to-purple-600 flex items-center justify-center shadow-glow-blue">
            <svg className="w-6 h-6 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M4 19c4-4 8-4 12 0" />
              <path d="M8 15c2-2 4-2 6 0" />
              <path d="M12 3v8" />
              <circle cx="12" cy="3" r="1.5" fill="currentColor" />
            </svg>
          </div>
          <span className="font-extrabold text-xl tracking-tight text-white">
            SkillBridge<span className="text-brand-400">.AI</span>
          </span>
        </div>

        <div className="hidden md:flex items-center space-x-6 text-xs font-semibold text-slate-300">
          <a href="#agents" className="hover:text-brand-400 transition-colors">6 Specialized Agents</a>
          <a href="#hub" className="hover:text-brand-400 transition-colors">Intelligence Hub</a>
          <a href="#workflow" className="hover:text-brand-400 transition-colors">How It Works</a>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={() => onNavigate('login')}
            className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
          >
            Sign In
          </button>
          <button
            onClick={onQuickDemoLogin}
            className="px-4 py-2 rounded-xl text-xs font-bold bg-gradient-to-r from-brand-600 to-blue-600 hover:from-brand-500 hover:to-blue-500 text-white shadow-glow-blue transition-all flex items-center space-x-1.5"
          >
            <span>Launch Live Demo</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-16 pb-24 px-6 max-w-7xl mx-auto text-center overflow-hidden">
        {/* Glow ambient background */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-brand-500/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute top-1/3 left-1/3 w-64 h-64 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-slate-900 border border-slate-700 text-xs text-brand-300 mb-6">
          <Sparkles className="w-3.5 h-3.5 text-brand-400 animate-spin" />
          <span>The Next-Generation Multi-Agent Student Career Ecosystem</span>
        </div>

        <h1 className="text-4xl sm:text-6xl lg:text-7xl font-black tracking-tight text-white max-w-4xl mx-auto leading-[1.1]">
          Connect Skills. <br />
          <span className="bg-gradient-to-r from-brand-400 via-blue-400 to-purple-400 bg-clip-text text-transparent">
            Discover Opportunities.
          </span> <br />
          Build Your Future.
        </h1>

        <p className="mt-6 text-base sm:text-lg text-slate-400 max-w-2xl mx-auto leading-relaxed">
          Millions of students don’t know what to learn or fall prey to fake internships. SkillBridge AI orchestrates <strong className="text-white">six specialized AI agents</strong> to analyze your skill gaps, guide your daily learning, verify your abilities, and launch your career.
        </p>

        {/* CTA Buttons */}
        <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            onClick={onQuickDemoLogin}
            className="w-full sm:w-auto px-8 py-3.5 rounded-xl text-sm font-bold bg-gradient-to-r from-brand-600 via-blue-600 to-purple-600 hover:from-brand-500 hover:to-purple-500 text-white shadow-glow-blue transition-all transform hover:-translate-y-0.5 flex items-center justify-center space-x-2"
          >
            <span>Explore Working Demo (Alex Chen)</span>
            <ArrowRight className="w-4 h-4" />
          </button>
          <button
            onClick={() => onNavigate('onboarding')}
            className="w-full sm:w-auto px-7 py-3.5 rounded-xl text-sm font-semibold bg-slate-900/90 hover:bg-slate-800 text-slate-200 border border-slate-700 transition-colors"
          >
            Create Free Account
          </button>
        </div>

        {/* Key Metrics / Highlights */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto text-left">
          <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800">
            <div className="text-2xl font-black text-white">6</div>
            <div className="text-xs font-semibold text-brand-400">Specialized AI Agents</div>
            <div className="text-[11px] text-slate-400">Coordinated via Intelligence Hub</div>
          </div>
          <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800">
            <div className="text-2xl font-black text-white">100%</div>
            <div className="text-xs font-semibold text-emerald-400">Transparent Scoring</div>
            <div className="text-[11px] text-slate-400">No opaque or fake certificates</div>
          </div>
          <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800">
            <div className="text-2xl font-black text-white">4-Tier</div>
            <div className="text-xs font-semibold text-rose-400">Scam Shield</div>
            <div className="text-[11px] text-slate-400">Protects students from fraud</div>
          </div>
          <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800">
            <div className="text-2xl font-black text-white">Free</div>
            <div className="text-xs font-semibold text-purple-400">Curated Resources</div>
            <div className="text-[11px] text-slate-400">Zero paywalled links</div>
          </div>
        </div>
      </section>

      {/* Six Intelligent Agents Showcase */}
      <section id="agents" className="py-20 px-6 max-w-7xl mx-auto border-t border-slate-800/80">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-brand-500/20 text-brand-300 border border-brand-500/30">
            The Multi-Agent Architecture
          </span>
          <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight mt-4">
            Six Specialized AI Agents Working in Harmony
          </h2>
          <p className="text-sm text-slate-400 mt-2">
            Not a generic chatbot. Each agent executes a dedicated domain model with custom interfaces, evaluation rubrics, and shared student memory.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {agents.map(ag => {
            const Icon = ag.icon;
            return (
              <div 
                key={ag.id}
                onClick={onQuickDemoLogin}
                className="p-6 rounded-2xl glass-panel glass-panel-hover border border-slate-800 flex flex-col justify-between cursor-pointer group"
              >
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono font-bold text-slate-500">{ag.num}</span>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold border uppercase tracking-wider ${ag.color}`}>
                      {ag.badge}
                    </span>
                  </div>

                  <div className="w-12 h-12 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Icon className="w-6 h-6 text-brand-400" />
                  </div>

                  <div>
                    <h3 className="text-lg font-bold text-white group-hover:text-brand-300 transition-colors">
                      {ag.title}
                    </h3>
                    <div className="text-xs font-semibold text-slate-400">{ag.subtitle}</div>
                  </div>

                  <p className="text-xs text-slate-400 leading-relaxed">
                    {ag.description}
                  </p>
                </div>

                <div className="pt-5 mt-4 border-t border-slate-800/80 flex items-center justify-between text-xs font-semibold text-brand-400 group-hover:text-brand-300">
                  <span>Launch Agent</span>
                  <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Intelligence Hub & Orchestration Flow */}
      <section id="hub" className="py-20 px-6 max-w-7xl mx-auto border-t border-slate-800/80">
        <div className="p-8 sm:p-12 rounded-3xl bg-gradient-to-br from-navy-900 via-slate-900 to-navy-950 border border-brand-500/30 relative overflow-hidden shadow-2xl">
          <div className="max-w-2xl space-y-4 relative z-10">
            <span className="px-3 py-1 rounded-full text-xs font-bold bg-brand-500/20 text-brand-300 border border-brand-500/40">
              Central Orchestration Engine
            </span>
            <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
              SkillBridge Intelligence Hub
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              When a student asks: <em>"I want to become a software engineer, but I don't know where to start"</em>, our hub doesn’t guess. It delegates to <strong>Agent 1</strong> to detect missing skills, triggers <strong>Agent 2</strong> to map a 4-week curriculum, and coordinates with <strong>Agent 6</strong> to outline career assets—all in one unified response.
            </p>
            <div className="pt-2">
              <button
                onClick={onQuickDemoLogin}
                className="px-6 py-3 rounded-xl text-xs font-bold bg-brand-600 hover:bg-brand-500 text-white shadow-glow-blue transition-all"
              >
                Experience Live Multi-Agent Hub →
              </button>
            </div>
          </div>

          <div className="hidden lg:block absolute right-8 top-1/2 -translate-y-1/2 w-80 opacity-90">
            <div className="p-4 rounded-2xl bg-slate-950/90 border border-slate-800 space-y-3 font-mono text-[11px]">
              <div className="flex items-center justify-between text-slate-400 pb-2 border-b border-slate-800">
                <span>Orchestration Log</span>
                <span className="text-emerald-400">RUNNING</span>
              </div>
              <div className="text-blue-400">▶ Agent 1: Skill Gap Analyzed (74%)</div>
              <div className="text-purple-400">▶ Agent 2: 4-Week Roadmap Built</div>
              <div className="text-emerald-400">▶ Agent 3: Verified Python Badge</div>
              <div className="text-amber-400">▶ Agent 4: 4 Fellowships Matched</div>
              <div className="text-rose-400">▶ Agent 5: Scam Risk Checked (0 Flags)</div>
            </div>
          </div>
        </div>
      </section>

      {/* How it Works Workflow */}
      <section id="workflow" className="py-20 px-6 max-w-7xl mx-auto border-t border-slate-800/80">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-purple-500/20 text-purple-300 border border-purple-500/30">
            Student Journey
          </span>
          <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight mt-4">
            From Zero Direction to Industry Ready
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {workflowSteps.map(st => (
            <div key={st.step} className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
              <div className="w-8 h-8 rounded-lg bg-brand-600/30 border border-brand-500/40 text-brand-300 font-bold flex items-center justify-center text-xs">
                {st.step}
              </div>
              <h3 className="font-bold text-base text-white">{st.title}</h3>
              <p className="text-xs text-slate-400 leading-relaxed">{st.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Bottom CTA */}
      <section className="py-20 px-6 max-w-4xl mx-auto text-center border-t border-slate-800/80">
        <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
          Ready to Bridge Your Skill Gap?
        </h2>
        <p className="mt-4 text-sm text-slate-400">
          Join thousands of college students discovering verified career clarity today.
        </p>
        <div className="mt-8 flex justify-center">
          <button
            onClick={onQuickDemoLogin}
            className="px-8 py-3.5 rounded-xl text-sm font-bold bg-gradient-to-r from-brand-600 to-purple-600 hover:from-brand-500 hover:to-purple-500 text-white shadow-glow-blue transition-all flex items-center space-x-2"
          >
            <span>Launch SkillBridge AI Dashboard</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-900 py-8 px-6 text-center text-xs text-slate-500">
        <p>© 2026 SkillBridge AI — Connect Skills. Discover Opportunities. Build Your Future.</p>
        <p className="pt-1 text-[11px] text-slate-600">Built for student success. AI responses are advisory.</p>
      </footer>
    </div>
  );
};
