import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useAgent } from '../context/AgentContext';
import { getQuiz, submitQuiz } from '../services/api';
import { Quiz, QuizEvaluation, Skill } from '../types';
import { WeaknessRecoveryModal } from '../components/WeaknessRecoveryModal';
import { 
  CheckCircle2, 
  ShieldCheck, 
  Clock, 
  Award, 
  AlertCircle, 
  HelpCircle, 
  Sparkles, 
  ArrowRight,
  Flame,
  Check,
  RefreshCw,
  Hash
} from 'lucide-react';

interface SkillVerificationPageProps {
  onNavigate: (page: string) => void;
}

export const SkillVerificationPage: React.FC<SkillVerificationPageProps> = ({ onNavigate }) => {
  const { student, refreshStudent } = useAuth();
  const { setActiveAgent } = useAgent();

  const [selectedSkill, setSelectedSkill] = useState<string>('Python');
  const [difficulty, setDifficulty] = useState<string>('Intermediate');
  const [quiz, setQuiz] = useState<Quiz | null>(null);
  const [loadingQuiz, setLoadingQuiz] = useState<boolean>(false);

  // Active Test State
  const [isTestRunning, setIsTestRunning] = useState<boolean>(false);
  const [currentQuestionIdx, setCurrentQuestionIdx] = useState<number>(0);
  const [userAnswers, setUserAnswers] = useState<Record<string, number>>({});
  const [timeLeft, setTimeLeft] = useState<number>(600); // 10 mins
  const [evaluation, setEvaluation] = useState<QuizEvaluation | null>(null);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Weakness Recovery state
  const [recoveryModalOpen, setRecoveryModalOpen] = useState(false);
  const [recoveryPlan, setRecoveryPlan] = useState<any>(null);

  const availableSkills = [
    'Python',
    'React & Modern UI',
    'Machine Learning (Scikit-Learn)',
    'Data Structures & Algorithms',
    'Git & GitHub'
  ];

  useEffect(() => {
    setActiveAgent('Skill Verification Agent (Agent 3)');
  }, [setActiveAgent]);

  // Timer countdown
  useEffect(() => {
    let timer: any;
    if (isTestRunning && timeLeft > 0) {
      timer = setInterval(() => setTimeLeft(prev => prev - 1), 1000);
    } else if (isTestRunning && timeLeft === 0) {
      handleSubmitTest();
    }
    return () => clearInterval(timer);
  }, [isTestRunning, timeLeft]);

  const handleStartTest = async () => {
    setLoadingQuiz(true);
    setEvaluation(null);
    setUserAnswers({});
    setCurrentQuestionIdx(0);
    setTimeLeft(600);

    try {
      const res = await getQuiz(selectedSkill, difficulty);
      if (res.quiz) {
        setQuiz(res.quiz);
        setIsTestRunning(true);
      }
    } finally {
      setLoadingQuiz(false);
    }
  };

  const handleSelectOption = (questionId: string, optionIdx: number) => {
    setUserAnswers(prev => ({ ...prev, [questionId]: optionIdx }));
  };

  const handleSubmitTest = async () => {
    if (!quiz) return;
    setIsSubmitting(true);
    try {
      const res = await submitQuiz({
        skillName: quiz.skillName,
        answers: userAnswers,
        quiz,
        studentId: student?.id
      });

      if (res.evaluation) {
        setEvaluation(res.evaluation);
        setIsTestRunning(false);
        await refreshStudent();
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const verifiedSkills = (student?.skills || []).filter(s => s.verified);
  const assessedSkills = (student?.skills || []).filter(s => s.assessed && !s.verified);
  const selfReportedSkills = (student?.skills || []).filter(s => s.selfReported);

  const currentQ = quiz?.questions[currentQuestionIdx];
  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;

  return (
    <div className="space-y-6 sm:space-y-8 animate-fadeIn">
      {/* Header */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-emerald-950/80 via-slate-900 to-navy-900 border border-emerald-500/30 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              Agent 3 • Performance Verifier
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight mt-1 flex items-center space-x-3">
            <CheckCircle2 className="w-7 h-7 text-emerald-400" />
            <span>Skill Verification Agent</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 max-w-xl mt-1">
            Do not just self-report your skills. Prove actual competence through timed assessments to earn verified badges.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <div className="px-3.5 py-1.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold flex items-center space-x-1.5">
            <Award className="w-4 h-4" />
            <span>{verifiedSkills.length} Badges Claimed</span>
          </div>
        </div>
      </div>

      {/* Main Testing View vs Idle View */}
      {isTestRunning && quiz && currentQ ? (
        /* ACTIVE TEST RUNNER */
        <div className="p-6 sm:p-8 rounded-2xl glass-panel border border-emerald-500/30 space-y-6 animate-fadeIn">
          {/* Top Bar: Progress & Timer */}
          <div className="flex items-center justify-between pb-4 border-b border-slate-800">
            <div>
              <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">
                Verifying: {quiz.skillName} ({quiz.difficulty})
              </span>
              <div className="text-sm font-bold text-white pt-0.5">
                Question {currentQuestionIdx + 1} of {quiz.questions.length}
              </div>
            </div>

            <div className="flex items-center space-x-2 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-amber-400 font-mono text-xs font-bold">
              <Clock className="w-4 h-4 text-amber-400" />
              <span>{minutes}:{seconds < 10 ? `0${seconds}` : seconds}</span>
            </div>
          </div>

          {/* Question Text */}
          <div className="space-y-4">
            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 text-sm font-medium text-slate-100 leading-relaxed">
              {currentQ.question}
            </div>

            {/* Options */}
            <div className="grid grid-cols-1 gap-2.5">
              {currentQ.options.map((opt, optIdx) => {
                const isSelected = userAnswers[currentQ.id] === optIdx;
                return (
                  <button
                    key={optIdx}
                    onClick={() => handleSelectOption(currentQ.id, optIdx)}
                    className={`p-3.5 rounded-xl text-left text-xs font-medium border transition-all flex items-center justify-between ${
                      isSelected
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500 shadow-glow-emerald'
                        : 'bg-slate-900/90 text-slate-300 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <span>{opt}</span>
                    <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold border ${
                      isSelected ? 'border-emerald-400 bg-emerald-500 text-navy-950' : 'border-slate-700 text-slate-500'
                    }`}>
                      {String.fromCharCode(65 + optIdx)}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Navigation Controls */}
          <div className="flex items-center justify-between pt-4 border-t border-slate-800">
            <button
              disabled={currentQuestionIdx === 0}
              onClick={() => setCurrentQuestionIdx(prev => prev - 1)}
              className="px-4 py-2 rounded-xl text-xs font-medium text-slate-400 hover:text-white disabled:opacity-40"
            >
              ← Previous Question
            </button>

            {currentQuestionIdx < quiz.questions.length - 1 ? (
              <button
                onClick={() => setCurrentQuestionIdx(prev => prev + 1)}
                className="px-5 py-2.5 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white transition-colors"
              >
                Next Question →
              </button>
            ) : (
              <button
                onClick={handleSubmitTest}
                disabled={isSubmitting}
                className="px-6 py-2.5 rounded-xl text-xs font-bold bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white shadow-glow-emerald transition-all"
              >
                {isSubmitting ? 'Evaluating Test...' : 'Finish & Submit for Verification ✓'}
              </button>
            )}
          </div>
        </div>
      ) : evaluation ? (
        /* POST-TEST RESULTS & VERIFICATION BADGE VIEW */
        <div className="p-6 sm:p-8 rounded-2xl glass-panel border border-slate-800 space-y-6 animate-fadeIn">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-4 border-b border-slate-800 gap-4">
            <div>
              <div className="text-xs font-bold text-slate-400">Diagnostic Assessment Complete</div>
              <h2 className="text-2xl font-black text-white mt-0.5">
                {evaluation.isPassed ? '🎉 Verification Bar Passed!' : 'Assessment Completed — Practice Recommended'}
              </h2>
            </div>
            <button
              onClick={() => setEvaluation(null)}
              className="px-4 py-2 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200"
            >
              Test Another Skill
            </button>
          </div>

          {/* Verification Badge Card (if score >= 80%) */}
          {evaluation.verificationBadge && (
            <div className="p-5 sm:p-6 rounded-2xl bg-gradient-to-r from-emerald-950/70 via-slate-900 to-navy-950 border border-emerald-500/40 shadow-glow-emerald flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="flex items-center space-x-4">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center text-white shadow-lg shrink-0">
                  <Award className="w-9 h-9" />
                </div>
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="text-lg font-black text-white">{evaluation.verificationBadge.verificationTier}</span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                      OFFICIAL BADGE
                    </span>
                  </div>
                  <div className="text-xs text-slate-300 font-semibold pt-0.5">
                    Certified Skill: <strong className="text-emerald-300">{evaluation.verificationBadge.skillName}</strong> (Score: {evaluation.scorePercentage}%)
                  </div>
                  <div className="text-[10px] text-slate-500 font-mono pt-1">
                    Hash: {evaluation.verificationBadge.verificationHash.substring(0, 24)}... • Issued by {evaluation.verificationBadge.issuer}
                  </div>
                </div>
              </div>

              <div className="shrink-0 text-center">
                <div className="text-3xl font-black text-emerald-400">{evaluation.scorePercentage}%</div>
                <div className="text-[10px] font-bold text-slate-400 uppercase">Verified Score</div>
              </div>
            </div>
          )}

          {/* Score & Breakdown summary */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
            <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
              <div className="text-lg font-bold text-white">{evaluation.scorePercentage}%</div>
              <div className="text-[10px] text-slate-400 uppercase">Score Earned</div>
            </div>
            <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
              <div className="text-lg font-bold text-white">{evaluation.passingScore}%</div>
              <div className="text-[10px] text-slate-400 uppercase">Passing Bar</div>
            </div>
            <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
              <div className="text-lg font-bold text-emerald-400">{evaluation.correctCount} / {evaluation.totalQuestions}</div>
              <div className="text-[10px] text-slate-400 uppercase">Correct Answers</div>
            </div>
            <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
              <div className={`text-lg font-bold ${evaluation.isPassed ? 'text-emerald-400' : 'text-amber-400'}`}>
                {evaluation.isPassed ? 'Verified' : 'Assessed'}
              </div>
              <div className="text-[10px] text-slate-400 uppercase">Profile Status</div>
            </div>
          </div>

          {/* Question-by-Question Review with Explanations */}
          <div className="space-y-3 pt-2">
            <h4 className="font-bold text-xs uppercase tracking-wider text-slate-300">Question-by-Question Review</h4>
            <div className="space-y-3">
              {evaluation.questionResults.map((q, idx) => (
                <div key={q.questionId} className={`p-4 rounded-xl border ${q.isCorrect ? 'bg-slate-900/60 border-slate-800' : 'bg-rose-950/20 border-rose-500/30'}`}>
                  <div className="flex items-start justify-between gap-2 text-xs">
                    <div className="font-semibold text-white">
                      {idx + 1}. {q.question}
                    </div>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold shrink-0 ${
                      q.isCorrect ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'
                    }`}>
                      {q.isCorrect ? 'Correct ✓' : 'Incorrect ✗'}
                    </span>
                  </div>
                  <div className="mt-2 text-[11px] text-slate-400 bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                    <strong className="text-slate-300">Explanation: </strong>
                    {q.explanation}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      ) : (
        /* IDLE VIEW: Test Launcher & Three-Tier Skills Inventory */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Test Launcher (Col 7) */}
          <div className="lg:col-span-7 p-6 rounded-2xl glass-panel border border-slate-800 space-y-5">
            <div>
              <h3 className="font-bold text-sm text-white">Launch Skill Diagnostic Assessment</h3>
              <p className="text-xs text-slate-400 pt-0.5">
                Take a 4-question timed test to upgrade a self-reported skill into an officially verified skill.
              </p>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 pb-1.5">Select Technology:</label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {availableSkills.map(sk => (
                    <button
                      key={sk}
                      onClick={() => setSelectedSkill(sk)}
                      className={`p-3 rounded-xl text-left text-xs font-semibold border transition-all ${
                        selectedSkill === sk
                          ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500 shadow-glow-emerald'
                          : 'bg-slate-900 text-slate-300 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      {sk}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 pb-1.5">Target Difficulty Level:</label>
                <div className="flex space-x-3">
                  {['Beginner', 'Intermediate', 'Advanced'].map(diff => (
                    <button
                      key={diff}
                      onClick={() => setDifficulty(diff)}
                      className={`flex-1 py-2 rounded-xl text-xs font-medium border transition-all ${
                        difficulty === diff
                          ? 'bg-slate-800 text-white border-slate-600 font-bold'
                          : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
                      }`}
                    >
                      {diff}
                    </button>
                  ))}
                </div>
              </div>

              <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 text-xs text-slate-400 space-y-1.5">
                <div className="font-bold text-slate-300">Verification Criteria:</div>
                <div className="flex items-center space-x-1.5 text-[11px]">
                  <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>Score &ge; 80% to earn official verified status & boost readiness index</span>
                </div>
                <div className="flex items-center space-x-1.5 text-[11px]">
                  <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>Includes MCQs, code-analysis, and real-world system debugging</span>
                </div>
              </div>

              <button
                onClick={handleStartTest}
                disabled={loadingQuiz}
                className="w-full py-3.5 rounded-xl text-xs font-bold bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white shadow-glow-emerald transition-all flex items-center justify-center space-x-2"
              >
                <span>{loadingQuiz ? 'Generating Assessment...' : `Start Verification for ${selectedSkill} →`}</span>
              </button>
            </div>
          </div>

          {/* Right Column: Three-Tier Skills Inventory (Col 5) */}
          <div className="lg:col-span-5 space-y-4">
            <div className="p-6 rounded-2xl glass-panel border border-slate-800 space-y-4">
              <h3 className="font-bold text-sm text-white">Your Audited Skills Inventory</h3>
              <p className="text-[11px] text-slate-400">
                Skills are explicitly segregated into three rigorous tiers:
              </p>

              {/* Verified Skills */}
              <div className="p-3.5 rounded-xl bg-emerald-950/20 border border-emerald-500/30 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-emerald-400 flex items-center space-x-1">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>Verified Skills ({verifiedSkills.length})</span>
                  </span>
                  <span className="text-[10px] text-emerald-500 font-mono font-bold">&ge;80% passing</span>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {verifiedSkills.length === 0 ? (
                    <span className="text-[11px] text-slate-500">Take a test to earn your first verified badge!</span>
                  ) : (
                    verifiedSkills.map(s => (
                      <span key={s.name} className="px-2 py-0.5 rounded text-[11px] font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                        {s.name} ({s.verificationScore}%)
                      </span>
                    ))
                  )}
                </div>
              </div>

              {/* Assessed Skills */}
              <div className="p-3.5 rounded-xl bg-blue-950/20 border border-blue-500/30 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-blue-400">Assessed Skills ({assessedSkills.length})</span>
                  <span className="text-[10px] text-blue-500 font-mono font-bold">50% - 79%</span>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {assessedSkills.length === 0 ? (
                    <span className="text-[11px] text-slate-500">None in this tier.</span>
                  ) : (
                    assessedSkills.map(s => (
                      <span key={s.name} className="px-2 py-0.5 rounded text-[11px] font-semibold bg-blue-500/20 text-blue-300 border border-blue-500/40">
                        {s.name} ({s.verificationScore}%)
                      </span>
                    ))
                  )}
                </div>
              </div>

              {/* Self-Reported */}
              <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-400">Self-Reported ({selfReportedSkills.length})</span>
                  <span className="text-[10px] text-slate-500">Unverified</span>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {selfReportedSkills.map(s => (
                    <span key={s.name} className="px-2 py-0.5 rounded text-[11px] text-slate-400 bg-slate-800 border border-slate-700">
                      {s.name}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Weakness Recovery Modal */}
      <WeaknessRecoveryModal
        isOpen={recoveryModalOpen}
        onClose={() => setRecoveryModalOpen(false)}
        recoveryPlan={recoveryPlan}
        onStartRetest={skill => setSelectedSkill(skill)}
      />
    </div>
  );
};
