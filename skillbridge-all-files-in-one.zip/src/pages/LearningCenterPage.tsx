import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useAgent } from '../context/AgentContext';
import { 
  getPersonalizedRoadmap, 
  toggleLessonCompletion, 
  explainConcept, 
  triggerWeaknessRecovery 
} from '../services/api';
import { Roadmap, Lesson } from '../types';
import { WeaknessRecoveryModal } from '../components/WeaknessRecoveryModal';
import { 
  GraduationCap, 
  BookOpen, 
  CheckCircle2, 
  Circle, 
  Play, 
  ExternalLink, 
  Sparkles, 
  Lightbulb, 
  Search, 
  HelpCircle, 
  Flame,
  ArrowRight,
  Code2
} from 'lucide-react';

interface LearningCenterPageProps {
  onNavigate: (page: string) => void;
}

export const LearningCenterPage: React.FC<LearningCenterPageProps> = ({ onNavigate }) => {
  const { student, refreshStudent } = useAuth();
  const { setActiveAgent } = useAgent();

  const [roadmap, setRoadmap] = useState<Roadmap | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [activeWeek, setActiveWeek] = useState<number>(1);

  // Concept Explainer state
  const [explainTopic, setExplainTopic] = useState('Gradient Descent');
  const [explainDifficulty, setExplainDifficulty] = useState<'Beginner' | 'Intermediate'>('Beginner');
  const [explanationData, setExplanationData] = useState<any>(null);
  const [explaining, setExplaining] = useState(false);

  // Weakness Recovery state
  const [recoveryModalOpen, setRecoveryModalOpen] = useState(false);
  const [recoveryPlan, setRecoveryPlan] = useState<any>(null);
  const [recovering, setRecovering] = useState(false);

  useEffect(() => {
    setActiveAgent('Personalized Learning Agent (Agent 2)');
    if (student) {
      setLoading(true);
      getPersonalizedRoadmap(student.id, student.targetCareerId)
        .then(res => {
          if (res.roadmap) setRoadmap(res.roadmap);
        })
        .finally(() => setLoading(false));
    }
  }, [student, setActiveAgent]);

  const handleToggleLesson = async (lessonId: string) => {
    try {
      const res = await toggleLessonCompletion(lessonId, student?.id);
      if (res.roadmap) {
        setRoadmap(res.roadmap);
        await refreshStudent();
      }
    } catch (err) {
      console.error('Failed to toggle lesson:', err);
    }
  };

  const handleExplain = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!explainTopic.trim()) return;
    setExplaining(true);
    try {
      const res = await explainConcept(explainTopic, explainDifficulty);
      if (res.explanation) setExplanationData(res.explanation);
    } finally {
      setExplaining(false);
    }
  };

  const handleTriggerRecovery = async (topic: string) => {
    setRecovering(true);
    try {
      const res = await triggerWeaknessRecovery(topic, student?.id);
      if (res.recoveryPlan) {
        setRecoveryPlan(res.recoveryPlan);
        setRecoveryModalOpen(true);
      }
    } finally {
      setRecovering(false);
    }
  };

  const currentWeekData = roadmap?.weeks?.find(w => w.weekNumber === activeWeek) || roadmap?.weeks?.[0];

  return (
    <div className="space-y-6 sm:space-y-8 animate-fadeIn">
      {/* Header */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-purple-950/80 via-slate-900 to-navy-900 border border-purple-500/30 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-purple-500/20 text-purple-300 border border-purple-500/30">
              Agent 2 • Curriculum & Tutoring
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight mt-1 flex items-center space-x-3">
            <GraduationCap className="w-7 h-7 text-purple-400" />
            <span>Personalized Learning Center</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 max-w-xl mt-1">
            Tailored weekly curriculum with free high-definition video tutorials, interactive notes, and automatic weakness recovery.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <div className="px-3 py-1.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs font-semibold flex items-center space-x-1.5">
            <Flame className="w-4 h-4 text-amber-500" />
            <span>{student?.learningStreakDays || 1}d Streak</span>
          </div>
          <button
            onClick={() => handleTriggerRecovery('Matrix Transformations')}
            disabled={recovering}
            className="px-3.5 py-1.5 rounded-xl text-xs font-bold bg-purple-600/30 hover:bg-purple-600/50 text-purple-300 border border-purple-500/40 transition-colors flex items-center space-x-1.5"
          >
            <Lightbulb className="w-3.5 h-3.5" />
            <span>{recovering ? 'Diagnosing...' : 'Test Weakness Recovery'}</span>
          </button>
        </div>
      </div>

      {/* Curriculum Roadmaps & Weeks Tabs */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Weekly Roadmap (Col 7) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="p-6 rounded-2xl glass-panel border border-slate-800 space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
              <div>
                <h3 className="font-bold text-sm text-white">4-Week Accelerated Curriculum</h3>
                <p className="text-xs text-slate-400">{roadmap?.paceRecommendation || '10-12 hours / week'}</p>
              </div>

              {/* Week Tabs */}
              <div className="flex space-x-1.5 bg-slate-900 p-1 rounded-xl border border-slate-800">
                {(roadmap?.weeks || []).map(w => (
                  <button
                    key={w.weekNumber}
                    onClick={() => setActiveWeek(w.weekNumber)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                      activeWeek === w.weekNumber
                        ? 'bg-purple-600 text-white shadow-glow-purple'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Week {w.weekNumber}
                  </button>
                ))}
              </div>
            </div>

            {/* Current Active Week Details */}
            {currentWeekData && (
              <div className="space-y-4">
                <div className="p-4 rounded-xl bg-purple-950/20 border border-purple-500/30">
                  <div className="font-bold text-xs sm:text-sm text-purple-300">
                    Week {currentWeekData.weekNumber}: {currentWeekData.title}
                  </div>
                  <p className="text-xs text-slate-300 pt-1 leading-relaxed">
                    {currentWeekData.objective || currentWeekData.summary}
                  </p>
                </div>

                {/* Lesson List with completion checkboxes */}
                <div className="space-y-3">
                  {currentWeekData.lessons.map((les, idx) => (
                    <div
                      key={les.id}
                      className={`p-4 rounded-xl border transition-all ${
                        les.completed 
                          ? 'bg-slate-900/40 border-slate-800/80 opacity-80' 
                          : 'bg-slate-900/90 hover:bg-slate-800/80 border-slate-800'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-start space-x-3">
                          <button
                            onClick={() => handleToggleLesson(les.id)}
                            className="text-slate-400 hover:text-purple-400 mt-0.5 shrink-0 focus:outline-none"
                          >
                            {les.completed ? (
                              <CheckCircle2 className="w-5 h-5 text-emerald-400 fill-emerald-500/20" />
                            ) : (
                              <Circle className="w-5 h-5 text-slate-500 hover:text-purple-400" />
                            )}
                          </button>
                          <div>
                            <div className={`text-xs font-bold ${les.completed ? 'line-through text-slate-500' : 'text-white'}`}>
                              {les.title}
                            </div>
                            <p className="text-[11px] text-slate-400 pt-1 leading-snug">{les.summary}</p>
                            
                            {les.keyTakeaways && (
                              <div className="flex flex-wrap gap-1.5 pt-2">
                                {les.keyTakeaways.map((takeaway, tIdx) => (
                                  <span key={tIdx} className="px-2 py-0.5 rounded text-[10px] bg-slate-950 text-slate-300 border border-slate-800">
                                    💡 {takeaway}
                                  </span>
                                ))}
                              </div>
                            )}
                          </div>
                        </div>

                        <div className="shrink-0 text-right space-y-1">
                          <span className="px-2 py-0.5 rounded text-[10px] font-mono text-slate-400 bg-slate-800">
                            {les.duration}
                          </span>
                          {les.resourceUrl && (
                            <div>
                              <a
                                href={les.resourceUrl}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="inline-flex items-center space-x-1 text-[11px] text-purple-400 hover:underline font-semibold"
                              >
                                <Play className="w-3 h-3 fill-purple-400" />
                                <span>Watch Video</span>
                              </a>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Interactive Concept Explainer (Col 5) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="p-6 rounded-2xl glass-panel border border-slate-800 space-y-4">
            <div className="flex items-center space-x-2">
              <Sparkles className="w-4 h-4 text-purple-400" />
              <h3 className="font-bold text-sm text-white">Interactive Concept Explainer</h3>
            </div>
            <p className="text-xs text-slate-400">
              Stuck on a tricky concept? Agent 2 teaches topics in simple English with real-world analogies and code.
            </p>

            {/* Input Form */}
            <form onSubmit={handleExplain} className="space-y-3">
              <div className="flex space-x-2">
                <input
                  type="text"
                  value={explainTopic}
                  onChange={e => setExplainTopic(e.target.value)}
                  placeholder="e.g. Backpropagation, Recursion, Closures"
                  className="flex-1 px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                />
                <select
                  value={explainDifficulty}
                  onChange={e => setExplainDifficulty(e.target.value as any)}
                  className="px-2 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-purple-300 focus:outline-none"
                >
                  <option>Beginner</option>
                  <option>Intermediate</option>
                </select>
              </div>

              <button
                type="submit"
                disabled={explaining}
                className="w-full py-2.5 rounded-xl text-xs font-bold bg-purple-600 hover:bg-purple-500 text-white shadow-glow-purple transition-all flex items-center justify-center space-x-1.5"
              >
                <span>{explaining ? 'Synthesizing Explanation...' : 'Explain in Simple English'}</span>
                <Sparkles className="w-3.5 h-3.5" />
              </button>
            </form>

            {/* Explainer Result */}
            {explanationData && (
              <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 space-y-3 text-xs animate-fadeIn">
                <div className="font-bold text-purple-300 flex items-center justify-between">
                  <span>Explanation: {explanationData.topic}</span>
                  <span className="text-[10px] text-slate-400">{explanationData.difficulty}</span>
                </div>

                <p className="text-slate-200 leading-relaxed text-[11px]">
                  {explanationData.simpleExplanation}
                </p>

                {explanationData.realWorldAnalogy && (
                  <div className="p-3 rounded-lg bg-purple-950/30 border border-purple-500/30 text-[11px] text-purple-200">
                    <strong className="text-purple-400">💡 Real-World Analogy: </strong>
                    {explanationData.realWorldAnalogy}
                  </div>
                )}

                {explanationData.codeExample && (
                  <div className="space-y-1">
                    <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Example Code:</div>
                    <pre className="p-3 rounded-lg bg-slate-950 text-slate-300 font-mono text-[10px] overflow-x-auto border border-slate-800">
                      {explanationData.codeExample}
                    </pre>
                  </div>
                )}

                {explanationData.practiceChallenge && (
                  <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-[11px] text-slate-300">
                    <strong className="text-brand-400">Quick Challenge: </strong>
                    {explanationData.practiceChallenge}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Weakness Recovery Modal */}
      <WeaknessRecoveryModal
        isOpen={recoveryModalOpen}
        onClose={() => setRecoveryModalOpen(false)}
        recoveryPlan={recoveryPlan}
        onStartRetest={skill => onNavigate('verification')}
      />
    </div>
  );
};
