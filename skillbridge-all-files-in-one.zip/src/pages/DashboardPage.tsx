import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useAgent } from '../context/AgentContext';
import { 
  getReadinessScore, 
  getPersonalizedRoadmap, 
  getOpportunities, 
  analyzeSkillGap,
  getScamHistory
} from '../services/api';
import { ReadinessScore, SkillGapReport, Roadmap, Opportunity } from '../types';
import { ReadinessGauge } from '../components/ReadinessGauge';
import { DailyMissionsCard } from '../components/DailyMissionsCard';
import { CareerReportModal } from '../components/CareerReportModal';
import { WeaknessRecoveryModal } from '../components/WeaknessRecoveryModal';
import { 
  Radar, 
  GraduationCap, 
  CheckCircle2, 
  Briefcase, 
  ShieldAlert, 
  Compass, 
  Sparkles, 
  ArrowRight, 
  Flame, 
  Activity, 
  BookOpen,
  Award,
  AlertTriangle,
  Play
} from 'lucide-react';

interface DashboardPageProps {
  onNavigate: (page: string) => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({ onNavigate }) => {
  const { student } = useAuth();
  const { setActiveAgent } = useAgent();

  const [readiness, setReadiness] = useState<ReadinessScore | null>(null);
  const [skillGap, setSkillGap] = useState<SkillGapReport | null>(null);
  const [roadmap, setRoadmap] = useState<Roadmap | null>(null);
  const [opportunities, setOpportunities] = useState<Opportunity[]>([]);
  const [recentScam, setRecentScam] = useState<any>(null);

  const [showReportModal, setShowReportModal] = useState(false);
  const [showRecoveryModal, setShowRecoveryModal] = useState(false);
  const [activeRecoveryPlan, setActiveRecoveryPlan] = useState<any>(null);

  useEffect(() => {
    setActiveAgent('SkillBridge Intelligence Hub');

    if (student) {
      getReadinessScore(student.id).then(res => {
        if (res.readiness) setReadiness(res.readiness);
      });

      analyzeSkillGap(student.id).then(res => {
        if (res.report) setSkillGap(res.report);
      });

      getPersonalizedRoadmap(student.id).then(res => {
        if (res.roadmap) setRoadmap(res.roadmap);
      });

      getOpportunities({ studentId: student.id, isBeginnerFriendly: true }).then(res => {
        if (res.opportunities) setOpportunities(res.opportunities.slice(0, 3));
      });

      getScamHistory(student.id).then(res => {
        if (res.history && res.history.length > 0) setRecentScam(res.history[0]);
      });
    }
  }, [student, setActiveAgent]);

  const verifiedSkillsCount = (student?.skills || []).filter(s => s.verified).length;
  const missingSkills = skillGap?.evaluatedSkills?.filter(s => s.status === 'Missing') || [];

  return (
    <div className="space-y-6 sm:space-y-8 animate-fadeIn">
      {/* Top Welcome Banner */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-brand-950 via-slate-900 to-purple-950 border border-slate-800 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-full bg-brand-600/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center space-x-2 text-xs font-bold uppercase tracking-wider text-brand-400">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Multi-Agent Career Command Center</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight mt-1">
              Welcome back, {student?.name || 'Student'}! 👋
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 max-w-xl mt-1 leading-relaxed">
              Target Goal: <strong className="text-brand-300 font-semibold">{student?.targetCareerTitle || 'Software Engineer'}</strong> • {student?.college} ({student?.yearOfStudy})
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => onNavigate('assistant')}
              className="px-4 py-2.5 rounded-xl text-xs font-bold bg-brand-600 hover:bg-brand-500 text-white shadow-glow-blue transition-all flex items-center space-x-1.5"
            >
              <span>Ask AI Assistant</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setShowReportModal(true)}
              className="px-4 py-2.5 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors flex items-center space-x-1.5"
            >
              <Award className="w-3.5 h-3.5 text-amber-400" />
              <span>Dossier Report</span>
            </button>
          </div>
        </div>
      </div>

      {/* Row 1: Readiness Gauge & Daily Missions */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7">
          <ReadinessGauge 
            readiness={readiness} 
            onOpenReport={() => setShowReportModal(true)} 
          />
        </div>

        <div className="lg:col-span-5">
          <DailyMissionsCard 
            missions={student?.activeDailyMissions || []} 
            onNavigateAgent={page => onNavigate(page)}
          />
        </div>
      </div>

      {/* Row 2: Skill Gaps & Active Learning Roadmap */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Missing Skills & Priority (Agent 1) */}
        <div className="lg:col-span-6 p-5 sm:p-6 rounded-2xl glass-panel border border-slate-800 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center space-x-2">
              <Radar className="w-4 h-4 text-blue-400" />
              <h3 className="font-bold text-sm text-slate-100">Target Skill Gaps</h3>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-500/10 text-blue-400 border border-blue-500/20">
                Agent 1
              </span>
            </div>
            <button
              onClick={() => onNavigate('skill-gap')}
              className="text-xs font-semibold text-brand-400 hover:underline"
            >
              Full Analysis →
            </button>
          </div>

          <div className="space-y-3">
            <div className="text-xs text-slate-300">
              Benchmark match for <strong className="text-white">{student?.targetCareerTitle}</strong>:
            </div>

            {/* Evaluated skills preview */}
            <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
              {(skillGap?.evaluatedSkills || []).slice(0, 5).map(sk => (
                <div key={sk.name} className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-between text-xs">
                  <div>
                    <div className="font-semibold text-slate-200">{sk.name}</div>
                    <div className="text-[10px] text-slate-400">
                      Req: {sk.benchmark} • Priority: <span className={sk.priority === 'HIGH' ? 'text-rose-400 font-bold' : 'text-slate-400'}>{sk.priority}</span>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                      sk.status === 'Verified' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' :
                      sk.status === 'Acquired' ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30' :
                      sk.status === 'Weak' ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' :
                      'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                    }`}>
                      {sk.status}
                    </span>
                    <div className="text-[10px] font-mono text-slate-500 pt-0.5">{sk.proficiencyScore}% score</div>
                  </div>
                </div>
              ))}
            </div>

            {skillGap?.priorityToLearn && skillGap.priorityToLearn.length > 0 && (
              <div className="p-3 rounded-xl bg-blue-950/30 border border-blue-500/30 text-xs text-blue-300">
                <span className="font-bold">Next Priority: </span>
                Start with <strong className="underline">{skillGap.priorityToLearn[0]}</strong> to close your highest-impact gap.
              </div>
            )}
          </div>
        </div>

        {/* Active Learning Curriculum (Agent 2) */}
        <div className="lg:col-span-6 p-5 sm:p-6 rounded-2xl glass-panel border border-slate-800 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center space-x-2">
              <GraduationCap className="w-4 h-4 text-purple-400" />
              <h3 className="font-bold text-sm text-slate-100">Active Learning Roadmap</h3>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-500/10 text-purple-400 border border-purple-500/20">
                Agent 2
              </span>
            </div>
            <button
              onClick={() => onNavigate('learning')}
              className="text-xs font-semibold text-brand-400 hover:underline"
            >
              Go to Lessons →
            </button>
          </div>

          <div className="space-y-3">
            {roadmap?.weeks && roadmap.weeks[0] ? (
              <div className="p-3.5 rounded-xl bg-purple-950/20 border border-purple-500/30 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-purple-300">Week 1: {roadmap.weeks[0].title}</span>
                  <span className="text-[10px] text-slate-400">Current Milestone</span>
                </div>
                <p className="text-[11px] text-slate-400">{roadmap.weeks[0].summary || roadmap.weeks[0].objective}</p>

                {/* Lessons in Week 1 */}
                <div className="space-y-2 pt-2">
                  {roadmap.weeks[0].lessons.slice(0, 3).map((les, idx) => (
                    <div key={les.id || idx} className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between text-xs">
                      <div className="flex items-center space-x-2.5">
                        <span className={`w-4 h-4 rounded-full flex items-center justify-center text-[10px] font-bold ${
                          les.completed ? 'bg-emerald-500/20 text-emerald-400' : 'bg-slate-800 text-slate-400'
                        }`}>
                          {les.completed ? '✓' : idx + 1}
                        </span>
                        <span className={`truncate max-w-[200px] sm:max-w-xs ${les.completed ? 'line-through text-slate-500' : 'text-slate-200'}`}>
                          {les.title}
                        </span>
                      </div>
                      <span className="text-[10px] text-slate-500 shrink-0">{les.duration}</span>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="text-xs text-slate-400 py-6 text-center">Loading personalized roadmap...</div>
            )}

            <div className="flex justify-between items-center text-xs pt-1">
              <span className="text-slate-400 text-[11px]">Free YouTube Tutorials Curated</span>
              <button
                onClick={() => onNavigate('learning')}
                className="text-purple-400 hover:text-purple-300 font-semibold"
              >
                Open Concept Explainer →
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Row 3: Opportunities & Scam Protection Preview */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Recommended Opportunities (Agent 4) */}
        <div className="lg:col-span-8 p-5 sm:p-6 rounded-2xl glass-panel border border-slate-800 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center space-x-2">
              <Briefcase className="w-4 h-4 text-amber-400" />
              <h3 className="font-bold text-sm text-slate-100">Matched Fellowships & Opportunities</h3>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20">
                Agent 4
              </span>
            </div>
            <button
              onClick={() => onNavigate('opportunities')}
              className="text-xs font-semibold text-brand-400 hover:underline"
            >
              Browse All ({opportunities.length}) →
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {opportunities.map(opp => (
              <div key={opp.id} className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 flex flex-col justify-between space-y-2 hover:border-slate-700 transition-colors">
                <div>
                  <div className="flex items-center justify-between text-[10px]">
                    <span className="px-2 py-0.5 rounded bg-brand-500/10 text-brand-300 font-bold border border-brand-500/20">
                      {opp.matchPercentage}% Match
                    </span>
                    <span className="text-slate-500">{opp.isRemote ? 'Remote' : opp.location}</span>
                  </div>
                  <h4 className="font-bold text-xs text-white pt-2 line-clamp-1">{opp.title}</h4>
                  <div className="text-[11px] text-slate-400">{opp.organization}</div>
                  <div className="text-[10px] text-amber-400 font-mono pt-1">{opp.stipend}</div>
                </div>

                <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px]">
                  <button
                    onClick={() => onNavigate('opportunities')}
                    className="text-brand-400 hover:underline font-semibold"
                  >
                    View Details
                  </button>
                  <button
                    onClick={() => onNavigate('safety')}
                    className="text-[10px] text-rose-400 hover:underline flex items-center space-x-0.5"
                    title="Run safety check in Scam Detector"
                  >
                    <ShieldAlert className="w-3 h-3" />
                    <span>Check Scam</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Scam Shield Quick Status (Agent 5) */}
        <div className="lg:col-span-4 p-5 sm:p-6 rounded-2xl glass-panel border border-slate-800 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center space-x-2">
              <ShieldAlert className="w-4 h-4 text-rose-400" />
              <h3 className="font-bold text-sm text-slate-100">Student Scam Shield</h3>
            </div>
            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-500/10 text-rose-400 border border-rose-500/20">
              Agent 5
            </span>
          </div>

          <div className="space-y-3">
            <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-xs space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-slate-400 text-[11px]">Recent Scan:</span>
                <span className="px-2 py-0.5 rounded text-[9px] font-bold bg-rose-500/20 text-rose-400 border border-rose-500/30">
                  HIGH RISK (92/100)
                </span>
              </div>
              <p className="text-[11px] text-slate-300 line-clamp-2">
                "Urgent Remote Data Entry. Laptop provided upon ₹2,500 deposit..."
              </p>
              <div className="text-[10px] text-rose-400 flex items-center space-x-1">
                <AlertTriangle className="w-3 h-3 shrink-0" />
                <span>Flagged: Upfront security deposit requested.</span>
              </div>
            </div>

            <button
              onClick={() => onNavigate('safety')}
              className="w-full py-2.5 rounded-xl text-xs font-semibold bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-500/30 transition-colors flex items-center justify-center space-x-1.5"
            >
              <span>Scan Suspicious Offer or DM</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Six Agents Quick Launch Grid */}
      <div className="space-y-3">
        <h3 className="font-bold text-sm text-slate-200">Access Dedicated Agent Workspaces</h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {[
            { id: 'skill-gap', label: 'Skill Gap', agent: 'Agent 1', icon: Radar, color: 'text-blue-400' },
            { id: 'learning', label: 'Learning Center', agent: 'Agent 2', icon: GraduationCap, color: 'text-purple-400' },
            { id: 'verification', label: 'Skill Quiz', agent: 'Agent 3', icon: CheckCircle2, color: 'text-emerald-400' },
            { id: 'opportunities', label: 'Opportunities', agent: 'Agent 4', icon: Briefcase, color: 'text-amber-400' },
            { id: 'safety', label: 'Scam Detector', agent: 'Agent 5', icon: ShieldAlert, color: 'text-rose-400' },
            { id: 'career', label: 'Career & ATS', agent: 'Agent 6', icon: Compass, color: 'text-cyan-400' },
          ].map(b => {
            const Icon = b.icon;
            return (
              <button
                key={b.id}
                onClick={() => onNavigate(b.id)}
                className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 flex flex-col items-center justify-center text-center space-y-1.5 transition-all hover:scale-105 group"
              >
                <Icon className={`w-5 h-5 ${b.color}`} />
                <span className="font-semibold text-xs text-slate-200 group-hover:text-white">{b.label}</span>
                <span className="text-[9px] text-slate-500 font-mono">{b.agent}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Modals */}
      <CareerReportModal 
        isOpen={showReportModal} 
        onClose={() => setShowReportModal(false)} 
      />

      <WeaknessRecoveryModal
        isOpen={showRecoveryModal}
        onClose={() => setShowRecoveryModal(false)}
        recoveryPlan={activeRecoveryPlan}
        onStartRetest={skill => onNavigate('verification')}
      />
    </div>
  );
};
