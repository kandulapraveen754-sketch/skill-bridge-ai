import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { User, Award, ShieldCheck, BookOpen, Flame, Save, Check } from 'lucide-react';

interface ProfilePageProps {
  onNavigate: (page: string) => void;
}

export const ProfilePage: React.FC<ProfilePageProps> = ({ onNavigate }) => {
  const { student, updateProfile } = useAuth();

  const [name, setName] = useState(student?.name || '');
  const [college, setCollege] = useState(student?.college || '');
  const [degree, setDegree] = useState(student?.degree || '');
  const [yearOfStudy, setYearOfStudy] = useState(student?.yearOfStudy || '');
  const [learningGoals, setLearningGoals] = useState(student?.learningGoals || '');
  const [saved, setSaved] = useState(false);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    await updateProfile({
      name,
      college,
      degree,
      yearOfStudy,
      learningGoals
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  const verifiedSkills = (student?.skills || []).filter(s => s.verified);

  return (
    <div className="space-y-6 sm:space-y-8 animate-fadeIn max-w-4xl mx-auto">
      {/* Header */}
      <div className="p-6 sm:p-8 rounded-3xl bg-slate-900 border border-slate-800 flex items-center space-x-4">
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-brand-600 via-blue-600 to-purple-600 flex items-center justify-center text-white text-2xl font-black shadow-lg">
          {student?.name?.charAt(0) || 'S'}
        </div>
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-white">{student?.name}</h1>
          <p className="text-xs text-slate-400">{student?.email} • {student?.college}</p>
          <div className="flex items-center space-x-2 pt-1 text-xs text-brand-400 font-semibold">
            <span>Target: {student?.targetCareerTitle}</span>
            <span>•</span>
            <span className="flex items-center space-x-1 text-amber-400 font-normal">
              <Flame className="w-3.5 h-3.5 fill-amber-400" />
              <span>{student?.learningStreakDays || 1}d Streak</span>
            </span>
          </div>
        </div>
      </div>

      {/* Profile Form */}
      <div className="p-6 sm:p-8 rounded-2xl glass-panel border border-slate-800 space-y-6">
        <h3 className="font-bold text-sm text-white">Student Academic Information</h3>

        <form onSubmit={handleSave} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 pb-1">Full Name</label>
              <input
                type="text"
                value={name}
                onChange={e => setName(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-brand-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 pb-1">College / University</label>
              <input
                type="text"
                value={college}
                onChange={e => setCollege(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-brand-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 pb-1">Degree Program</label>
              <input
                type="text"
                value={degree}
                onChange={e => setDegree(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-brand-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 pb-1">Year of Study</label>
              <input
                type="text"
                value={yearOfStudy}
                onChange={e => setYearOfStudy(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-brand-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 pb-1">Primary Learning Goal</label>
            <input
              type="text"
              value={learningGoals}
              onChange={e => setLearningGoals(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-brand-500"
            />
          </div>

          <div className="pt-2 flex items-center justify-between">
            <span className="text-xs text-slate-400">All 6 agents dynamically synchronize with profile updates.</span>
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl text-xs font-bold bg-brand-600 hover:bg-brand-500 text-white shadow-glow-blue transition-colors flex items-center space-x-1.5"
            >
              {saved ? <Check className="w-4 h-4" /> : <Save className="w-4 h-4" />}
              <span>{saved ? 'Changes Saved!' : 'Save Profile Changes'}</span>
            </button>
          </div>
        </form>
      </div>

      {/* Verified Badges Showcase */}
      <div className="p-6 sm:p-8 rounded-2xl glass-panel border border-slate-800 space-y-4">
        <div className="flex items-center space-x-2">
          <Award className="w-5 h-5 text-emerald-400" />
          <h3 className="font-bold text-sm text-white">Cryptographic SkillBridge Verification Badges</h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {verifiedSkills.length === 0 ? (
            <div className="text-xs text-slate-400 col-span-2">No skills verified yet. Take a diagnostic assessment in Skill Verification.</div>
          ) : (
            verifiedSkills.map(sk => (
              <div key={sk.name} className="p-4 rounded-xl bg-slate-900/90 border border-emerald-500/30 flex items-center justify-between">
                <div>
                  <div className="font-bold text-xs text-white">{sk.name}</div>
                  <div className="text-[10px] text-slate-400">Score: {sk.verificationScore}% • {sk.level}</div>
                </div>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  VERIFIED
                </span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
