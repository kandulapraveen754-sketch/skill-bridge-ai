import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useAgent } from '../context/AgentContext';
import { Settings, Key, Sparkles, Database, Check, ShieldCheck, Download, RefreshCw } from 'lucide-react';

interface SettingsPageProps {
  onNavigate: (page: string) => void;
}

export const SettingsPage: React.FC<SettingsPageProps> = ({ onNavigate }) => {
  const { student, refreshStudent } = useAuth();
  const { isAiDemoMode, setIsAiDemoMode } = useAgent();

  const [geminiKey, setGeminiKey] = useState(localStorage.getItem('user_gemini_api_key') || '');
  const [keySaved, setKeySaved] = useState(false);

  const handleSaveKey = (e: React.FormEvent) => {
    e.preventDefault();
    localStorage.setItem('user_gemini_api_key', geminiKey);
    setKeySaved(true);
    setTimeout(() => setKeySaved(false), 2000);
  };

  return (
    <div className="space-y-6 sm:space-y-8 animate-fadeIn max-w-4xl mx-auto">
      {/* Header */}
      <div className="p-6 sm:p-8 rounded-3xl bg-slate-900 border border-slate-800 flex items-center justify-between">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-white flex items-center space-x-2.5">
            <Settings className="w-6 h-6 text-slate-400" />
            <span>Platform Configuration & AI Settings</span>
          </h1>
          <p className="text-xs text-slate-400 pt-1">
            Manage your AI model keys, execution mode, and database state.
          </p>
        </div>
      </div>

      {/* AI Model Configuration */}
      <div className="p-6 sm:p-8 rounded-2xl glass-panel border border-slate-800 space-y-5">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center space-x-2">
            <Key className="w-5 h-5 text-brand-400" />
            <h3 className="font-bold text-sm text-white">Google Gemini API Configuration</h3>
          </div>
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-brand-500/10 text-brand-300 border border-brand-500/20">
            BYOK Supported
          </span>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed">
          SkillBridge AI supports live neural execution via Google Gemini 1.5 Flash. If no key is set, the application operates in <strong className="text-brand-300">High-Fidelity Demo Mode</strong> using deterministic AI responses with full UI functionality.
        </p>

        <form onSubmit={handleSaveKey} className="space-y-3">
          <div>
            <label className="block text-xs font-semibold text-slate-300 pb-1">Gemini API Key</label>
            <input
              type="password"
              value={geminiKey}
              onChange={e => setGeminiKey(e.target.value)}
              placeholder="AIzaSy..."
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white font-mono placeholder-slate-500 focus:outline-none focus:border-brand-500"
            />
          </div>

          <div className="flex justify-end">
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl text-xs font-bold bg-brand-600 hover:bg-brand-500 text-white shadow-glow-blue transition-colors flex items-center space-x-1.5"
            >
              {keySaved ? <Check className="w-4 h-4" /> : <Key className="w-4 h-4" />}
              <span>{keySaved ? 'Saved!' : 'Save API Key'}</span>
            </button>
          </div>
        </form>
      </div>

      {/* Database & Demo Mode */}
      <div className="p-6 sm:p-8 rounded-2xl glass-panel border border-slate-800 space-y-4">
        <div className="flex items-center space-x-2">
          <Database className="w-5 h-5 text-purple-400" />
          <h3 className="font-bold text-sm text-white">Data & Demo State</h3>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed">
          All student activity, quiz attempts, verified badges, and scam analyses are stored persistently in the database.
        </p>

        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 flex items-center justify-between text-xs">
          <div>
            <div className="font-semibold text-slate-200">Current Profile Identity</div>
            <div className="text-[11px] text-slate-400">ID: {student?.id} ({student?.name})</div>
          </div>
          <button
            onClick={() => onNavigate('dashboard')}
            className="text-brand-400 hover:underline font-semibold"
          >
            Go to Dashboard →
          </button>
        </div>
      </div>
    </div>
  );
};
