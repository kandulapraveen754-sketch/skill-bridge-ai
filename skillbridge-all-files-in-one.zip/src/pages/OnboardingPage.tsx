import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { getCareers } from '../services/api';
import { Career } from '../types';
import { ArrowRight, ArrowLeft, CheckCircle2, Sparkles, BookOpen, Target, User } from 'lucide-react';

interface OnboardingPageProps {
  onNavigate: (page: string) => void;
}

export const OnboardingPage: React.FC<OnboardingPageProps> = ({ onNavigate }) => {
  const { register, isLoading } = useAuth();
  const [step, setStep] = useState(1);
  const [careers, setCareers] = useState<Career[]>([]);

  // Form State
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [college, setCollege] = useState('');
  const [degree, setDegree] = useState('Computer Science & Engineering');
  const [yearOfStudy, setYearOfStudy] = useState('3rd Year');
  const [targetCareerId, setTargetCareerId] = useState('ai-ml-engineer');
  const [learningGoals, setLearningGoals] = useState('Secure a software internship and build scalable web projects.');
  
  // Selected Skills & Levels
  const [selectedSkills, setSelectedSkills] = useState<{ name: string; level: 'Beginner' | 'Intermediate' | 'Advanced' }[]>([
    { name: 'Python', level: 'Beginner' },
    { name: 'Git & GitHub', level: 'Beginner' }
  ]);

  const skillOptions = [
    'Python', 'JavaScript / TypeScript', 'React & Modern UI', 'Node.js & Backend APIs',
    'Data Structures & Algorithms', 'SQL & Databases', 'Machine Learning', 'Docker',
    'Linux & Command Line', 'Cloud (AWS / GCP)', 'Mathematics & Linear Algebra'
  ];

  useEffect(() => {
    getCareers().then(res => {
      if (res.careers) setCareers(res.careers);
    });
  }, []);

  const handleToggleSkill = (skillName: string) => {
    const exists = selectedSkills.find(s => s.name === skillName);
    if (exists) {
      setSelectedSkills(selectedSkills.filter(s => s.name !== skillName));
    } else {
      setSelectedSkills([...selectedSkills, { name: skillName, level: 'Beginner' }]);
    }
  };

  const handleSkillLevelChange = (skillName: string, level: 'Beginner' | 'Intermediate' | 'Advanced') => {
    setSelectedSkills(selectedSkills.map(s => s.name === skillName ? { ...s, level } : s));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const formattedSkills = selectedSkills.map(s => ({
      name: s.name,
      level: s.level,
      verified: false,
      verificationScore: 0,
      assessed: false,
      selfReported: true,
      verifiedAt: null
    }));

    await register({
      name,
      email,
      college,
      degree,
      yearOfStudy,
      targetCareerId,
      learningGoals,
      skills: formattedSkills
    });

    onNavigate('dashboard');
  };

  return (
    <div className="min-h-screen bg-navy-950 flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="sm:mx-auto sm:w-full sm:max-w-xl">
        {/* Step Indicator */}
        <div className="text-center pb-6">
          <span className="px-3 py-1 rounded-full text-xs font-bold bg-brand-500/20 text-brand-300 border border-brand-500/30">
            Student Onboarding • Step {step} of 3
          </span>
          <h2 className="text-2xl font-black text-white tracking-tight mt-3">
            {step === 1 && "Tell us about yourself"}
            {step === 2 && "Choose your dream career target"}
            {step === 3 && "Tell us your current skills"}
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            SkillBridge AI configures all 6 agents based on your baseline knowledge
          </p>
        </div>

        <div className="p-6 sm:p-8 rounded-2xl glass-panel border border-slate-800 shadow-2xl">
          <form onSubmit={handleSubmit} className="space-y-5">
            {/* STEP 1: Academic Profile */}
            {step === 1 && (
              <div className="space-y-4 animate-fadeIn">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 pb-1">Full Name</label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={e => setName(e.target.value)}
                    placeholder="e.g. Priya Sharma"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-brand-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 pb-1">College / University</label>
                  <input
                    type="text"
                    required
                    value={college}
                    onChange={e => setCollege(e.target.value)}
                    placeholder="e.g. National Institute of Technology"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-brand-500"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 pb-1">Degree Program</label>
                    <input
                      type="text"
                      required
                      value={degree}
                      onChange={e => setDegree(e.target.value)}
                      placeholder="e.g. B.Tech CSE"
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-brand-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 pb-1">Year of Study</label>
                    <select
                      value={yearOfStudy}
                      onChange={e => setYearOfStudy(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-brand-500"
                    >
                      <option>1st Year</option>
                      <option>2nd Year</option>
                      <option>3rd Year</option>
                      <option>4th Year / Final Year</option>
                      <option>Recent Graduate / Fresher</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 pb-1">University Email</label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    placeholder="you@university.edu"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-brand-500"
                  />
                </div>

                <div className="pt-3 flex justify-end">
                  <button
                    type="button"
                    onClick={() => {
                      if (!name || !college || !email) {
                        alert('Please fill in your basic details.');
                        return;
                      }
                      setStep(2);
                    }}
                    className="px-6 py-2.5 rounded-xl text-xs font-bold bg-brand-600 hover:bg-brand-500 text-white flex items-center space-x-1.5 transition-colors shadow-glow-blue"
                  >
                    <span>Next: Choose Career Target</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            )}

            {/* STEP 2: Target Career */}
            {step === 2 && (
              <div className="space-y-4 animate-fadeIn">
                <div className="text-xs text-slate-300 font-medium">
                  Select your primary career aspiration. Agent 1 will analyze required benchmarks against your current skills.
                </div>

                <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1">
                  {careers.map(car => {
                    const isSelected = targetCareerId === car.id;
                    return (
                      <div
                        key={car.id}
                        onClick={() => setTargetCareerId(car.id)}
                        className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                          isSelected
                            ? 'bg-brand-600/20 border-brand-500 shadow-glow-blue'
                            : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div className="font-bold text-xs text-white">{car.title}</div>
                          <span className="text-[10px] text-brand-300 font-mono">{car.averageSalary}</span>
                        </div>
                        <p className="text-[11px] text-slate-400 pt-1 leading-snug">{car.description}</p>
                      </div>
                    );
                  })}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 pb-1">What is your primary learning goal?</label>
                  <input
                    type="text"
                    value={learningGoals}
                    onChange={e => setLearningGoals(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-brand-500"
                  />
                </div>

                <div className="pt-3 flex justify-between">
                  <button
                    type="button"
                    onClick={() => setStep(1)}
                    className="px-4 py-2.5 rounded-xl text-xs font-medium text-slate-400 hover:text-white flex items-center space-x-1"
                  >
                    <ArrowLeft className="w-3.5 h-3.5" />
                    <span>Back</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setStep(3)}
                    className="px-6 py-2.5 rounded-xl text-xs font-bold bg-brand-600 hover:bg-brand-500 text-white flex items-center space-x-1.5 transition-colors shadow-glow-blue"
                  >
                    <span>Next: Select Skills</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            )}

            {/* STEP 3: Current Skills */}
            {step === 3 && (
              <div className="space-y-4 animate-fadeIn">
                <div className="text-xs text-slate-300 font-medium">
                  Select technologies you know. Be honest! Agent 3 will verify your knowledge through diagnostic assessments.
                </div>

                <div className="flex flex-wrap gap-2 max-h-52 overflow-y-auto p-1">
                  {skillOptions.map(skill => {
                    const sel = selectedSkills.find(s => s.name === skill);
                    return (
                      <button
                        key={skill}
                        type="button"
                        onClick={() => handleToggleSkill(skill)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
                          sel
                            ? 'bg-brand-500/20 text-brand-300 border-brand-500/50'
                            : 'bg-slate-900 text-slate-400 border-slate-800 hover:border-slate-700'
                        }`}
                      >
                        {skill} {sel ? '✓' : '+'}
                      </button>
                    );
                  })}
                </div>

                {/* Level adjustments for selected */}
                {selectedSkills.length > 0 && (
                  <div className="space-y-2 pt-2 border-t border-slate-800">
                    <div className="text-[11px] font-bold text-slate-400">Set Proficiency Levels:</div>
                    <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
                      {selectedSkills.map(s => (
                        <div key={s.name} className="flex items-center justify-between p-2 rounded-lg bg-slate-900 border border-slate-800 text-xs">
                          <span className="font-semibold text-slate-200">{s.name}</span>
                          <select
                            value={s.level}
                            onChange={e => handleSkillLevelChange(s.name, e.target.value as any)}
                            className="bg-slate-800 border border-slate-700 rounded px-2 py-1 text-[11px] text-brand-300 focus:outline-none"
                          >
                            <option>Beginner</option>
                            <option>Intermediate</option>
                            <option>Advanced</option>
                          </select>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <div className="pt-3 flex justify-between">
                  <button
                    type="button"
                    onClick={() => setStep(2)}
                    className="px-4 py-2.5 rounded-xl text-xs font-medium text-slate-400 hover:text-white flex items-center space-x-1"
                  >
                    <ArrowLeft className="w-3.5 h-3.5" />
                    <span>Back</span>
                  </button>

                  <button
                    type="submit"
                    disabled={isLoading}
                    className="px-6 py-2.5 rounded-xl text-xs font-bold bg-gradient-to-r from-brand-600 to-purple-600 hover:from-brand-500 hover:to-purple-500 text-white flex items-center space-x-1.5 transition-all shadow-glow-blue"
                  >
                    <span>{isLoading ? 'Creating Profile...' : 'Complete & Launch Platform'}</span>
                    <Sparkles className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            )}
          </form>
        </div>
      </div>
    </div>
  );
};
