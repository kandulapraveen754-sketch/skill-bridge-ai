import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useAgent } from '../context/AgentContext';
import { getCareers, analyzeSkillGap } from '../services/api';
import { Career, SkillGapReport, EvaluatedSkill } from '../types';
import { 
  Radar, 
  Sparkles, 
  ArrowRight, 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  Layers, 
  RefreshCw, 
  Target,
  ShieldCheck,
  TrendingUp,
  Brain
} from 'lucide-react';

interface SkillGapPageProps {
  onNavigate: (page: string) => void;
}

export const SkillGapPage: React.FC<SkillGapPageProps> = ({ onNavigate }) => {
  const { student, updateProfile } = useAuth();
  const { setActiveAgent } = useAgent();

  const [careers, setCareers] = useState<Career[]>([]);
  const [selectedCareerId, setSelectedCareerId] = useState<string>('ai-ml-engineer');
  const [report, setReport] = useState<SkillGapReport | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    setActiveAgent('Skill Gap Detector (Agent 1)');
    getCareers().then(res => {
      if (res.careers) {
        setCareers(res.careers);
        if (student?.targetCareerId) {
          setSelectedCareerId(student.targetCareerId);
        }
      }
    });
  }, [student, setActiveAgent]);

  useEffect(() => {
    if (student && selectedCareerId) {
      setLoading(true);
      analyzeSkillGap(student.id, selectedCareerId)
        .then(res => {
          if (res.report) setReport(res.report);
        })
        .finally(() => setLoading(false));
    }
  }, [selectedCareerId, student]);

  const handleCareerChange = async (newCareerId: string) => {
    setSelectedCareerId(newCareerId);
    const chosen = careers.find(c => c.id === newCareerId);
    if (chosen) {
      await updateProfile({
        targetCareerId: chosen.id,
        targetCareerTitle: chosen.title
      });
    }
  };

  return (
    <div className="space-y-6 sm:space-y-8 animate-fadeIn">
      {/* Header */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-blue-950/80 via-slate-900 to-navy-900 border border-blue-500/30 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-blue-500/20 text-blue-300 border border-blue-500/30">
              Agent 1 • Differential Diagnostics
            </span>
            {report?.isDemoMode && (
              <span className="px-2 py-0.5 rounded text-[10px] font-mono text-slate-400 bg-slate-800">
                Demo Engine Active
              </span>
            )}
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight mt-1 flex items-center space-x-3">
            <Radar className="w-7 h-7 text-blue-400" />
            <span>Skill Gap Detector</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 max-w-xl mt-1">
            Compare your verified and self-reported skills against rigorous industry benchmarks.
          </p>
        </div>

        {/* Target Career Picker */}
        <div className="w-full md:w-auto">
          <label className="block text-[11px] font-bold text-slate-400 pb-1">Target Career Benchmark:</label>
          <select
            value={selectedCareerId}
            onChange={e => handleCareerChange(e.target.value)}
            className="w-full md:w-64 px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs font-semibold text-white focus:outline-none focus:border-blue-500"
          >
            {careers.map(car => (
              <option key={car.id} value={car.id}>
                {car.title}
              </option>
            ))}
          </select>
        </div>
      </div>

      {loading ? (
        <div className="p-16 text-center text-slate-400 text-sm glass-panel rounded-2xl animate-pulse">
          Agent 1 analyzing skill differential benchmarks...
        </div>
      ) : report ? (
        <div className="space-y-6">
          {/* Executive Match Banner */}
          <div className="p-6 rounded-2xl glass-panel border border-slate-800 grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
            <div className="md:col-span-4 text-center md:text-left md:border-r border-slate-800 md:pr-6">
              <span className="text-xs font-semibold text-slate-400">Readiness Benchmark Match</span>
              <div className="text-5xl font-black text-white tracking-tight mt-1">
                {report.overallMatchPercentage}%
              </div>
              <p className="text-xs text-slate-400 pt-1">
                Based on {report.summaryMetrics.totalRequired} competencies required for {report.targetCareer}.
              </p>
            </div>

            <div className="md:col-span-8 grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                <div className="text-lg font-bold text-emerald-400">{report.summaryMetrics.verifiedCount}</div>
                <div className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Verified Skills</div>
              </div>
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                <div className="text-lg font-bold text-blue-400">{report.summaryMetrics.acquiredCount}</div>
                <div className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">In Progress</div>
              </div>
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                <div className="text-lg font-bold text-amber-400">{report.summaryMetrics.weakCount}</div>
                <div className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Weak Areas</div>
              </div>
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                <div className="text-lg font-bold text-rose-400">{report.summaryMetrics.missingCount}</div>
                <div className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Missing Skills</div>
              </div>
            </div>
          </div>

          {/* AI Qualitative Analysis & Priority Recommendations */}
          <div className="p-6 rounded-2xl bg-blue-950/20 border border-blue-500/30 space-y-4">
            <div className="flex items-center space-x-2 text-xs font-bold text-blue-300">
              <Sparkles className="w-4 h-4 text-blue-400" />
              <span>AI Strategic Guidance (Agent 1)</span>
            </div>
            <p className="text-xs sm:text-sm text-slate-200 leading-relaxed">
              {report.qualitativeAnalysis.executiveSummary}
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
              <div className="space-y-2">
                <div className="text-xs font-bold text-slate-300 uppercase tracking-wider">Recommended Learning Order:</div>
                {report.qualitativeAnalysis.priorityRecommendations.map((rec, idx) => (
                  <div key={idx} className="flex items-start space-x-2 text-xs text-slate-300">
                    <span className="w-4 h-4 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5">
                      {idx + 1}
                    </span>
                    <span>{rec}</span>
                  </div>
                ))}
              </div>

              <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2 text-xs">
                <div className="text-slate-400">
                  Estimated Timeline: <strong className="text-white">{report.qualitativeAnalysis.projectedTimeToReadiness}</strong>
                </div>
                <div className="text-slate-400">
                  Target Capstone Milestone: <span className="text-blue-300 font-medium">{report.qualitativeAnalysis.keyMilestone}</span>
                </div>
                <button
                  onClick={() => onNavigate('learning')}
                  className="w-full py-2 mt-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs transition-colors flex items-center justify-center space-x-1.5"
                >
                  <span>Build Curriculum in Learning Center</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>

          {/* Granular Skill Evaluation Table */}
          <div className="p-6 rounded-2xl glass-panel border border-slate-800 space-y-4">
            <h3 className="font-bold text-sm text-white">Competency-by-Competency Matrix</h3>
            
            <div className="space-y-3">
              {report.evaluatedSkills.map((sk: EvaluatedSkill) => (
                <div key={sk.name} className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2.5">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div>
                      <div className="font-bold text-xs sm:text-sm text-white flex items-center space-x-2">
                        <span>{sk.name}</span>
                        {sk.verified && (
                          <span className="flex items-center space-x-1 text-[10px] text-emerald-400 font-bold bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20">
                            <ShieldCheck className="w-3 h-3" />
                            <span>Verified</span>
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-400 pt-0.5">
                        Current: <strong className="text-slate-200">{sk.currentLevel}</strong> • Target Benchmark: <strong className="text-blue-300">{sk.benchmark}</strong> • Weight: {sk.weight}%
                      </div>
                    </div>

                    <div className="flex items-center space-x-3">
                      <span className={`px-2.5 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider ${
                        sk.status === 'Verified' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40' :
                        sk.status === 'Acquired' ? 'bg-blue-500/20 text-blue-400 border border-blue-500/40' :
                        sk.status === 'Weak' ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40' :
                        'bg-rose-500/20 text-rose-400 border border-rose-500/40'
                      }`}>
                        {sk.status}
                      </span>
                      {sk.status !== 'Verified' && (
                        <button
                          onClick={() => onNavigate('verification')}
                          className="text-[11px] text-brand-400 hover:underline font-semibold"
                        >
                          Test Now →
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Progress bar */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                      <span>Proficiency: {sk.proficiencyScore}%</span>
                      <span>Target: {sk.targetScore}%</span>
                    </div>
                    <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                      <div 
                        className={`h-full rounded-full transition-all duration-700 ${
                          sk.status === 'Verified' ? 'bg-emerald-500' :
                          sk.status === 'Acquired' ? 'bg-blue-500' :
                          sk.status === 'Weak' ? 'bg-amber-500' : 'bg-rose-500'
                        }`}
                        style={{ width: `${sk.proficiencyScore}%` }}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
};
