import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useAgent } from '../context/AgentContext';
import { getOpportunities } from '../services/api';
import { Opportunity } from '../types';
import { 
  Briefcase, 
  Search, 
  Filter, 
  MapPin, 
  Calendar, 
  DollarSign, 
  ExternalLink, 
  ShieldAlert, 
  Sparkles, 
  CheckCircle2, 
  AlertTriangle,
  Info
} from 'lucide-react';

interface OpportunityCenterPageProps {
  onNavigate: (page: string) => void;
  onCheckOpportunitySafety: (opp: Opportunity) => void;
}

export const OpportunityCenterPage: React.FC<OpportunityCenterPageProps> = ({ 
  onNavigate, 
  onCheckOpportunitySafety 
}) => {
  const { student } = useAuth();
  const { setActiveAgent } = useAgent();

  const [opportunities, setOpportunities] = useState<Opportunity[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [isRemoteOnly, setIsRemoteOnly] = useState<boolean>(false);
  const [isBeginnerOnly, setIsBeginnerOnly] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');

  useEffect(() => {
    setActiveAgent('Opportunity Finder Agent (Agent 4)');
  }, [setActiveAgent]);

  const loadOpps = () => {
    setLoading(true);
    getOpportunities({
      category: categoryFilter,
      isRemote: isRemoteOnly ? true : undefined,
      isBeginnerFriendly: isBeginnerOnly ? true : undefined,
      search: searchQuery,
      studentId: student?.id
    })
      .then(res => {
        if (res.opportunities) setOpportunities(res.opportunities);
      })
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    loadOpps();
  }, [categoryFilter, isRemoteOnly, isBeginnerOnly, student]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    loadOpps();
  };

  return (
    <div className="space-y-6 sm:space-y-8 animate-fadeIn">
      {/* Header */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-amber-950/80 via-slate-900 to-navy-900 border border-amber-500/30 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/30">
              Agent 4 • Opportunity Matcher
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight mt-1 flex items-center space-x-3">
            <Briefcase className="w-7 h-7 text-amber-400" />
            <span>Opportunity Center</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 max-w-xl mt-1">
            Real student programs, fellowships, and hackathons ranked by compatibility with your verified skills.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => onNavigate('safety')}
            className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-500/30 transition-colors flex items-center space-x-1.5"
          >
            <ShieldAlert className="w-4 h-4" />
            <span>Scan Suspect Link</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 sm:p-5 rounded-2xl glass-panel border border-slate-800 space-y-4">
        <form onSubmit={handleSearchSubmit} className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-3 text-slate-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search internships, Google Summer of Code, hackathons..."
              className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
            />
          </div>

          <button
            type="submit"
            className="px-5 py-2.5 rounded-xl text-xs font-bold bg-amber-600 hover:bg-amber-500 text-white transition-colors"
          >
            Search Listings
          </button>
        </form>

        {/* Filter Badges */}
        <div className="flex flex-wrap items-center gap-2 pt-1 text-xs">
          <span className="text-[11px] font-bold text-slate-400 mr-2 flex items-center space-x-1">
            <Filter className="w-3.5 h-3.5" />
            <span>Filters:</span>
          </span>

          {['all', 'Fellowship', 'Internship', 'Hackathon', 'Workshop'].map(cat => (
            <button
              key={cat}
              onClick={() => setCategoryFilter(cat)}
              className={`px-3 py-1 rounded-lg text-xs font-medium border transition-colors ${
                categoryFilter === cat
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 font-bold'
                  : 'bg-slate-900 text-slate-400 border-slate-800 hover:border-slate-700'
              }`}
            >
              {cat === 'all' ? 'All Types' : cat}
            </button>
          ))}

          <button
            onClick={() => setIsRemoteOnly(!isRemoteOnly)}
            className={`px-3 py-1 rounded-lg text-xs font-medium border transition-colors ml-auto ${
              isRemoteOnly
                ? 'bg-blue-500/20 text-blue-300 border-blue-500/40 font-bold'
                : 'bg-slate-900 text-slate-400 border-slate-800'
            }`}
          >
            100% Remote {isRemoteOnly ? '✓' : ''}
          </button>

          <button
            onClick={() => setIsBeginnerOnly(!isBeginnerOnly)}
            className={`px-3 py-1 rounded-lg text-xs font-medium border transition-colors ${
              isBeginnerOnly
                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 font-bold'
                : 'bg-slate-900 text-slate-400 border-slate-800'
            }`}
          >
            Beginner-Friendly {isBeginnerOnly ? '✓' : ''}
          </button>
        </div>
      </div>

      {/* Opportunities Grid */}
      {loading ? (
        <div className="p-16 text-center text-slate-400 text-sm glass-panel rounded-2xl animate-pulse">
          Agent 4 matching opportunities with student skill profile...
        </div>
      ) : opportunities.length === 0 ? (
        <div className="p-12 text-center text-slate-400 text-xs glass-panel rounded-2xl">
          No opportunities match your current filter parameters. Try clearing filters.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {opportunities.map(opp => {
            const isSuspicious = opp.safetyScore < 40;

            return (
              <div
                key={opp.id}
                className={`p-6 rounded-2xl glass-panel border transition-all flex flex-col justify-between space-y-4 ${
                  isSuspicious 
                    ? 'border-rose-500/40 bg-rose-950/10' 
                    : 'border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="space-y-3">
                  {/* Top Bar: Match Score & Category */}
                  <div className="flex items-center justify-between text-xs">
                    <span className={`px-2.5 py-1 rounded-lg font-bold border ${
                      (opp.matchPercentage || 0) >= 80 ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' :
                      (opp.matchPercentage || 0) >= 50 ? 'bg-brand-500/20 text-brand-300 border-brand-500/40' :
                      'bg-slate-800 text-slate-400 border-slate-700'
                    }`}>
                      {opp.matchPercentage}% Profile Match
                    </span>

                    <div className="flex items-center space-x-2">
                      {opp.isBeginnerFriendly && (
                        <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                          Beginner Friendly
                        </span>
                      )}
                      <span className="text-[10px] text-slate-400 font-mono">
                        Deadline: {opp.deadline}
                      </span>
                    </div>
                  </div>

                  {/* Title & Organization */}
                  <div>
                    <h3 className="text-base font-bold text-white leading-snug">
                      {opp.title}
                    </h3>
                    <div className="text-xs text-amber-400 font-semibold pt-0.5">
                      {opp.organization} • <span className="text-slate-400 font-normal">{opp.location}</span>
                    </div>
                  </div>

                  {/* Stipend / Perks */}
                  <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 text-xs text-slate-300 flex items-center justify-between">
                    <span><strong>Compensation / Benefit:</strong> {opp.stipend}</span>
                  </div>

                  {/* Description */}
                  <p className="text-xs text-slate-400 leading-relaxed">
                    {opp.description}
                  </p>

                  {/* Required Skills & Missing tags */}
                  <div className="space-y-1.5 pt-1">
                    <div className="text-[11px] font-bold text-slate-300">Required Competencies:</div>
                    <div className="flex flex-wrap gap-1.5">
                      {(opp.requiredSkills || []).map(sk => {
                        const hasSkill = (student?.skills || []).some(s => s.name.toLowerCase().includes(sk.toLowerCase()));
                        return (
                          <span
                            key={sk}
                            className={`px-2 py-0.5 rounded text-[10px] font-medium border ${
                              hasSkill 
                                ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' 
                                : 'bg-slate-800/80 text-slate-400 border-slate-700'
                            }`}
                          >
                            {sk} {hasSkill ? '✓' : ''}
                          </span>
                        );
                      })}
                    </div>
                  </div>

                  {/* Action Tip */}
                  {opp.actionTip && (
                    <div className="text-[11px] text-slate-400 bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                      💡 <strong className="text-slate-300">Strategy Tip: </strong>{opp.actionTip}
                    </div>
                  )}

                  {/* Sample Data Notice */}
                  {opp.isSampleData && (
                    <div className="text-[10px] text-slate-500 flex items-center space-x-1 pt-1">
                      <Info className="w-3 h-3 shrink-0" />
                      <span>{opp.sampleNotice || 'Curated sample opportunity data.'}</span>
                    </div>
                  )}
                </div>

                {/* Footer Buttons */}
                <div className="pt-4 border-t border-slate-800 flex items-center justify-between gap-2 text-xs">
                  {/* Safety Checker Bridge */}
                  <button
                    onClick={() => {
                      onCheckOpportunitySafety(opp);
                      onNavigate('safety');
                    }}
                    className={`px-3 py-1.5 rounded-lg font-semibold flex items-center space-x-1.5 transition-colors ${
                      isSuspicious 
                        ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 hover:bg-rose-500/30' 
                        : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700'
                    }`}
                  >
                    <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
                    <span>Check Scam Risk</span>
                  </button>

                  <a
                    href={opp.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-4 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-500 text-white font-bold transition-colors flex items-center space-x-1"
                  >
                    <span>Official Portal</span>
                    <ExternalLink className="w-3 h-3 ml-1" />
                  </a>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
