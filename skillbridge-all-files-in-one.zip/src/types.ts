export interface Skill {
  name: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced';
  verified: boolean;
  verificationScore?: number;
  assessed: boolean;
  selfReported: boolean;
  verifiedAt?: string | null;
}

export interface Student {
  id: string;
  name: string;
  email: string;
  college: string;
  degree: string;
  yearOfStudy: string;
  targetCareerId: string;
  targetCareerTitle: string;
  learningGoals: string;
  learningStreakDays: number;
  weeklyStudyHours: number;
  preferredPace: string;
  skills: Skill[];
  activeDailyMissions: DailyMission[];
  recentActivities: AgentActivity[];
}

export interface DailyMission {
  id: string;
  agent: string;
  task: string;
  status: 'pending' | 'completed';
  xp: number;
  skill: string;
}

export interface CareerRequirement {
  name: string;
  importance: 'Core' | 'Recommended' | 'Emerging';
  weight: number;
  benchmark: 'Beginner' | 'Intermediate' | 'Advanced';
}

export interface Career {
  id: string;
  title: string;
  category: string;
  description: string;
  averageSalary: string;
  jobOutlook: string;
  skills: CareerRequirement[];
}

export interface EvaluatedSkill {
  name: string;
  importance: string;
  benchmark: string;
  currentLevel: string;
  proficiencyScore: number;
  targetScore: number;
  gap: number;
  priority: 'HIGH' | 'MEDIUM' | 'LOW';
  status: 'Verified' | 'Acquired' | 'Weak' | 'Missing';
  verified: boolean;
  weight: number;
}

export interface SkillGapReport {
  targetCareer: string;
  category: string;
  overallMatchPercentage: number;
  evaluatedSkills: EvaluatedSkill[];
  summaryMetrics: {
    totalRequired: number;
    verifiedCount: number;
    acquiredCount: number;
    weakCount: number;
    missingCount: number;
  };
  priorityToLearn: string[];
  qualitativeAnalysis: {
    executiveSummary: string;
    priorityRecommendations: string[];
    projectedTimeToReadiness: string;
    keyMilestone: string;
  };
  isDemoMode: boolean;
  aiModel: string;
  generatedAt: string;
}

export interface Lesson {
  id: string;
  title: string;
  duration: string;
  type?: string;
  resourceUrl?: string;
  resourceTitle?: string;
  summary: string;
  keyTakeaways?: string[];
  completed: boolean;
}

export interface RoadmapWeek {
  weekNumber: number;
  title: string;
  objective?: string;
  summary?: string;
  lessons: Lesson[];
}

export interface Roadmap {
  careerId: string;
  title?: string;
  paceRecommendation?: string;
  generatedAt: string;
  weeks: RoadmapWeek[];
}

export interface QuizQuestion {
  id: string;
  type: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  subtopic: string;
}

export interface Quiz {
  id: string;
  skillName: string;
  difficulty: string;
  category: string;
  passingScore: number;
  timeLimitMinutes: number;
  questions: QuizQuestion[];
}

export interface QuestionResult {
  questionId: string;
  question: string;
  selectedOptionIndex: number;
  correctOptionIndex: number;
  isCorrect: boolean;
  explanation: string;
  subtopic: string;
}

export interface VerificationBadge {
  badgeId: string;
  skillName: string;
  verificationTier: string;
  score: number;
  verifiedAt: string;
  issuer: string;
  verificationHash: string;
  status: string;
}

export interface QuizEvaluation {
  skillName: string;
  scorePercentage: number;
  passingScore: number;
  isPassed: boolean;
  correctCount: number;
  totalQuestions: number;
  questionResults: QuestionResult[];
  weakTopics: string[];
  verificationBadge: VerificationBadge | null;
  weaknessRecoveryTriggered: boolean;
  evaluatedAt: string;
}

export interface Opportunity {
  id: string;
  title: string;
  organization: string;
  category: string;
  type: string;
  location: string;
  isRemote: boolean;
  isBeginnerFriendly: boolean;
  stipend: string;
  deadline: string;
  isSampleData: boolean;
  sampleNotice?: string;
  url: string;
  logo?: string;
  description: string;
  requiredSkills: string[];
  eligibility: string;
  preparationTips: string[];
  verificationStatus: string;
  safetyScore: number;
  safetyTag: string;
  matchPercentage?: number;
  qualificationTier?: string;
  missingPrerequisites?: string[];
  actionTip?: string;
}

export interface RedFlag {
  name: string;
  severity: string;
  triggerKeywords: string[];
  explanation: string;
  recommendation: string;
}

export interface ScamAnalysisReport {
  id: string;
  studentId: string;
  targetText: string;
  url: string;
  companyName: string;
  riskScore: number;
  safetyScore: number;
  riskCategory: 'LOW_RISK' | 'MEDIUM_RISK' | 'HIGH_RISK' | 'INSUFFICIENT_INFORMATION';
  riskBadge: string;
  confidencePercentage: number;
  detectedRedFlags: RedFlag[];
  whySuspicious: string;
  safetyChecklist: string[];
  disclaimer: string;
  analyzedAt: string;
}

export interface ResumeAudit {
  id: string;
  targetRole: string;
  overallScore: number;
  atsSummary: string;
  keywordAnalysis: {
    matchedCount: number;
    totalChecked: number;
    keywords: { keyword: string; present: boolean; importance: string }[];
  };
  missingSections: string[];
  bulletRewrites: { before: string; after: string; critique: string }[];
  formattingTips: string[];
  analyzedAt: string;
}

export interface ReadinessScore {
  overallScore: number;
  tier: string;
  tierBadge: string;
  breakdown: {
    verification: { score: number; max: number; percentage: number; label: string; detail: string };
    learningRoadmap: { score: number; max: number; percentage: number; label: string; detail: string };
    skillGapClosure: { score: number; max: number; percentage: number; label: string; detail: string };
    careerAssets: { score: number; max: number; percentage: number; label: string; detail: string };
    consistency: { score: number; max: number; percentage: number; label: string; detail: string };
  };
  recommendations: string[];
}

export interface AgentActivity {
  id: string;
  agent: string;
  action: string;
  status: 'success' | 'running' | 'failed';
  timestamp: string;
  summary: string;
  studentId?: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  routedAgent?: string;
  agentData?: any;
  isDemoMode?: boolean;
  aiModel?: string;
  timestamp: string;
}
