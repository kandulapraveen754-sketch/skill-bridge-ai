import React, { useState } from 'react';
import { ReadinessScore } from '../types';
import { 
  Award, 
  HelpCircle, 
  ChevronDown, 
  ChevronUp, 
  TrendingUp, 
  ShieldCheck, 
  BookOpen, 
  CheckCircle2, 
  Briefcase 
} from 'lucide-react';

interface ReadinessGaugeProps {
  readiness: ReadinessScore | null;
  onOpenReport?: () => void;
}

export const ReadinessGauge: React.FC<ReadinessGaugeProps> = ({ readiness, onOpenReport }) => {
  const [showFormula, setShowFormula] = useState(false);

  if (!readiness) {
    return (
      <div className="p-6 rounded-2xl glass-panel animate-pulse flex items-center justify-center h-48">
        <div className="text-slate-400 text-xs font-medium">Calculating Student Readiness Score...</div>
      </div>
    );
  }

  const { overallScore, tier, tierBadge, breakdown, recommendations } = readiness;

  // SVG Circular progress values
  const radius = 54;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (overallScore / 100) * circumference;

  return (
    <div className="p-5 sm:p-6 rounded-2xl glass-panel relative overflow-hidden border border-slate-800">
      {/* Background ambient glow */}
      <div className="absolute -top-12 -right-12 w-48 h-48 bg-brand-600/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex items-center justify-between pb-4 border-b border-slate-800/80">
        <div>
          <div className="flex items-center space-x-2">
            <h3 className="font-bold text-sm text-slate-100">Student Readiness Index</h3>
            <span className={`px-2 py-0.5 text-[10px] font-bold border rounded-full ${tierBadge}`}>
              {tier}
            </span>
          </div>
          <p className="text-[11px] text-slate-400 pt-0.5">
            Transparent composite score based on verified abilities & curriculum progress
          </p>
        </div>

        <button
          onClick={() => setShowFormula(!showFormula)}
          className="flex items-center space-x-1 text-[11px] text-slate-400 hover:text-brand-300 font-medium transition-colors"
        >
          <HelpCircle className="w-3.5 h-3.5" />
          <span>Formula</span>
          {showFormula ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
        </button>
      </div>

      {/* Main Gauge & Metrics Row */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 pt-5 items-center">
        {/* Circle Meter (col 4) */}
        <div className="md:col-span-4 flex flex-col items-center justify-center">
          <div className="relative w-36 h-36 flex items-center justify-center">
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 130 130">
              {/* Background ring */}
              <circle
                cx="65"
                cy="65"
                r={radius}
                className="text-slate-800/80"
                strokeWidth="10"
                stroke="currentColor"
                fill="transparent"
              />
              {/* Animated progress ring */}
              <circle
                cx="65"
                cy="65"
                r={radius}
                className="text-brand-500 transition-all duration-1000 ease-out"
                strokeWidth="10"
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                strokeLinecap="round"
                stroke="currentColor"
                fill="transparent"
              />
            </svg>
            <div className="absolute flex flex-col items-center justify-center text-center">
              <span className="text-3xl font-black text-white tracking-tight">
                {overallScore}
              </span>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                out of 100
              </span>
            </div>
          </div>

          <div className="text-center pt-2">
            <span className="text-xs font-semibold text-slate-300">{tier}</span>
            <div className="text-[10px] text-slate-400">
              {overallScore >= 80 ? 'Ready for competitive internships' : 'Building foundational competencies'}
            </div>
          </div>
        </div>

        {/* Breakdown Progress Bars (col 8) */}
        <div className="md:col-span-8 space-y-3">
          {/* 1. Verification */}
          <div>
            <div className="flex justify-between text-xs pb-1">
              <span className="font-semibold text-slate-200 flex items-center space-x-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>Skill Verification (Quizzes)</span>
              </span>
              <span className="font-mono text-emerald-400 font-bold">
                {breakdown.verification.score} / {breakdown.verification.max} pts
              </span>
            </div>
            <div className="w-full bg-slate-800/80 h-2 rounded-full overflow-hidden">
              <div 
                className="bg-emerald-500 h-full rounded-full transition-all duration-700" 
                style={{ width: `${breakdown.verification.percentage}%` }}
              />
            </div>
            <div className="text-[10px] text-slate-400 pt-0.5">{breakdown.verification.detail}</div>
          </div>

          {/* 2. Roadmap Progress */}
          <div>
            <div className="flex justify-between text-xs pb-1">
              <span className="font-semibold text-slate-200 flex items-center space-x-1.5">
                <BookOpen className="w-3.5 h-3.5 text-purple-400" />
                <span>Curriculum & Lessons</span>
              </span>
              <span className="font-mono text-purple-400 font-bold">
                {breakdown.learningRoadmap.score} / {breakdown.learningRoadmap.max} pts
              </span>
            </div>
            <div className="w-full bg-slate-800/80 h-2 rounded-full overflow-hidden">
              <div 
                className="bg-purple-500 h-full rounded-full transition-all duration-700" 
                style={{ width: `${breakdown.learningRoadmap.percentage}%` }}
              />
            </div>
            <div className="text-[10px] text-slate-400 pt-0.5">{breakdown.learningRoadmap.detail}</div>
          </div>

          {/* 3. Skill Gap Closure */}
          <div>
            <div className="flex justify-between text-xs pb-1">
              <span className="font-semibold text-slate-200 flex items-center space-x-1.5">
                <TrendingUp className="w-3.5 h-3.5 text-blue-400" />
                <span>Skill Gap Closure</span>
              </span>
              <span className="font-mono text-blue-400 font-bold">
                {breakdown.skillGapClosure.score} / {breakdown.skillGapClosure.max} pts
              </span>
            </div>
            <div className="w-full bg-slate-800/80 h-2 rounded-full overflow-hidden">
              <div 
                className="bg-blue-500 h-full rounded-full transition-all duration-700" 
                style={{ width: `${breakdown.skillGapClosure.percentage}%` }}
              />
            </div>
            <div className="text-[10px] text-slate-400 pt-0.5">{breakdown.skillGapClosure.detail}</div>
          </div>

          {/* 4. Career Assets & Streak */}
          <div className="grid grid-cols-2 gap-3 pt-1">
            <div className="p-2 rounded-lg bg-slate-900/60 border border-slate-800">
              <div className="flex justify-between text-[11px] font-semibold text-slate-300">
                <span>Career Assets</span>
                <span className="text-cyan-400 font-mono font-bold">{breakdown.careerAssets.score}/{breakdown.careerAssets.max}</span>
              </div>
              <div className="text-[10px] text-slate-400 truncate">ATS & Mock Interview</div>
            </div>

            <div className="p-2 rounded-lg bg-slate-900/60 border border-slate-800">
              <div className="flex justify-between text-[11px] font-semibold text-slate-300">
                <span>Consistency</span>
                <span className="text-amber-400 font-mono font-bold">{breakdown.consistency.score}/{breakdown.consistency.max}</span>
              </div>
              <div className="text-[10px] text-slate-400 truncate">{breakdown.consistency.detail}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Expandable Transparent Formula Explanation */}
      {showFormula && (
        <div className="mt-5 p-4 rounded-xl bg-slate-900 border border-slate-700 text-xs space-y-2 animate-fadeIn">
          <div className="font-bold text-slate-200">How SkillBridge AI Calculates Your Readiness Score:</div>
          <p className="text-slate-400 leading-relaxed text-[11px]">
            Unlike opaque proprietary algorithms, our readiness metric is 100% mathematically transparent:
          </p>
          <ul className="list-disc list-inside space-y-1 text-[11px] text-slate-300">
            <li><strong className="text-emerald-400">30% Practical Verification:</strong> Scored objectively on interactive coding & MCQ quizzes (minimum 80% passing bar).</li>
            <li><strong className="text-purple-400">25% Roadmap Execution:</strong> Percentage of structured weekly curriculum modules and hands-on labs checked off.</li>
            <li><strong className="text-blue-400">20% Benchmark Gap Closure:</strong> Alignment of your verified skills against industry benchmarks for your target career.</li>
            <li><strong className="text-cyan-400">15% Career Assets:</strong> Resume ATS keyword scan score and performance during AI mock technical interviews.</li>
            <li><strong className="text-amber-400">10% Habits & Consistency:</strong> Consecutive study streak days and completion of daily missions.</li>
          </ul>
        </div>
      )}

      {/* Action Footer */}
      {onOpenReport && (
        <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs">
          <span className="text-slate-400 text-[11px]">Need official proof of your abilities for recruiters?</span>
          <button
            onClick={onOpenReport}
            className="px-3 py-1.5 rounded-lg bg-brand-600/30 hover:bg-brand-600/50 text-brand-300 border border-brand-500/40 font-semibold transition-colors flex items-center space-x-1.5"
          >
            <Award className="w-3.5 h-3.5" />
            <span>Generate Career Readiness Report</span>
          </button>
        </div>
      )}
    </div>
  );
};
