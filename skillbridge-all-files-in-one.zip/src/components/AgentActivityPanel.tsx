import React from 'react';
import { useAgent } from '../context/AgentContext';
import { 
  X, 
  Activity, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  Bot, 
  Sparkles,
  ArrowRight,
  RefreshCw
} from 'lucide-react';

interface AgentActivityPanelProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigateAgent: (agentPageId: string) => void;
}

export const AgentActivityPanel: React.FC<AgentActivityPanelProps> = ({ 
  isOpen, 
  onClose,
  onNavigateAgent 
}) => {
  const { activities, refreshActivities } = useAgent();

  if (!isOpen) return null;

  const getAgentColor = (agent: string) => {
    if (agent.includes('Skill Gap')) return 'text-blue-400 bg-blue-500/10 border-blue-500/30';
    if (agent.includes('Learning')) return 'text-purple-400 bg-purple-500/10 border-purple-500/30';
    if (agent.includes('Verification')) return 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30';
    if (agent.includes('Opportunity')) return 'text-amber-400 bg-amber-500/10 border-amber-500/30';
    if (agent.includes('Scam')) return 'text-rose-400 bg-rose-500/10 border-rose-500/30';
    if (agent.includes('Career')) return 'text-cyan-400 bg-cyan-500/10 border-cyan-500/30';
    return 'text-brand-400 bg-brand-500/10 border-brand-500/30';
  };

  const getAgentPageId = (agent: string) => {
    if (agent.includes('Skill Gap')) return 'skill-gap';
    if (agent.includes('Learning')) return 'learning';
    if (agent.includes('Verification')) return 'verification';
    if (agent.includes('Opportunity')) return 'opportunities';
    if (agent.includes('Scam')) return 'safety';
    if (agent.includes('Career')) return 'career';
    return 'assistant';
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/60 backdrop-blur-sm flex justify-end animate-fadeIn">
      <div 
        className="w-full max-w-md bg-navy-900 border-l border-slate-800 h-full flex flex-col shadow-2xl animate-slideLeft"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between bg-navy-950/80">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Activity className="w-4 h-4 animate-pulse" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-slate-100 flex items-center space-x-2">
                <span>Multi-Agent Live Activity Hub</span>
              </h3>
              <p className="text-[11px] text-slate-400">
                Real-time orchestration & agent execution feed
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={refreshActivities}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
              title="Refresh Activity Log"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Intelligence Hub Banner */}
        <div className="p-3 bg-brand-950/40 border-b border-brand-900/40 px-4 flex items-center justify-between text-xs">
          <div className="flex items-center space-x-2 text-brand-300">
            <Bot className="w-4 h-4" />
            <span className="font-semibold">SkillBridge Intelligence Hub</span>
          </div>
          <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-[10px] font-bold border border-emerald-500/30 flex items-center space-x-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
            <span>All 6 Agents Online</span>
          </span>
        </div>

        {/* Activities Stream */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {activities.length === 0 ? (
            <div className="text-center py-12 text-slate-400 text-xs">
              No recent agent executions recorded yet.
            </div>
          ) : (
            activities.map(act => {
              const colorClass = getAgentColor(act.agent);
              const pageId = getAgentPageId(act.agent);

              return (
                <div 
                  key={act.id} 
                  className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-slate-700 transition-all space-y-2 group"
                >
                  {/* Top Bar: Agent Badge & Status */}
                  <div className="flex items-center justify-between text-xs">
                    <span className={`px-2 py-0.5 rounded-md font-semibold text-[10px] border ${colorClass}`}>
                      {act.agent}
                    </span>
                    <div className="flex items-center space-x-1 text-[10px] text-slate-400">
                      {act.status === 'success' ? (
                        <span className="flex items-center text-emerald-400 space-x-1 font-medium">
                          <CheckCircle2 className="w-3 h-3" />
                          <span>Success</span>
                        </span>
                      ) : act.status === 'running' ? (
                        <span className="flex items-center text-amber-400 space-x-1 font-medium">
                          <Clock className="w-3 h-3 animate-spin" />
                          <span>Running</span>
                        </span>
                      ) : (
                        <span className="flex items-center text-rose-400 space-x-1 font-medium">
                          <AlertCircle className="w-3 h-3" />
                          <span>Failed</span>
                        </span>
                      )}
                      <span>•</span>
                      <span>
                        {new Date(act.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                  </div>

                  {/* Action Description */}
                  <div className="font-semibold text-xs text-slate-200">
                    {act.action}
                  </div>

                  {/* Summary / Output */}
                  <div className="text-[11px] text-slate-400 bg-slate-950/60 p-2 rounded-lg border border-slate-800/80 font-mono leading-relaxed">
                    {act.summary}
                  </div>

                  {/* Deep Link to Agent */}
                  <div className="flex justify-end pt-1">
                    <button
                      onClick={() => {
                        onNavigateAgent(pageId);
                        onClose();
                      }}
                      className="text-[11px] font-semibold text-brand-400 hover:text-brand-300 flex items-center space-x-1 group-hover:underline"
                    >
                      <span>Open {act.agent.split(' ')[0]} Agent</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
