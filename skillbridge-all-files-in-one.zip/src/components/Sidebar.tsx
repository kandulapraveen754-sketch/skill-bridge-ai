import React from 'react';
import { 
  LayoutDashboard, 
  Bot, 
  Radar, 
  GraduationCap, 
  CheckCircle2, 
  Briefcase, 
  ShieldAlert, 
  Compass, 
  UserCircle2, 
  Settings,
  Sparkles,
  Award
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface SidebarProps {
  currentPage: string;
  onNavigate: (page: string) => void;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ 
  currentPage, 
  onNavigate, 
  isOpenMobile, 
  onCloseMobile 
}) => {
  const { student } = useAuth();

  const navigationItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, badge: null },
    { id: 'assistant', label: 'AI Assistant', icon: Bot, badge: 'Hub', badgeColor: 'bg-brand-500/20 text-brand-300 border-brand-500/30' },
    { id: 'skill-gap', label: 'Skill Gap Detector', icon: Radar, badge: 'Agent 1', badgeColor: 'bg-blue-500/20 text-blue-300 border-blue-500/30' },
    { id: 'learning', label: 'Learning Center', icon: GraduationCap, badge: 'Agent 2', badgeColor: 'bg-purple-500/20 text-purple-300 border-purple-500/30' },
    { id: 'verification', label: 'Skill Verification', icon: CheckCircle2, badge: 'Agent 3', badgeColor: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30' },
    { id: 'opportunities', label: 'Opportunities', icon: Briefcase, badge: 'Agent 4', badgeColor: 'bg-amber-500/20 text-amber-300 border-amber-500/30' },
    { id: 'safety', label: 'Scam Detection', icon: ShieldAlert, badge: 'Agent 5', badgeColor: 'bg-rose-500/20 text-rose-300 border-rose-500/30' },
    { id: 'career', label: 'Career Guidance', icon: Compass, badge: 'Agent 6', badgeColor: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30' },
    { id: 'profile', label: 'Profile', icon: UserCircle2, badge: null },
    { id: 'settings', label: 'Settings', icon: Settings, badge: null },
  ];

  const handleSelect = (id: string) => {
    onNavigate(id);
    onCloseMobile();
  };

  const verifiedCount = (student?.skills || []).filter(s => s.verified).length;

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpenMobile && (
        <div 
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 lg:hidden"
          onClick={onCloseMobile}
        />
      )}

      {/* Sidebar Container */}
      <aside className={`
        fixed top-16 bottom-0 left-0 z-40 w-64 bg-navy-900/95 border-r border-slate-800 flex flex-col justify-between
        transition-transform duration-300 ease-in-out lg:translate-x-0
        ${isOpenMobile ? 'translate-x-0' : '-translate-x-full'}
      `}>
        {/* Navigation list */}
        <div className="flex-1 overflow-y-auto px-3 py-4 space-y-1.5">
          <div className="px-3 pb-2 text-[10px] font-bold uppercase tracking-wider text-slate-400">
            Ecosystem Navigation
          </div>

          {navigationItems.map(item => {
            const Icon = item.icon;
            const isActive = currentPage === item.id;

            return (
              <button
                key={item.id}
                onClick={() => handleSelect(item.id)}
                className={`
                  w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-medium transition-all group
                  ${isActive
                    ? 'bg-gradient-to-r from-brand-600/30 to-blue-600/10 text-brand-300 border border-brand-500/40 shadow-glow-blue'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/60 border border-transparent'
                  }
                `}
              >
                <div className="flex items-center space-x-3 truncate">
                  <Icon className={`w-4 h-4 shrink-0 transition-colors ${isActive ? 'text-brand-400' : 'text-slate-400 group-hover:text-slate-200'}`} />
                  <span className="truncate">{item.label}</span>
                </div>
                {item.badge && (
                  <span className={`px-1.5 py-0.5 text-[9px] font-bold border rounded uppercase tracking-wide shrink-0 ${item.badgeColor || 'bg-slate-800 text-slate-300 border-slate-700'}`}>
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Footer: Quick Readiness & Verified Badges */}
        {student && (
          <div className="p-3 border-t border-slate-800/80 bg-navy-950/60">
            <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-slate-400 font-medium">Verified Badges</span>
                <span className="flex items-center space-x-1 font-bold text-emerald-400">
                  <Award className="w-3.5 h-3.5" />
                  <span>{verifiedCount} Verified</span>
                </span>
              </div>
              <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                <div 
                  className="bg-gradient-to-r from-brand-500 to-emerald-400 h-full rounded-full transition-all duration-500"
                  style={{ width: `${Math.min(100, (verifiedCount / 5) * 100)}%` }}
                />
              </div>
              <div className="flex items-center justify-between text-[10px] text-slate-400 pt-0.5">
                <span>Goal: {student.targetCareerTitle?.split(' ')[0] || 'Career'}</span>
                <button 
                  onClick={() => handleSelect('verification')}
                  className="text-brand-400 hover:underline font-semibold"
                >
                  Verify more →
                </button>
              </div>
            </div>
          </div>
        )}
      </aside>
    </>
  );
};
