import React, { useState, useEffect } from 'react';
import { X, Printer, Download, Award, ShieldCheck, CheckCircle2, TrendingUp, Calendar, User } from 'lucide-react';
import { getCareerReport } from '../services/api';
import { useAuth } from '../context/AuthContext';

interface CareerReportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CareerReportModal: React.FC<CareerReportModalProps> = ({ isOpen, onClose }) => {
  const { student } = useAuth();
  const [reportData, setReportData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (isOpen) {
      setLoading(true);
      getCareerReport(student?.id)
        .then(res => {
          if (res.report) setReportData(res.report);
        })
        .finally(() => setLoading(false));
    }
  }, [isOpen, student?.id]);

  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto animate-fadeIn">
      <div 
        className="w-full max-w-3xl bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl overflow-hidden my-6 print:border-none print:shadow-none print:bg-white print:text-black"
        onClick={e => e.stopPropagation()}
      >
        {/* Header (No print controls) */}
        <div className="no-print p-4 sm:p-5 border-b border-slate-800 bg-navy-950 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Award className="w-5 h-5 text-brand-400" />
            <h3 className="font-bold text-sm text-slate-100">Official SkillBridge AI Career Readiness Dossier</h3>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={handlePrint}
              className="px-3 py-1.5 rounded-lg bg-brand-600 hover:bg-brand-500 text-white text-xs font-semibold flex items-center space-x-1.5 transition-colors shadow-glow-blue"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / Save as PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Report Document Body */}
        {loading || !reportData ? (
          <div className="p-12 text-center text-slate-400 text-sm">Compiling verified candidate dossier...</div>
        ) : (
          <div className="p-6 sm:p-8 space-y-6 print:p-0 print:space-y-4">
            {/* Document Header */}
            <div className="border-b border-slate-800 print:border-slate-300 pb-5 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <div>
                <div className="text-xl font-extrabold text-white print:text-black tracking-tight">
                  SkillBridge<span className="text-brand-400">.AI</span> Candidate Evaluation Report
                </div>
                <div className="text-xs text-slate-400 print:text-slate-600">
                  Document ID: SKB-RPT-{student?.id?.substring(0, 8).toUpperCase()}-{new Date().getFullYear()}
                </div>
              </div>
              <div className="text-right">
                <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-400 print:border print:border-emerald-600 text-xs font-bold border border-emerald-500/30">
                  {reportData.tier} ({reportData.readinessScore}/100)
                </span>
                <div className="text-[10px] text-slate-400 print:text-slate-500 pt-1">
                  Issued: {new Date(reportData.generatedAt).toLocaleDateString()}
                </div>
              </div>
            </div>

            {/* Candidate & Career Summary */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-slate-950/60 print:bg-slate-100 p-4 rounded-xl border border-slate-800 print:border-slate-300 text-xs">
              <div className="space-y-1">
                <div className="font-bold text-slate-300 print:text-slate-700 uppercase text-[10px] tracking-wider">Candidate Profile</div>
                <div className="text-sm font-bold text-white print:text-black">{reportData.studentProfile.name}</div>
                <div className="text-slate-400 print:text-slate-600">{reportData.studentProfile.college}</div>
                <div className="text-slate-400 print:text-slate-600">{reportData.studentProfile.degree} ({reportData.studentProfile.yearOfStudy})</div>
              </div>
              <div className="space-y-1">
                <div className="font-bold text-slate-300 print:text-slate-700 uppercase text-[10px] tracking-wider">Target Career Benchmark</div>
                <div className="text-sm font-bold text-brand-300 print:text-brand-700">{reportData.targetCareer.title}</div>
                <div className="text-slate-400 print:text-slate-600">Domain: {reportData.targetCareer.category}</div>
                <div className="text-slate-400 print:text-slate-600">Industry Outlook: {reportData.targetCareer.outlook}</div>
              </div>
            </div>

            {/* Transparent Score Breakdown */}
            <div className="space-y-2">
              <div className="text-xs font-bold text-slate-200 print:text-black uppercase tracking-wider">
                Objective Readiness Scorecard
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-center text-xs">
                {Object.entries(reportData.scoreBreakdown || {}).map(([key, val]: any) => (
                  <div key={key} className="p-3 rounded-lg bg-slate-950 print:bg-slate-50 border border-slate-800 print:border-slate-300">
                    <div className="text-[10px] text-slate-400 print:text-slate-600">{val.label}</div>
                    <div className="text-base font-bold text-white print:text-black mt-1">{val.score}/{val.max}</div>
                    <div className="text-[9px] text-slate-500">{val.percentage}%</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Three-Tier Skills Inventory (Verified vs Assessed vs Self-Reported) */}
            <div className="space-y-3">
              <div className="text-xs font-bold text-slate-200 print:text-black uppercase tracking-wider">
                Audited Skills Inventory
              </div>

              {/* Verified */}
              <div className="p-3 rounded-xl bg-emerald-950/20 print:bg-emerald-50 border border-emerald-500/30">
                <div className="text-xs font-bold text-emerald-400 print:text-emerald-700 flex items-center space-x-1.5 pb-2">
                  <ShieldCheck className="w-4 h-4" />
                  <span>Verified Skills (Tested & Certified Score &ge; 80%)</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {(reportData.skillsInventory.verifiedSkills || []).length === 0 ? (
                    <span className="text-xs text-slate-500">None verified yet.</span>
                  ) : (
                    reportData.skillsInventory.verifiedSkills.map((s: any, idx: number) => (
                      <span key={idx} className="px-2.5 py-1 rounded-md text-xs font-medium bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                        {s.name} ({s.verificationScore || 85}%)
                      </span>
                    ))
                  )}
                </div>
              </div>

              {/* Assessed */}
              <div className="p-3 rounded-xl bg-blue-950/20 print:bg-blue-50 border border-blue-500/30">
                <div className="text-xs font-bold text-blue-400 print:text-blue-700 pb-2">
                  Assessed Skills (50% - 79% Diagnostic Bar)
                </div>
                <div className="flex flex-wrap gap-2">
                  {(reportData.skillsInventory.assessedSkills || []).length === 0 ? (
                    <span className="text-xs text-slate-500">None in this tier.</span>
                  ) : (
                    reportData.skillsInventory.assessedSkills.map((s: any, idx: number) => (
                      <span key={idx} className="px-2.5 py-1 rounded-md text-xs font-medium bg-blue-500/20 text-blue-300 border border-blue-500/40">
                        {s.name} ({s.verificationScore || 60}%)
                      </span>
                    ))
                  )}
                </div>
              </div>

              {/* Self-reported */}
              <div className="p-3 rounded-xl bg-slate-900 print:bg-slate-100 border border-slate-800 print:border-slate-300">
                <div className="text-xs font-bold text-slate-400 print:text-slate-600 pb-2">
                  Self-Reported Skills (Unverified by Testing)
                </div>
                <div className="flex flex-wrap gap-2">
                  {(reportData.skillsInventory.selfReportedSkills || []).map((s: any, idx: number) => (
                    <span key={idx} className="px-2.5 py-1 rounded-md text-xs text-slate-400 bg-slate-800 print:bg-slate-200 border border-slate-700">
                      {s.name} ({s.level || 'Beginner'})
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Strategic Recommendations */}
            <div className="space-y-1.5 pt-2">
              <div className="text-xs font-bold text-slate-200 print:text-black uppercase tracking-wider">
                Actionable Next Steps
              </div>
              <ul className="list-disc list-inside space-y-1 text-xs text-slate-300 print:text-slate-700">
                {reportData.recommendations.map((rec: string, idx: number) => (
                  <li key={idx}>{rec}</li>
                ))}
              </ul>
            </div>

            {/* Disclaimer */}
            <div className="text-[10px] text-slate-500 print:text-slate-400 border-t border-slate-800 print:border-slate-300 pt-3">
              {reportData.disclaimer}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
