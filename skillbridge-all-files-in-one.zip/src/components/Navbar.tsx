import React from 'react';
import { useAuth } from '../context/AuthContext';
import { useAgent } from '../context/AgentContext';
import { 
  Sparkles, 
  Activity, 
  Flame, 
  User, 
  ShieldCheck, 
  Bot,
  LogOut,
  ExternalLink
} from 'lucide-react';

interface NavbarProps {
  onOpenActivityPanel: () => void;
  currentPage: string;
  onNavigate: (page: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenActivityPanel, currentPage, onNavigate }) => {
  const { student, logout, isDemoAccount } = useAuth();
  const { activities, activeAgent } = useAgent();

  const recentCount = activities.length;

  return (
    <header className="sticky top-0 z-30 h-16 border-b border-slate-800 bg-navy-950/80 backdrop-blur-md px-4 sm:px-6 flex items-center justify-between">
      {/* Brand Logo & Name */}
      <div className="flex items-center space-x-3 cursor-pointer" onClick={() => onNavigate('dashboard')}>
        <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-br from-brand-600 via-blue-600 to-purple-600 shadow-glow-blue">
          <svg className="w-6 h-6 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M4 19c4-4 8-4 12 0" />
            <path d="M8 15c2-2 4-2 6 0" />
            <path d="M12 3v8" />
            <circle cx="12" cy="3" r="1.5" fill="currentColor" />
          </svg>
          <span className="absolute -top-1 -right-1 flex h-3 w-3">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3 w-3 bg-brand-500"></span>
          </span>
        </div>
        <div>
          <div className="flex items-center space-x-2">
            <span className="font-extrabold text-lg sm:text-xl tracking-tight bg-gradient-to-r from-white via-slate-100 to-slate-400 bg-clip-text text-transparent">
              SkillBridge<span className="text-brand-400">.AI</span>
            </span>
            <span className="hidden sm:inline-block px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider bg-brand-500/20 text-brand-400 border border-brand-500/30 rounded">
              v1.0
            </span>
          </div>
          <p className="hidden md:block text-[11px] text-slate-400 tracking-wide">
            Connect Skills. Discover Opportunities. Build Your Future.
          </p>
        </div>
      </div>

      {/* Middle: Active Agent Indicator */}
      <div className="hidden lg:flex items-center space-x-2 px-3 py-1.5 rounded-full bg-slate-900/80 border border-slate-800 text-xs text-slate-300">
        <Bot className="w-3.5 h-3.5 text-brand-400 animate-pulse" />
        <span>Active Coordinator:</span>
        <span className="font-medium text-brand-300">
          {activeAgent || 'SkillBridge Intelligence Hub'}
        </span>
      </div>

      {/* Right Controls */}
      <div className="flex items-center space-x-3 sm:space-x-4">
        {/* Streak Counter */}
        {student && (
          <div className="flex items-center space-x-1.5 px-2.5 py-1 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs font-semibold">
            <Flame className="w-4 h-4 fill-amber-500 text-amber-500 animate-bounce" />
            <span>{student.learningStreakDays || 1}d Streak</span>
          </div>
        )}

        {/* Live Activity Feed Button */}
        <button
          onClick={onOpenActivityPanel}
          className="relative flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-medium transition-colors"
          title="Open Live Multi-Agent Activity Panel"
        >
          <Activity className="w-3.5 h-3.5 text-emerald-400" />
          <span className="hidden sm:inline">Agent Feed</span>
          {recentCount > 0 && (
            <span className="ml-1 px-1.5 py-0.2 text-[10px] font-bold rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              {recentCount}
            </span>
          )}
        </button>

        {/* User Pill / Login */}
        {student ? (
          <div className="flex items-center space-x-2 pl-2 border-l border-slate-800">
            <button
              onClick={() => onNavigate('profile')}
              className="flex items-center space-x-2 p-1 sm:px-2 sm:py-1 rounded-lg hover:bg-slate-800/60 transition-colors text-left"
            >
              <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-brand-600 to-purple-600 flex items-center justify-center text-xs font-bold text-white shadow-sm">
                {student.name.charAt(0)}
              </div>
              <div className="hidden xl:block">
                <div className="text-xs font-semibold text-slate-200 truncate max-w-[110px]">
                  {student.name}
                </div>
                <div className="text-[10px] text-brand-400 truncate max-w-[110px]">
                  {student.targetCareerTitle || 'Student'}
                </div>
              </div>
            </button>
            <button
              onClick={logout}
              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
              title="Sign Out"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <button
            onClick={() => onNavigate('login')}
            className="px-3.5 py-1.5 rounded-lg bg-brand-600 hover:bg-brand-500 text-white text-xs font-medium transition-colors shadow-glow-blue"
          >
            Sign In
          </button>
        )}
      </div>
    </header>
  );
};
