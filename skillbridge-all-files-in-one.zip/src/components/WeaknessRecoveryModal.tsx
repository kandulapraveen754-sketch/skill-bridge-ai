import React, { useState } from 'react';
import { X, RefreshCw, BookOpen, CheckCircle, ExternalLink, Lightbulb, Sparkles } from 'lucide-react';

interface WeaknessRecoveryModalProps {
  isOpen: boolean;
  onClose: () => void;
  recoveryPlan: any;
  onStartRetest: (skillName: string) => void;
}

export const WeaknessRecoveryModal: React.FC<WeaknessRecoveryModalProps> = ({
  isOpen,
  onClose,
  recoveryPlan,
  onStartRetest
}) => {
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, number>>({});
  const [revealed, setRevealed] = useState<Record<string, boolean>>({});

  if (!isOpen || !recoveryPlan) return null;

  const handleSelect = (qId: string, optIdx: number) => {
    setSelectedAnswers(prev => ({ ...prev, [qId]: optIdx }));
    setRevealed(prev => ({ ...prev, [qId]: true }));
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto animate-fadeIn">
      <div 
        className="w-full max-w-2xl bg-navy-900 border border-purple-500/40 rounded-2xl shadow-2xl overflow-hidden my-8"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 border-b border-slate-800 bg-gradient-to-r from-purple-950/60 to-navy-950/90 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-purple-500/20 border border-purple-500/30 flex items-center justify-center text-purple-400">
              <Lightbulb className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="font-bold text-base text-white">Weakness Recovery System</h3>
                <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/40">
                  Targeted Reinforcement
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Overcoming bottleneck: <strong className="text-purple-300">{recoveryPlan.weakTopic}</strong>
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">
          {/* Diagnosis */}
          <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-1.5">
            <div className="text-xs font-bold text-purple-400 uppercase tracking-wider flex items-center space-x-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Conceptual Diagnosis</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              {recoveryPlan.diagnosis}
            </p>
          </div>

          {/* Simplified Breakdown */}
          <div className="space-y-2">
            <div className="text-xs font-bold text-slate-200">Simplified Step-by-Step Breakdown:</div>
            <div className="space-y-2">
              {(recoveryPlan.simplifiedBreakdown || []).map((step: string, idx: number) => (
                <div key={idx} className="flex items-start space-x-2 text-xs text-slate-300 bg-slate-900/40 p-2.5 rounded-lg border border-slate-800">
                  <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>{step}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Targeted Free Resources */}
          {recoveryPlan.targetedFreeResources && recoveryPlan.targetedFreeResources.length > 0 && (
            <div className="space-y-2">
              <div className="text-xs font-bold text-slate-200">Curated Free Explanations:</div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {recoveryPlan.targetedFreeResources.map((res: any, idx: number) => (
                  <a
                    key={idx}
                    href={res.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-3 rounded-xl bg-slate-900/80 hover:bg-slate-800/80 border border-slate-800 hover:border-purple-500/40 transition-colors flex items-center justify-between group"
                  >
                    <div>
                      <div className="text-xs font-semibold text-slate-200 group-hover:text-purple-300 transition-colors">
                        {res.title}
                      </div>
                      <div className="text-[10px] text-slate-400">{res.type}</div>
                    </div>
                    <ExternalLink className="w-4 h-4 text-slate-500 group-hover:text-purple-400 shrink-0 ml-2" />
                  </a>
                ))}
              </div>
            </div>
          )}

          {/* Easier Diagnostic Practice Questions */}
          {recoveryPlan.easierPracticeQuestions && recoveryPlan.easierPracticeQuestions.length > 0 && (
            <div className="space-y-3 pt-2">
              <div className="text-xs font-bold text-slate-200">
                Confidence-Building Practice ({recoveryPlan.easierPracticeQuestions.length} Questions):
              </div>
              {recoveryPlan.easierPracticeQuestions.map((q: any, qIdx: number) => {
                const isAnswered = revealed[q.id];
                const selectedOpt = selectedAnswers[q.id];

                return (
                  <div key={q.id || qIdx} className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2.5">
                    <div className="text-xs font-semibold text-slate-200">
                      {qIdx + 1}. {q.question}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {q.options.map((opt: string, optIdx: number) => {
                        const isCorrect = optIdx === q.correctIndex;
                        const isChosen = selectedOpt === optIdx;

                        let btnStyle = "bg-slate-800/60 text-slate-300 hover:bg-slate-800 border-slate-700";
                        if (isAnswered) {
                          if (isCorrect) btnStyle = "bg-emerald-500/20 text-emerald-300 border-emerald-500/40 font-bold";
                          else if (isChosen) btnStyle = "bg-rose-500/20 text-rose-300 border-rose-500/40";
                        }

                        return (
                          <button
                            key={optIdx}
                            disabled={isAnswered}
                            onClick={() => handleSelect(q.id, optIdx)}
                            className={`p-2.5 rounded-lg text-left text-xs border transition-all ${btnStyle}`}
                          >
                            {opt}
                          </button>
                        );
                      })}
                    </div>

                    {isAnswered && (
                      <div className="p-2.5 rounded-lg bg-slate-950/80 text-[11px] text-slate-300 border border-slate-800">
                        <strong className="text-purple-400">Explanation: </strong>
                        {q.explanation}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-navy-950 flex items-center justify-between">
          <div className="text-[11px] text-slate-400">
            {recoveryPlan.readinessToRetest || "Ready to prove your mastery?"}
          </div>
          <div className="flex space-x-2">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-medium text-slate-300 hover:bg-slate-800 transition-colors"
            >
              Done Reviewing
            </button>
            <button
              onClick={() => {
                onClose();
                onStartRetest(recoveryPlan.weakTopic);
              }}
              className="px-4 py-2 rounded-xl text-xs font-semibold bg-purple-600 hover:bg-purple-500 text-white shadow-glow-purple transition-all"
            >
              Retake Verification Test →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
