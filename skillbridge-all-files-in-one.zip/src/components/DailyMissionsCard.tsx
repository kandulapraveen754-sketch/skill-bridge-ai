import React, { useState } from 'react';
import { DailyMission } from '../types';
import { Target, CheckCircle2, Circle, Flame, Sparkles } from 'lucide-react';
import { completeMission } from '../services/api';
import { useAuth } from '../context/AuthContext';

interface DailyMissionsCardProps {
  missions: DailyMission[];
  onMissionCompleted?: () => void;
  onNavigateAgent?: (agentId: string) => void;
}

export const DailyMissionsCard: React.FC<DailyMissionsCardProps> = ({ 
  missions, 
  onMissionCompleted,
  onNavigateAgent 
}) => {
  const { student, refreshStudent } = useAuth();
  const [loadingId, setLoadingId] = useState<string | null>(null);

  const handleToggle = async (m: DailyMission) => {
    if (m.status === 'completed' || loadingId) return;
    setLoadingId(m.id);
    try {
      await completeMission(m.id, student?.id);
      await refreshStudent();
      if (onMissionCompleted) onMissionCompleted();
    } catch (err) {
      console.error('Failed to complete mission:', err);
    } finally {
      setLoadingId(null);
    }
  };

  const completedCount = missions.filter(m => m.status === 'completed').length;
  const progressPercent = Math.round((completedCount / (missions.length || 1)) * 100);

  const getAgentPage = (agent: string) => {
    if (agent.includes('Skill Gap')) return 'skill-gap';
    if (agent.includes('Learning')) return 'learning';
    if (agent.includes('Verification')) return 'verification';
    if (agent.includes('Opportunity')) return 'opportunities';
    if (agent.includes('Scam')) return 'safety';
    if (agent.includes('Career')) return 'career';
    return 'dashboard';
  };

  return (
    <div className="p-5 sm:p-6 rounded-2xl glass-panel border border-slate-800 space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2.5">
          <div className="w-8 h-8 rounded-lg bg-brand-500/20 border border-brand-500/30 flex items-center justify-center text-brand-400">
            <Target className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-bold text-sm text-slate-100">Personalized Daily Missions</h3>
            <p className="text-[11px] text-slate-400">3 bite-sized steps targeting your active skill gaps</p>
          </div>
        </div>

        <div className="text-right">
          <span className="text-xs font-mono font-bold text-brand-400">{completedCount} of {missions.length} Done</span>
          <div className="w-20 bg-slate-800 h-1.5 rounded-full mt-1 overflow-hidden">
            <div 
              className="bg-brand-500 h-full rounded-full transition-all duration-500"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>
      </div>

      {/* Mission Items */}
      <div className="space-y-2.5">
        {missions.map(m => {
          const isDone = m.status === 'completed';
          const isLoading = loadingId === m.id;

          return (
            <div
              key={m.id}
              onClick={() => handleToggle(m)}
              className={`
                p-3 rounded-xl border transition-all cursor-pointer flex items-center justify-between group
                ${isDone 
                  ? 'bg-slate-900/40 border-slate-800/60 opacity-75' 
                  : 'bg-slate-900/80 hover:bg-slate-800/80 border-slate-800 hover:border-slate-700'
                }
              `}
            >
              <div className="flex items-center space-x-3 pr-2">
                <button
                  disabled={isDone || isLoading}
                  className="text-slate-400 hover:text-brand-400 focus:outline-none shrink-0"
                >
                  {isDone ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-400 fill-emerald-500/20" />
                  ) : (
                    <Circle className={`w-5 h-5 ${isLoading ? 'animate-spin text-brand-400' : 'text-slate-500 group-hover:text-slate-300'}`} />
                  )}
                </button>

                <div>
                  <div className={`text-xs font-medium ${isDone ? 'line-through text-slate-500' : 'text-slate-200'}`}>
                    {m.task}
                  </div>
                  <div className="flex items-center space-x-2 text-[10px] text-slate-400 pt-0.5">
                    <span className="text-brand-400 font-semibold">{m.agent}</span>
                    <span>•</span>
                    <span className="text-slate-400">{m.skill}</span>
                  </div>
                </div>
              </div>

              <div className="shrink-0 flex items-center space-x-2">
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20">
                  +{m.xp} XP
                </span>
                {!isDone && onNavigateAgent && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onNavigateAgent(getAgentPage(m.agent));
                    }}
                    className="hidden sm:inline text-[10px] text-slate-400 hover:text-white underline"
                  >
                    Go →
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
