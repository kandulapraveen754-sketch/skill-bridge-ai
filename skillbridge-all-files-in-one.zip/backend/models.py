from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any

class Skill(BaseModel):
    name: str
    level: str = "Beginner" # Beginner, Intermediate, Advanced
    verified: bool = False
    verificationScore: int = 0
    assessed: bool = False
    selfReported: bool = True
    verifiedAt: Optional[str] = None

class DailyMission(BaseModel):
    id: str
    agent: str
    task: str
    status: str = "pending" # pending, completed
    xp: int = 50
    skill: str = "General"

class StudentProfile(BaseModel):
    id: str
    name: str
    email: str
    college: str
    degree: str
    yearOfStudy: str
    targetCareerId: str
    targetCareerTitle: str
    learningGoals: str
    learningStreakDays: int = 1
    weeklyStudyHours: int = 10
    preferredPace: str = "Standard"
    skills: List[Skill] = []
    activeDailyMissions: List[DailyMission] = []
    recentActivities: List[Dict[str, Any]] = []

class SkillGapAnalysisRequest(BaseModel):
    studentId: str = "std-alex-chen"
    targetCareerId: Optional[str] = None

class ScamAnalysisRequest(BaseModel):
    text: Optional[str] = None
    url: Optional[str] = None
    companyName: Optional[str] = None
    studentId: str = "std-alex-chen"

class ResumeAuditRequest(BaseModel):
    resumeText: str
    targetCareerTitle: Optional[str] = "Software Engineer"
    studentId: str = "std-alex-chen"

class MockInterviewRequest(BaseModel):
    targetCareerTitle: Optional[str] = "AI / Machine Learning Engineer"
    questionType: str = "technical"
    count: int = 2

class EvaluateInterviewRequest(BaseModel):
    question: str
    studentAnswer: str
    targetRole: Optional[str] = "Software Engineer"

class ChatRequest(BaseModel):
    message: str
    studentId: str = "std-alex-chen"
    conversationHistory: List[Dict[str, Any]] = []
