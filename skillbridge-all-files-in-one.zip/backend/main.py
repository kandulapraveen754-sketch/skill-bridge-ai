import os
import json
import time
from datetime import datetime
from typing import Optional, Dict, Any, List
from fastapi import FastAPI, HTTPException, Query, Body
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI(
    title="SkillBridge AI - Multi-Agent Backend",
    description="Connect Skills. Discover Opportunities. Build Your Future. 6 Specialized AI Agents.",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

DATA_PATH = os.path.join(os.path.dirname(__file__), "../server/db/skillbridge_data.json")

def load_db():
    if os.path.exists(DATA_PATH):
        with open(DATA_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    return {
        "users": [],
        "students": {},
        "careers": [],
        "opportunities": [],
        "quizzes": [],
        "scamPatterns": [],
        "scamAnalyses": [],
        "resumeAnalyses": [],
        "activityLogs": []
    }

def save_db(data):
    with open(DATA_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

def log_activity(agent: str, action: str, summary: str, student_id: str = "std-alex-chen", status: str = "success"):
    db = load_db()
    entry = {
        "id": f"act-{int(time.time()*1000)}",
        "agent": agent,
        "action": action,
        "status": status,
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "summary": summary,
        "studentId": student_id
    }
    db.setdefault("activityLogs", []).insert(0, entry)
    if len(db["activityLogs"]) > 50:
        db["activityLogs"].pop()
    save_db(db)
    return entry

@app.get("/api/health")
def health_check():
    api_key = os.environ.get("GEMINI_API_KEY", "")
    return {
        "status": "ok",
        "platform": "SkillBridge AI (FastAPI Edition)",
        "version": "1.0.0",
        "aiProvider": "Gemini 1.5 Flash (Configured)" if api_key else "Local Intelligence Engine (Demo Mode Active)",
        "registeredAgents": [
            "Skill Gap Detector",
            "Personalized Learning Agent",
            "Skill Verification Agent",
            "Opportunity Finder Agent",
            "Scam Detection Agent",
            "Career Guidance Agent",
            "SkillBridge Assistant",
            "SkillBridge Intelligence Hub"
        ],
        "timestamp": datetime.utcnow().isoformat() + "Z"
    }

@app.post("/api/auth/login")
def login(payload: Dict[str, Any] = Body(...)):
    db = load_db()
    email = payload.get("email", "alex.chen@university.edu")
    user = next((u for u in db.get("users", []) if u.get("email", "").lower() == email.lower()), None)
    if not user:
        user = db.get("users", [{}])[0] if db.get("users") else {
            "id": "user-demo-1",
            "email": email,
            "name": "Alex Chen",
            "studentId": "std-alex-chen"
        }
    student = db.get("students", {}).get(user.get("studentId", "std-alex-chen"))
    return {
        "success": True,
        "token": f"skb_jwt_{user.get('id')}_{int(time.time())}",
        "user": user,
        "student": student
    }

@app.get("/api/student/profile")
def get_profile(studentId: str = "std-alex-chen"):
    db = load_db()
    student = db.get("students", {}).get(studentId)
    if not student and db.get("students"):
        student = list(db["students"].values())[0]
    return {"success": True, "student": student}

@app.get("/api/student/readiness")
def get_readiness(studentId: str = "std-alex-chen"):
    db = load_db()
    student = db.get("students", {}).get(studentId, {})
    skills = student.get("skills", [])
    verified_count = sum(1 for s in skills if s.get("verified"))
    
    # Calculate transparent score
    verification_score = min(30, verified_count * 15)
    roadmap_score = 18
    gap_score = 16
    career_score = 12
    consistency_score = min(10, (student.get("learningStreakDays", 1) // 2) + 4)
    overall = verification_score + roadmap_score + gap_score + career_score + consistency_score

    tier = "Early Explorer"
    badge = "bg-blue-500/20 text-blue-400 border-blue-500/30"
    if overall >= 85:
        tier = "Industry Ready"
        badge = "bg-emerald-500/20 text-emerald-400 border-emerald-500/30"
    elif overall >= 70:
        tier = "Internship Qualified"
        badge = "bg-brand-500/20 text-brand-300 border-brand-500/30"
    elif overall >= 50:
        tier = "Active Builder"
        badge = "bg-purple-500/20 text-purple-300 border-purple-500/30"

    return {
        "success": True,
        "readiness": {
            "overallScore": overall,
            "tier": tier,
            "tierBadge": badge,
            "breakdown": {
                "verification": {"score": verification_score, "max": 30, "percentage": int((verification_score/30)*100), "label": "Skill Verification", "detail": f"{verified_count} skills verified via objective testing"},
                "learningRoadmap": {"score": roadmap_score, "max": 25, "percentage": int((roadmap_score/25)*100), "label": "Roadmap Progress", "detail": "Curriculum milestone execution"},
                "skillGapClosure": {"score": gap_score, "max": 20, "percentage": int((gap_score/20)*100), "label": "Skill Gap Closure", "detail": "Alignment with target benchmark prerequisites"},
                "careerAssets": {"score": career_score, "max": 15, "percentage": int((career_score/15)*100), "label": "Career Assets & Resume", "detail": "ATS score and mock interview feedback"},
                "consistency": {"score": consistency_score, "max": 10, "percentage": int((consistency_score/10)*100), "label": "Habits & Streaks", "detail": f"{student.get('learningStreakDays', 1)}d streak"}
            },
            "recommendations": [
                "Take the Python Core Quiz to claim a verified badge.",
                "Complete Week 1 milestone in the Learning Center.",
                "Run an ATS audit on your resume in Career Guidance."
            ]
        }
    }

@app.get("/api/careers")
def get_careers():
    db = load_db()
    return {"success": True, "careers": db.get("careers", [])}

@app.get("/api/agents/opportunities")
def get_opportunities(category: Optional[str] = None, isRemote: Optional[bool] = None, isBeginnerFriendly: Optional[bool] = None, search: Optional[str] = None):
    db = load_db()
    opps = db.get("opportunities", [])
    if category and category != "all":
        opps = [o for o in opps if category.lower() in o.get("category", "").lower()]
    if isRemote is not None:
        opps = [o for o in opps if o.get("isRemote") == isRemote]
    if isBeginnerFriendly is not None:
        opps = [o for o in opps if o.get("isBeginnerFriendly") == isBeginnerFriendly]
    if search:
        s = search.lower()
        opps = [o for o in opps if s in o.get("title", "").lower() or s in o.get("organization", "").lower()]
    
    # Add match percentage
    for o in opps:
        o["matchPercentage"] = o.get("matchPercentage", 85)
    return {"success": True, "totalCount": len(opps), "opportunities": opps}

@app.get("/api/agents/activities")
def get_activities():
    db = load_db()
    return {"success": True, "activities": db.get("activityLogs", [])}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=5000)
