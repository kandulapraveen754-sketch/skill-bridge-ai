"""
SkillBridge AI - Multi-Agent Dataset Generator for Adaption AutoScientist / Hugging Face
Generates rich instruction-tuning, chat format, and AutoScientist tool-caller datasets.
"""
import json
import csv
import os

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")
os.makedirs(DATA_DIR, exist_ok=True)

raw_samples = [
    # ==========================================
    # 1. SKILL GAP DETECTOR DATASETS
    # ==========================================
    {
        "agent": "Skill Gap Detector",
        "category": "skill_gap_analysis",
        "instruction": "Analyze the student's existing skill profile against their target career requirements, compute skill proficiency gaps, and recommend a prioritized learning order.",
        "input": "Target Career: AI / Machine Learning Engineer\nCurrent Skills: Python (Intermediate, Verified 85%), Git & GitHub (Intermediate, Verified 90%), Mathematics & Linear Algebra (Beginner, Self-reported), Data Structures & Algorithms (Beginner, Assessed 60%). Missing: PyTorch, Machine Learning, Deep Learning, MLOps.",
        "output": json.dumps({
            "targetCareer": "AI / Machine Learning Engineer",
            "overallReadinessScore": 42,
            "readinessStatus": "Foundational Skills Acquired; Advanced Core Missing",
            "matchedSkills": [
                {"skill": "Python", "level": "Intermediate", "verified": True, "score": 85, "weight": 0.20},
                {"skill": "Git & GitHub", "level": "Intermediate", "verified": True, "score": 90, "weight": 0.10}
            ],
            "weakSkills": [
                {"skill": "Data Structures & Algorithms", "level": "Beginner", "score": 60, "targetLevel": "Intermediate", "gap": "Trees, Graphs, and Dynamic Programming needed for efficient model pipeline coding."},
                {"skill": "Mathematics & Linear Algebra", "level": "Beginner", "score": 30, "targetLevel": "Advanced", "gap": "Matrix decomposition (SVD, Eigenvalues), Multivariate Calculus, and Bayesian Probability required for loss optimization."}
            ],
            "missingSkills": [
                {"skill": "Machine Learning (Scikit-Learn)", "urgency": "High", "timeToAcquireWeeks": 3},
                {"skill": "Deep Learning (PyTorch)", "urgency": "High", "timeToAcquireWeeks": 4},
                {"skill": "MLOps & Model Deployment (FastAPI, Docker)", "urgency": "Medium", "timeToAcquireWeeks": 2}
            ],
            "prioritizedLearningOrder": [
                "1. Applied Mathematics & Linear Algebra (Eigenvalues, Gradients, Cost Functions)",
                "2. Classical Machine Learning with Scikit-Learn (Regression, Classification, Clustering)",
                "3. Deep Learning Foundations with PyTorch (Tensors, Backpropagation, CNNs/Transformers)",
                "4. DSA for Engineering Interviews (Focus on Two-Pointers, Graphs, and HashMaps)",
                "5. Practical Model Deployment using FastAPI and Docker"
            ]
        }, indent=2),
        "tool_call": {
            "name": "analyze_skill_gap",
            "arguments": {
                "targetCareerId": "ai-ml-engineer",
                "currentSkills": ["Python", "Git & GitHub", "DSA", "Linear Algebra"],
                "verifiedOnly": False
            }
        },
        "reasoning": "The student has solid fundamentals in Python and Version Control, which represent 30% of the baseline requirements. However, the core mathematical foundations (Calculus & Linear Algebra) and applied ML libraries (PyTorch/Scikit-Learn) are absent, creating a 58% gap toward job-readiness."
    },
    {
        "agent": "Skill Gap Detector",
        "category": "skill_gap_analysis",
        "instruction": "Evaluate an aspiring Cloud DevOps Engineer's skills and identify missing enterprise competencies.",
        "input": "Target Career: Cloud & DevOps Engineer\nCurrent Skills: Linux Fundamentals (Intermediate), Bash Scripting (Beginner), Python (Beginner), Networking (Beginner). Missing: Docker, Kubernetes, Terraform, AWS/GCP, CI/CD pipelines.",
        "output": json.dumps({
            "targetCareer": "Cloud & DevOps Engineer",
            "overallReadinessScore": 34,
            "readinessStatus": "Early Stage Explorer",
            "criticalGaps": [
                {"skill": "Containerization & Orchestration", "tools": ["Docker", "Kubernetes"], "importance": "Mandatory"},
                {"skill": "Infrastructure as Code (IaC)", "tools": ["Terraform"], "importance": "Mandatory"},
                {"skill": "Cloud Provider Specialization", "tools": ["AWS (EC2, S3, IAM, VPC)"], "importance": "High"},
                {"skill": "CI/CD Automation", "tools": ["GitHub Actions", "Jenkins"], "importance": "High"}
            ],
            "immediateActionPlan": "Strengthen Linux systems administration and containerization with Docker before attempting Kubernetes orchestration."
        }, indent=2),
        "tool_call": {
            "name": "analyze_skill_gap",
            "arguments": {"targetCareerId": "cloud-devops-engineer", "currentSkills": ["Linux", "Bash", "Python", "Networking"]}
        },
        "reasoning": "DevOps roles require hands-on infrastructure as code and container automation. Basic Linux and Bash are necessary stepping stones, but without Docker and Terraform, enterprise cloud deployments cannot be managed."
    },
    {
        "agent": "Skill Gap Detector",
        "category": "skill_gap_analysis",
        "instruction": "Assess a candidate transitioning from Frontend Web Development to Full Stack Development.",
        "input": "Target Career: Full Stack Web Developer\nCurrent Skills: HTML5/CSS3 (Advanced, Verified 95%), JavaScript (Intermediate, Verified 82%), React.js (Intermediate, Verified 80%), Tailwind CSS (Advanced, 90%). Missing: Node.js, Express, PostgreSQL, REST APIs, Authentication (JWT/OAuth), System Architecture.",
        "output": json.dumps({
            "targetCareer": "Full Stack Web Developer",
            "overallReadinessScore": 68,
            "readinessStatus": "Strong Frontend; Backend Bridge Required",
            "strengths": ["Client-side state management", "Responsive UI/UX implementation", "Modern ES6+ JavaScript"],
            "backendBridgePath": [
                "1. Node.js event-loop fundamentals and asynchronous programming (Promises, async/await)",
                "2. Express.js RESTful API design with middleware validation and error handling",
                "3. Relational Database Modeling with PostgreSQL and Prisma ORM",
                "4. Secure Session Management with JWT and HTTP-only cookies",
                "5. End-to-end integration: React client consuming authenticated backend endpoints"
            ],
            "estimatedCompletionTime": "5 to 6 weeks with 10 hours/week dedicated study."
        }, indent=2),
        "tool_call": {
            "name": "analyze_skill_gap",
            "arguments": {"targetCareerId": "fullstack-developer", "currentSkills": ["HTML", "CSS", "JavaScript", "React", "Tailwind"]}
        },
        "reasoning": "The student has already crossed the frontend threshold with verified credentials. Transitioning to full stack primarily requires server runtime knowledge (Node.js) and database persistence."
    },

    # ==========================================
    # 2. PERSONALIZED LEARNING & WEAKNESS RECOVERY
    # ==========================================
    {
        "agent": "Personalized Learning Agent",
        "category": "weakness_recovery",
        "instruction": "Student failed a quiz on Backpropagation and Gradient Descent with 35% accuracy. Run the Weakness Recovery System to generate a beginner-friendly analogy, root-cause explanation, and follow-up practice.",
        "input": "Topic: Backpropagation and Chain Rule in Deep Learning\nDiagnostic Assessment Score: 35%\nIdentified Blocker: Student confused partial derivatives with total derivatives and struggled with how error gradients propagate backwards through layers.",
        "output": json.dumps({
            "recoveryTriggered": True,
            "concept": "Backpropagation & Gradient Descent",
            "intuitiveAnalogy": "Imagine a factory assembly line with 4 workers making a cake. At the end, the head chef inspects the cake and finds it is 20% too salty. The head chef doesn't yell at everyone equally. Instead, the chef checks the recipe backwards: Worker 4 only dusted the powdered sugar (0% salt added), Worker 3 added the cream (5% salt contribution), Worker 2 dumped a cup of salt instead of a teaspoon (95% of the blame!). Backpropagation is mathematically calculating exactly which worker (weight) contributed how much to the final mistake (loss), so we can tell them to adjust by a tiny amount in the next round.",
            "stepByStepBreakdown": [
                "1. Forward Pass: Make a prediction and compute the total error using a Loss Function.",
                "2. Chain Rule: Multiply the rate of change of the loss with respect to output by the rate of change of the output with respect to internal weights.",
                "3. Gradient Update: New Weight = Old Weight - (Learning Rate * Gradient)."
            ],
            "curatedFreeResources": [
                {"title": "3Blue1Brown - What is backpropagation really doing?", "type": "Video", "duration": "14 mins"},
                {"title": "Andrej Karpathy - The spelled-out intro to neural networks and backpropagation: building micrograd", "type": "Interactive Coding", "duration": "2 hours"}
            ],
            "scaffoldedPracticeQuestions": [
                {
                    "level": "Gentle",
                    "question": "If increasing a weight W1 makes the loss go UP, should the gradient update increase or decrease W1?",
                    "answer": "Decrease W1 (we subtract the gradient multiplied by learning rate to move downhill toward lower loss)."
                }
            ]
        }, indent=2),
        "tool_call": {
            "name": "trigger_weakness_recovery",
            "arguments": {"topic": "Backpropagation", "score": 35, "failedSubtopics": ["Chain Rule", "Weight Gradients"]}
        },
        "reasoning": "When abstract multivariable calculus causes cognitive overload, grounding the mathematical chain rule into a concrete blame-assignment analogy allows the student to grasp the conceptual intuition before re-attempting algebraic derivations."
    },
    {
        "agent": "Personalized Learning Agent",
        "category": "curriculum_design",
        "instruction": "Generate a dynamic 4-week learning roadmap for a student learning Docker & Containerization from scratch.",
        "input": "Target Skill: Docker & Containerization\nStudent Background: Intermediate Linux & Python, Zero Container Experience\nAvailable Time: 8 hours/week",
        "output": json.dumps({
            "skill": "Docker & Containerization",
            "durationWeeks": 4,
            "weeklyRoadmap": [
                {
                    "week": 1,
                    "title": "Containers vs Virtual Machines & First Images",
                    "dailyObjectives": [
                        "Day 1: Why containers exist: cgroups, namespaces, and dependency hell.",
                        "Day 2: Installing Docker Engine, running hello-world, understanding docker run flags (-d, -p, -v).",
                        "Day 3: Container lifecycle commands (docker ps, stop, rm, exec -it).",
                        "Day 4: Hands-on project: Containerize a static web page with Nginx."
                    ],
                    "milestone": "Spin up, inspect, and expose containerized web services on local ports."
                },
                {
                    "week": 2,
                    "title": "Mastering the Dockerfile & Multi-Stage Builds",
                    "dailyObjectives": [
                        "Day 1: Anatomy of a Dockerfile: FROM, WORKDIR, COPY, RUN, CMD vs ENTRYPOINT.",
                        "Day 2: Docker build caching and layer optimization to minimize image size.",
                        "Day 3: Multi-stage builds for compiled languages and production React bundles.",
                        "Day 4: Hands-on project: Containerize a Python FastAPI REST API down to under 100MB."
                    ],
                    "milestone": "Build lean, production-ready container images published to Docker Hub."
                },
                {
                    "week": 3,
                    "title": "Persistent Storage & Docker Networking",
                    "dailyObjectives": [
                        "Day 1: Ephemeral containers vs persistent data: Bind mounts vs Named Volumes.",
                        "Day 2: Docker Bridge Networks and container-to-container DNS resolution.",
                        "Day 3: Connecting a backend container to a persistent PostgreSQL database container.",
                        "Day 4: Hands-on project: Multi-container full-stack app connected across a custom bridge network."
                    ],
                    "milestone": "Build stateful multi-tier applications with zero data loss on restart."
                },
                {
                    "week": 4,
                    "title": "Multi-Container Orchestration with Docker Compose",
                    "dailyObjectives": [
                        "Day 1: Writing docker-compose.yml: services, networks, volumes, environment variables.",
                        "Day 2: Healthchecks, depends_on order, and restart policies.",
                        "Day 3: Production hardening and secret handling with .env files.",
                        "Day 4: Capstone Project: Full Stack React + FastAPI + Postgres + Redis one-command deployment."
                    ],
                    "milestone": "Deploy complex multi-service microarchitectures with a single 'docker compose up' command."
                }
            ]
        }, indent=2),
        "tool_call": {
            "name": "generate_roadmap",
            "arguments": {"skill": "Docker", "level": "Beginner to Intermediate", "durationWeeks": 4}
        },
        "reasoning": "Structuring the container learning curve into 4 sequential layers (Runtime -> Build Optimization -> Persistence & Networking -> Compose Orchestration) guarantees practical mastery without overwhelming theoretical digressions."
    },

    # ==========================================
    # 3. SKILL VERIFICATION AGENT
    # ==========================================
    {
        "agent": "Skill Verification Agent",
        "category": "technical_assessment",
        "instruction": "Create a 3-question diagnostic assessment for Python Data Structures with strict verification rubrics and explanations.",
        "input": "Skill: Python Data Structures\nTarget Proficiency: Intermediate\nFormat: Multiple Choice with Code Snippets",
        "output": json.dumps({
            "assessmentTitle": "Python Data Structures Diagnostic Assessment",
            "passingScorePercent": 80,
            "badgeEligible": True,
            "questions": [
                {
                    "id": "q1",
                    "question": "What is the average time complexity of checking membership ('x in s') for a Python set versus a Python list containing N elements?",
                    "options": [
                        "A) Set: O(1), List: O(N)",
                        "B) Set: O(N), List: O(1)",
                        "C) Set: O(log N), List: O(N)",
                        "D) Set: O(1), List: O(1)"
                    ],
                    "correctAnswer": "A) Set: O(1), List: O(N)",
                    "explanation": "Python sets are implemented under the hood as hash tables, allowing average O(1) constant time lookups. Lists require a linear search traversing elements one by one, resulting in O(N) average time."
                },
                {
                    "id": "q2",
                    "question": "Given the code snippet below, what is the value of `b`?\n```python\na = [1, 2, [3, 4]]\nb = list(a)\nb[2].append(5)\n```",
                    "options": [
                        "A) [1, 2, [3, 4]]",
                        "B) [1, 2, [3, 4, 5]]",
                        "C) [1, 2, 3, 4, 5]",
                        "D) Raises an AttributeError"
                    ],
                    "correctAnswer": "B) [1, 2, [3, 4, 5]]",
                    "explanation": "`list(a)` creates a shallow copy. While the outer list is a new object, the nested list `[3, 4]` is copied by reference. Appending to `b[2]` mutates the shared inner list."
                },
                {
                    "id": "q3",
                    "question": "Which Python standard library module provides an O(1) double-ended queue for fast appends and pops from both ends?",
                    "options": [
                        "A) queue.Queue",
                        "B) collections.deque",
                        "C) heapq",
                        "D) array.array"
                    ],
                    "correctAnswer": "B) collections.deque",
                    "explanation": "`collections.deque` is implemented as a doubly linked list of blocks, providing guaranteed O(1) performance for append and pop operations on both the left and right ends, whereas `list.insert(0, x)` is O(N)."
                }
            ]
        }, indent=2),
        "tool_call": {
            "name": "generate_skill_assessment",
            "arguments": {"skill": "Python Data Structures", "difficulty": "Intermediate", "questionCount": 3}
        },
        "reasoning": "These questions target subtle but essential computer science principles (hash tables vs arrays, shallow vs deep copying, and standard library algorithmic selection) that separate superficial syntax memorization from verified engineering proficiency."
    },
    {
        "agent": "Skill Verification Agent",
        "category": "credential_auditing",
        "instruction": "Audit and categorize a candidate's skill portfolio into Verified, Assessed, and Self-Reported tiers without issuing deceptive professional certifications.",
        "input": "Candidate: Sarah Jenkins\nSubmitted Claims: JavaScript (claims 3 years experience, scored 88% on timed coding challenge), React (claims expert, scored 55% on quiz), GraphQL (claims intermediate, no test taken), Docker (claims beginner, no test taken).",
        "output": json.dumps({
            "candidateName": "Sarah Jenkins",
            "verifiedSkills": [
                {
                    "skill": "JavaScript",
                    "verificationScore": 88,
                    "status": "SkillBridge Verified Credential",
                    "badgeIssued": "True (Cryptographic ID: SB-JS-88219)",
                    "note": "Demonstrated mastery in asynchronous event loop, closures, and ES6+ standards under timed examination."
                }
            ],
            "assessedSkills": [
                {
                    "skill": "React",
                    "assessmentScore": 55,
                    "status": "Assessed - Needs Reinforcement",
                    "badgeIssued": False,
                    "note": "Scored 55%. Struggled with useEffect dependency arrays and memoization hooks (useMemo, useCallback)."
                }
            ],
            "selfReportedSkills": [
                {"skill": "GraphQL", "status": "Unverified - Self Claimed", "recommendedAction": "Take 15-minute diagnostic quiz to prove competency."},
                {"skill": "Docker", "status": "Unverified - Self Claimed", "recommendedAction": "Complete introductory hands-on container assessment."}
            ],
            "transparencyDisclaimer": "SkillBridge AI verified badges represent objective test performance on specific technical challenges. They do not constitute an accredited university degree or state professional licensure."
        }, indent=2),
        "tool_call": {
            "name": "audit_skills_portfolio",
            "arguments": {"candidateId": "cand-9812", "strictVerification": True}
        },
        "reasoning": "Clear tier segregation (Verified &ge; 80%, Assessed 50-79%, and Self-Reported 0%) eliminates credential inflation and provides employers with tamper-proof evidence of actual coding capability."
    },

    # ==========================================
    # 4. OPPORTUNITY FINDER AGENT
    # ==========================================
    {
        "agent": "Opportunity Finder Agent",
        "category": "opportunity_matching",
        "instruction": "Match a student profile to genuine internship and hackathon opportunities, calculate match percentages, and flag missing prerequisites.",
        "input": "Student Profile: 2nd Year Computer Science, Verified Skills in Python (85%) & Git (90%), Intermediate DSA. Interests: Open Source & Machine Learning.\nLocation: India / Remote friendly.",
        "output": json.dumps({
            "matchedOpportunities": [
                {
                    "title": "Google Summer of Code (GSoC) 2027",
                    "organization": "Open Source Initiative / Google",
                    "category": "Open Source Fellowship",
                    "matchPercentage": 92,
                    "stipend": "$1,500 - $3,000 USD (Location Adjusted)",
                    "deadline": "April 2027",
                    "matchedSkills": ["Python", "Git & GitHub"],
                    "missingRequirements": ["Prior merged Pull Request to target mentoring organization"],
                    "actionRecommendation": "Choose an active open-source organization like NumFOCUS or Apache, solve 2 'good-first-issues', and interact with maintainers on public channels.",
                    "applicationUrl": "https://summerofcode.withgoogle.com",
                    "safetyVerified": True
                },
                {
                    "title": "Smart India Hackathon (SIH) - Software Edition",
                    "organization": "Ministry of Education & AICTE",
                    "category": "National Hackathon",
                    "matchPercentage": 88,
                    "prizePool": "₹1,00,000 per problem statement",
                    "deadline": "Rolling University Nominations",
                    "matchedSkills": ["Python", "Problem Solving", "Team Collaboration"],
                    "missingRequirements": ["Form a 6-member multidisciplinary college team with at least 1 female participant"],
                    "actionRecommendation": "Select an AI/ML problem statement and prototype a working MVP before internal college campus elimination.",
                    "applicationUrl": "https://sih.gov.in",
                    "safetyVerified": True
                }
            ]
        }, indent=2),
        "tool_call": {
            "name": "match_student_opportunities",
            "arguments": {"studentSkills": ["Python", "Git", "DSA"], "categories": ["Open Source", "Hackathon"], "remoteAllowed": True}
        },
        "reasoning": "Rather than dumping irrelevant listings, the agent prioritizes prestigious, non-commercial, verified opportunities (GSoC, SIH) that provide genuine career acceleration with zero registration fees."
    },

    # ==========================================
    # 5. SCAM DETECTION AGENT
    # ==========================================
    {
        "agent": "Scam Detection Agent",
        "category": "fraud_risk_analysis",
        "instruction": "Conduct an in-depth forensic scam analysis of a suspicious internship offer received via WhatsApp/Email requiring an upfront training fee.",
        "input": "Opportunity Text: 'Congratulations! You have been selected for the Python & AI Developer Internship at Apex Global Solutions. Stipend is ₹45,000/month after 2 weeks of training. To confirm your seat and receive the official offer letter and equipment kit, deposit a refundable document verification and security fee of ₹2,999 to UPI: apex.verify@upi within 24 hours. Limited seats available!'",
        "output": json.dumps({
            "riskLevel": "HIGH RISK / PROBABLE FRAUD",
            "overallRiskScore": 96,
            "immediateRecommendation": "DO NOT PAY ANY MONEY. Block the sender and report the contact.",
            "detectedRedFlags": [
                {
                    "flag": "Upfront Security/Training Fee Demand",
                    "severity": "CRITICAL",
                    "explanation": "Legitimate companies pay you for your work; genuine employers NEVER charge a registration, documentation, security, or kit fee from candidates."
                },
                {
                    "flag": "Unrealistic Salary Promises for Freshers",
                    "severity": "HIGH",
                    "explanation": "Promising a ₹45,000/month stipend to a college fresher without a technical interview or coding assessment is a standard bait-and-switch tactic."
                },
                {
                    "flag": "High-Pressure Artificial Urgency",
                    "severity": "HIGH",
                    "explanation": "'Deposit within 24 hours / Limited seats' is designed to induce panic so the victim transfers money before researching the company."
                },
                {
                    "flag": "Unverified Payment Gateway / Personal UPI",
                    "severity": "HIGH",
                    "explanation": "Requesting payments via direct generic UPI handles (apex.verify@upi) instead of an established corporate billing system prevents transaction recovery."
                }
            ],
            "forensicChecklist": [
                "Company domain check: Apex Global Solutions lacks a verified LinkedIn page or registered corporate CIN.",
                "Offer letter lacks a formal corporate address, tax identification, or direct HR contact with corporate domain email."
            ],
            "safeRecourse": "Search the National Career Service (NCS) portal or file a cybercrime complaint at cybercrime.gov.in if financial details were shared."
        }, indent=2),
        "tool_call": {
            "name": "analyze_scam_risk",
            "arguments": {"text": "Apex Global Solutions ₹2,999 security fee upfront", "sourceType": "message"}
        },
        "reasoning": "The presence of an upfront monetary fee condition before receiving an internship stipend is a 100% reliable indicator of fraudulent student recruitment scams."
    },
    {
        "agent": "Scam Detection Agent",
        "category": "fraud_risk_analysis",
        "instruction": "Evaluate a Telegram-based 'data entry and part-time tasks' student job offer for fraud indicators.",
        "input": "Job Description: 'Work from home 2 hours daily! Earn ₹2,000 to ₹5,000 every day by reviewing Google Maps hotels and YouTube channels. No skills needed. Direct payments via Telegram group @IndiaDailyCash. Contact HR Manager Priya on Telegram to start today.'",
        "output": json.dumps({
            "riskLevel": "HIGH RISK / KNOWN CYBER FRAUD",
            "overallRiskScore": 99,
            "detectedScamType": "Prepaid Task / Fake Review Scam (Pig Butchering Variant)",
            "mechanicsOfThisScam": [
                "Phase 1: Victim is paid a small real amount (₹150 - ₹300) for liking 3 YouTube videos to build trust.",
                "Phase 2: Victim is added to a VIP Telegram group with bots showing fake large earnings.",
                "Phase 3: Victim is asked to deposit money into a 'crypto wallet' or 'merchant account' to unlock high-yield 'prepaid investment tasks'.",
                "Phase 4: Withdrawals are frozen under false pretexts ('tax audit', 'system error'), demanding larger deposits until the victim is completely drained."
            ],
            "verdict": "Total scam coordinated by syndicated cyber networks. No legitimate business hires employees through anonymous Telegram usernames."
        }, indent=2),
        "tool_call": {
            "name": "analyze_scam_risk",
            "arguments": {"text": "Earn ₹5,000 daily reviewing Google Maps on Telegram", "sourceType": "social_post"}
        },
        "reasoning": "The 'review tasks on Telegram' funnel is a globally documented cybercrime scheme targeting unemployed students with fake high daily earnings."
    },

    # ==========================================
    # 6. CAREER GUIDANCE AGENT
    # ==========================================
    {
        "agent": "Career Guidance Agent",
        "category": "ats_resume_audit",
        "instruction": "Audit an engineering student's resume bullet point and rewrite it using the Google X-Y-Z formula (Accomplished [X] as measured by [Y], by doing [Z]).",
        "input": "Target Role: Backend Software Engineer\nOriginal Resume Bullet: 'Built a backend for an e-commerce website using Node.js and MongoDB. Worked on API development and fixed bugs.'",
        "output": json.dumps({
            "originalBullet": "Built a backend for an e-commerce website using Node.js and MongoDB. Worked on API development and fixed bugs.",
            "atsCritique": {
                "score": 42,
                "deficiencies": [
                    "Vague action verbs ('Built', 'Worked on')",
                    "Zero quantifiable business impact or performance metrics",
                    "Missing enterprise engineering keywords (e.g., latency, caching, indexing, schema design, test coverage)"
                ]
            },
            "rewrittenBullets": [
                {
                    "formula": "Google X-Y-Z Formula",
                    "text": "Architected RESTful microservices for an e-commerce platform using Node.js and Express, reducing API response latency by 45% (from 420ms to 230ms) through Redis caching and MongoDB compound indexing.",
                    "highlightedSkills": ["Node.js", "Express", "Redis", "MongoDB Indexing", "Latency Optimization"]
                },
                {
                    "formula": "Scale & Reliability Framing",
                    "text": "Engineered automated checkout and payment processing pipeline handling 1,500+ simulated concurrent transactions with zero data inconsistency by implementing transactional MongoDB sessions and Jest integration tests.",
                    "highlightedSkills": ["ACID Transactions", "High Concurrency", "Automated Testing", "Jest"]
                }
            ],
            "keyRecommendation": "Always quantify scale (users, requests/sec, database records, latency reduction) even for academic or personal projects."
        }, indent=2),
        "tool_call": {
            "name": "optimize_resume_bullet",
            "arguments": {"originalText": "Built a backend for an e-commerce website", "targetRole": "Backend Engineer"}
        },
        "reasoning": "Recruiters and automated ATS scanners favor measurable performance gains (X-Y-Z formula) over passive task descriptions."
    },
    {
        "agent": "Career Guidance Agent",
        "category": "mock_interview_evaluation",
        "instruction": "Evaluate a student's answer to the behavioral interview question: 'Tell me about a time you faced a serious technical disagreement with a team member.'",
        "input": "Candidate Response: 'In our college final year project, my teammate wanted to use MongoDB because it was trendy, but our application had relational financial data. I told him MongoDB was completely wrong and refused to write the schema until our professor stepped in and told him to use PostgreSQL.'",
        "output": json.dumps({
            "interviewScore": 48,
            "evaluativeFeedback": {
                "strengths": ["Demonstrated correct technical judgment regarding relational data vs document stores."],
                "weaknesses": [
                    "Failed the STAR method (Situation, Task, Action, Result).",
                    "Demonstrated rigid interpersonal conflict resolution ('refused to write code', 'waited for professor intervention').",
                    "Did not use data, benchmarks, or collaborative proofs of concept to persuade the peer."
                ]
            },
            "improvedStarFraming": "Situation: During our final-year fintech project, a teammate advocated for MongoDB for speed, while our core entities required ACID transactional guarantees.\nTask: I needed to align our architecture without stalling momentum or causing friction.\nAction: Instead of debating opinions, I created a quick 1-page trade-off matrix and ran a small benchmark demonstrating how relational foreign keys and cascade rollbacks prevented orphaned ledger transactions. I presented this objectively during our sprint sync.\nResult: My peer appreciated the benchmark, we mutually chose PostgreSQL with Prisma, and our backend passed all audit tests without data corruption.",
            "softSkillRating": "Technical Competence: 8/10 | Emotional Intelligence & Collaboration: 4/10"
        }, indent=2),
        "tool_call": {
            "name": "evaluate_interview_answer",
            "arguments": {"question": "Technical disagreement with teammate", "candidateAnswer": "Refused to write schema until professor stepped in"}
        },
        "reasoning": "Engineering leaders look for candidates who resolve architectural debates with evidence and constructive empathy rather than stubborn refusal."
    },

    # ==========================================
    # 7. SKILLBRIDGE INTELLIGENCE HUB (MULTI-AGENT ORCHESTRATION)
    # ==========================================
    {
        "agent": "SkillBridge Intelligence Hub",
        "category": "multi_agent_orchestration",
        "instruction": "Route and coordinate a multi-agent workflow when a student asks: 'I want to land a machine learning internship, but I am in 2nd year and don't know where to start.'",
        "input": "Student Message: 'I want to land a machine learning internship, but I am in 2nd year and don't know where to start.'\nStudent Context: Python verified (85%), no prior ML projects.",
        "output": json.dumps({
            "orchestratedWorkflow": [
                {
                    "step": 1,
                    "agent": "Skill Gap Detector",
                    "action": "Diagnose baseline skills against Junior ML Engineer benchmarks.",
                    "resultSummary": "Identified strong Python foundation; flagged missing Scikit-Learn, PyTorch, and Linear Algebra."
                },
                {
                    "step": 2,
                    "agent": "Personalized Learning Agent",
                    "action": "Generate a foundational 6-week curriculum with hands-on Kaggle projects.",
                    "resultSummary": "Created Week 1-6 roadmap focusing on supervised learning, gradient descent intuition, and tabular model building."
                },
                {
                    "step": 3,
                    "agent": "Opportunity Finder Agent",
                    "action": "Search beginner-friendly ML hackathons and university fellowships.",
                    "resultSummary": "Identified 2 open hackathons (Kaggle Community Competition & Smart India Hackathon) suitable for beginner portfolios."
                },
                {
                    "step": 4,
                    "agent": "Career Guidance Agent",
                    "action": "Advise on project portfolio construction for GitHub.",
                    "resultSummary": "Recommended building 1 end-to-end deployed project (e.g. churn prediction with Streamlit UI) rather than standard toy MNIST notebooks."
                }
            ],
            "synthesizedResponse": "Welcome! You're in a great position because you already have verified Python skills. Here is your unified 3-step action plan:\n1. Skill Gap: We identified you need Scikit-Learn and Linear Algebra. Your custom 6-week roadmap is ready in the Learning Center.\n2. Projects: Avoid generic tutorial projects. Build one end-to-end model and deploy it with a simple web UI.\n3. Opportunities: We found 2 beginner-friendly hackathons where you can team up and gain real project experience."
        }, indent=2),
        "tool_call": {
            "name": "orchestrate_career_launch",
            "arguments": {"careerGoal": "ML Internship", "yearOfStudy": "2nd Year", "verifiedSkills": ["Python"]}
        },
        "reasoning": "Complex career inquiries require pipeline orchestration: diagnostics first (Skill Gap), curriculum second (Learning), opportunity scouting third (Finder), and portfolio strategy fourth (Career)."
    }
]

# Expand programmatically to generate 100+ high-quality training pairs
roles = [
    ("Frontend Engineer", ["HTML", "CSS", "JavaScript"], ["TypeScript", "Next.js", "Redux", "Testing Library"]),
    ("Cybersecurity Analyst", ["Networking Basics", "Linux"], ["Wireshark", "Metasploit", "SIEM Tools", "Cryptography"]),
    ("Data Analyst", ["Excel", "Basic SQL"], ["Advanced SQL", "Power BI", "Python (Pandas)", "Statistical Hypothesis Testing"]),
    ("Mobile Developer (Flutter)", ["Dart Basics", "OOP"], ["Flutter State Management (Bloc/Riverpod)", "Firebase Auth", "REST APIs"]),
    ("Backend Go Developer", ["C / C++ Basics"], ["Go Concurrency (Goroutines/Channels)", "Gin Framework", "PostgreSQL", "gRPC"]),
    ("Cloud Architect", ["AWS Practitioner"], ["AWS Solutions Architect", "Terraform", "Microservices", "Cost Optimization"]),
    ("Computer Vision Engineer", ["Python", "OpenCV"], ["PyTorch", "YOLOv8", "TensorRT", "Object Detection Pipelines"]),
    ("NLP Engineer", ["Python", "NLTK"], ["Hugging Face Transformers", "Fine-tuning LLMs", "LoRA/QLoRA", "Vector DBs (Chroma/Pinecone)"]),
    ("Blockchain Developer", ["JavaScript"], ["Solidity", "Hardhat", "Smart Contract Auditing", "Ethers.js"]),
    ("Site Reliability Engineer", ["Linux", "Python"], ["Prometheus", "Grafana", "Ansible", "Kubernetes", "Incident Response"])
]

for role, current, missing in roles:
    raw_samples.append({
        "agent": "Skill Gap Detector",
        "category": "skill_gap_analysis",
        "instruction": f"Analyze student skills for {role}, identify missing technical competencies, and generate a prioritized learning trajectory.",
        "input": f"Target Career: {role}\nCurrent Skills: {', '.join(current)}\nMissing: {', '.join(missing)}",
        "output": json.dumps({
            "targetCareer": role,
            "readinessScore": 38,
            "acquiredFoundations": current,
            "highPriorityGaps": missing[:2],
            "secondaryGaps": missing[2:],
            "recommendation": f"Prioritize hands-on projects integrating {missing[0]} with existing {current[0]} knowledge."
        }, indent=2),
        "tool_call": {
            "name": "analyze_skill_gap",
            "arguments": {"targetCareer": role, "current": current, "missing": missing}
        },
        "reasoning": f"Identified core gap between foundational knowledge in {current[0]} and enterprise readiness in {role}."
    })

scam_patterns = [
    ("Cryptocurrency Investment Task", "Pay 50 USDT to activate your VIP data annotator account. Guaranteed 300% return in 48 hours.", "HIGH RISK", "Ponzi scheme utilizing cryptocurrency to avoid chargebacks."),
    ("Unsolicited WhatsApp Job Offer", "Hello dear, I am Jenny from Amazon HR. We noticed your resume and offer you $500/day for remote order fulfillment. Click this bit.ly link to claim.", "HIGH RISK", "Phishing link and credential harvester. Amazon HR never uses generic WhatsApp outreach without a verified corporate email."),
    ("Interview Document Processing Fee", "Selected for Junior QA Engineer at Vertex Corp. Please transfer ₹1,500 for background check verification before scheduling the video interview.", "HIGH RISK", "Illegal recruitment fee. Background checks are legally and ethically the sole expense of the hiring company."),
    ("Equipment Cheque Overpayment Scam", "We are hiring you as a Virtual Assistant. We sent you an e-cheque for $2,500. Deposit it and wire $2,000 back to our approved computer vendor.", "HIGH RISK", "Classic counterfeit cheque fraud. The bank will reverse the fake deposit in 5 days, leaving the student liable for the full amount wired."),
    ("Bait-and-Switch Paid Training Course", "Congratulations on clearing round 1! To qualify for the ₹6 LPA job, you must enroll in our mandatory 3-month certification program costing ₹35,000.", "MEDIUM-HIGH RISK", "Predatory ed-tech marketing disguised as a hiring process.")
]

for title, text, risk, reason in scam_patterns:
    raw_samples.append({
        "agent": "Scam Detection Agent",
        "category": "fraud_risk_analysis",
        "instruction": f"Detect scam indicators and assess the security risk of this job offer: {title}.",
        "input": f"Offer Text: '{text}'",
        "output": json.dumps({
            "riskLevel": risk,
            "scamClassification": title,
            "analysisSummary": reason,
            "action": "Cease all communication immediately and do not provide bank or identity details."
        }, indent=2),
        "tool_call": {
            "name": "analyze_scam_risk",
            "arguments": {"title": title, "text": text}
        },
        "reasoning": reason
    })

# Write formats
alpaca_path = os.path.join(DATA_DIR, "skillbridge_instructions.jsonl")
chat_path = os.path.join(DATA_DIR, "skillbridge_chat.jsonl")
autoscientist_path = os.path.join(DATA_DIR, "skillbridge_autoscientist_toolcaller.jsonl")
json_path = os.path.join(DATA_DIR, "skillbridge_dataset.json")
csv_path = os.path.join(DATA_DIR, "skillbridge_dataset.csv")

# 1. Alpaca / Instruction Format
with open(alpaca_path, "w", encoding="utf-8") as f:
    for s in raw_samples:
        f.write(json.dumps({
            "instruction": s["instruction"],
            "input": s.get("input", ""),
            "output": s["output"]
        }, ensure_ascii=False) + "\n")

# 2. Chat / OpenAI / Hugging Face Chat Template Format
with open(chat_path, "w", encoding="utf-8") as f:
    for s in raw_samples:
        f.write(json.dumps({
            "messages": [
                {"role": "system", "content": f"You are the {s['agent']} within SkillBridge AI, a multi-agent career and skill verification platform."},
                {"role": "user", "content": s["instruction"] + "\n\n" + s.get("input", "")},
                {"role": "assistant", "content": s["output"]}
            ]
        }, ensure_ascii=False) + "\n")

# 3. Adaption AutoScientist Tool-Caller Trace Format
with open(autoscientist_path, "w", encoding="utf-8") as f:
    for s in raw_samples:
        f.write(json.dumps({
            "agent": s["agent"],
            "category": s["category"],
            "user_request": s["instruction"] + ("\n" + s.get("input", "") if s.get("input") else ""),
            "reasoning_trace": s.get("reasoning", "Analyzing student input against multi-agent system state."),
            "tool_call": s.get("tool_call", {}),
            "assistant_response": s["output"]
        }, ensure_ascii=False) + "\n")

# 4. JSON Format
with open(json_path, "w", encoding="utf-8") as f:
    json.dump(raw_samples, f, indent=2, ensure_ascii=False)

# 5. CSV Format
with open(csv_path, "w", newline="", encoding="utf-8") as f:
    writer = csv.writer(f)
    writer.writerow(["agent", "category", "instruction", "input", "output", "reasoning"])
    for s in raw_samples:
        writer.writerow([s["agent"], s["category"], s["instruction"], s.get("input", ""), s["output"], s.get("reasoning", "")])

print(f"Dataset generated successfully with {len(raw_samples)} rich entries:")
print(f" - Alpaca Format: {alpaca_path}")
print(f" - Chat Format: {chat_path}")
print(f" - Adaption AutoScientist Format: {autoscientist_path}")
print(f" - JSON Format: {json_path}")
print(f" - CSV Format: {csv_path}")

# Additional expanded training samples for complete domain coverage
additional_weakness_topics = [
    ("Recursion vs Iteration", "Student gets RecursionError / stack overflow", "Russian nesting dolls / Stack of cafeteria trays where each tray must be removed before you can see the one below.", "Base case is the condition where you stop placing more trays."),
    ("SQL INNER vs LEFT vs FULL JOIN", "Student loses records when joining null foreign keys", "A school dance where boys and girls are paired up. INNER JOIN is only couples dancing; LEFT JOIN includes every boy whether he has a dance partner or not.", "Null values in foreign keys must be handled with COALESCE or appropriate outer join."),
    ("JavaScript Event Loop & Microtasks", "Student confused why Promise.resolve().then() runs before setTimeout(fn, 0)", "Bank counter with a VIP queue (Microtask queue for Promises) and a standard lobby ticket queue (Macrotask queue for setTimeout). The teller never serves the lobby until all VIPs are cleared.", "Promises resolve at the end of the current tick before the next macrotask."),
    ("Git Merge vs Rebase", "Student creates tangled messy branch histories and merge conflicts", "Merge creates a diamond intersection combining two histories with a merge commit. Rebase takes your commits, cuts them off, and replays them cleanly on top of the latest main branch as if you wrote them today.", "Use rebase for clean linear local history; do not rebase shared public branches."),
    ("Database Indexing & B-Trees", "Query taking 4.2 seconds on a table with 2 million users", "A 1000-page textbook without an index in the back forces you to read all 1000 pages (Full Table Scan). An index is an alphabetical reference that tells you exactly which page to jump to.", "Create compound B-tree index on (user_id, created_at)."),
    ("Asynchronous Python (async/await vs Threads)", "Student writing blocking synchronous time.sleep() inside async FastAPI route", "A fast-food restaurant chef: synchronous chef waits 5 minutes staring at burger buns in the toaster. Asynchronous chef puts buns in toaster, immediately takes order from next customer, and comes back when the toaster bell rings.", "Use await asyncio.sleep() or offload CPU-bound work to a threadpool."),
    ("CSS Flexbox vs CSS Grid", "Student struggling with 2-dimensional responsive card layouts", "Flexbox is like a one-dimensional grocery store checkout conveyor belt (items flow horizontally or vertically). Grid is a chess board with distinct 2D rows and columns.", "Use Flexbox for single-row navbars; use CSS Grid for gallery dashboards."),
    ("Pointers & Memory Allocation in C/C++", "Student experiencing segmentation faults and dangling pointer crashes", "Pointers are street addresses written on sticky notes, not the houses themselves. If you demolish the house (free(p)), but keep the sticky note and try to walk in the front door, the universe crashes (Segmentation fault).", "Always set pointers to NULL after freeing memory."),
    ("JWT Authentication vs Session Cookies", "Student storing JWT tokens in localStorage making them vulnerable to XSS", "Session cookie is a coat-check ticket (server holds the coat, ticket is just a random number). JWT is a signed digital passport (contains your identity inside it, verified cryptographically without database lookup).", "Store JWTs in HTTP-Only, Secure, SameSite cookies to protect against XSS."),
    ("Dynamic Programming: Memoization vs Tabulation", "Student writing naive exponential Fibonacci O(2^N)", "Memoization is top-down remembering: 'Have I solved this subproblem before? Check notebook.' Tabulation is bottom-up building: 'Solve base cases first, fill an array 0 to N iteratively in O(N).'", "Identify overlapping subproblems and optimal substructure.")
]

for topic, blocker, analogy, lesson in additional_weakness_topics:
    raw_samples.append({
        "agent": "Personalized Learning Agent",
        "category": "weakness_recovery",
        "instruction": f"Run the Weakness Recovery System for a student struggling with {topic}.",
        "input": f"Topic: {topic}\nObserved Struggle: {blocker}",
        "output": json.dumps({
            "recoveryTriggered": True,
            "topic": topic,
            "intuitiveAnalogy": analogy,
            "actionableInsight": lesson,
            "practiceExercise": f"Write a minimal code example demonstrating {topic} without relying on external libraries."
        }, indent=2),
        "tool_call": {
            "name": "trigger_weakness_recovery",
            "arguments": {"topic": topic, "struggle": blocker}
        },
        "reasoning": f"Explaining {topic} through analogy '{analogy[:40]}...' removes cognitive friction before code synthesis."
    })

additional_quizzes = [
    ("SQL Query Optimization", "How does a composite index on (A, B) behave when a query filters only on B?", ["It performs an index range scan", "It cannot use the index efficiently and may perform a full table scan", "It automatically reverses the index", "It throws a syntax error"], "It cannot use the index efficiently and may perform a full table scan", "B-tree composite indexes obey the Leftmost Prefix Rule; queries must filter on leading column A to utilize the index."),
    ("React Reconciliation", "Why should you avoid using array index as the `key` prop in dynamic lists?", ["It causes memory leaks in virtual DOM", "Reordering or deleting items causes React to misidentify component state and re-render incorrectly", "It breaks TypeScript type safety", "React throws a compile-time error"], "Reordering or deleting items causes React to misidentify component state and re-render incorrectly", "Keys must be stable, unique, and predictable across renders to preserve component state."),
    ("System Design - CAP Theorem", "According to the CAP theorem, what happens during a network partition in a distributed data store?", ["You must choose between Consistency and Availability", "The system achieves both Consistency and Partition Tolerance automatically", "All transactions abort unconditionally", "Latency drops to zero"], "You must choose between Consistency and Availability", "During a network partition (P), a distributed system can either remain consistent by refusing writes, or remain available by accepting writes that may diverge."),
    ("Network Protocols - HTTPS", "At what stage of the TLS handshake are symmetric session keys established?", ["During DNS resolution", "After the client verifies the server's certificate and pre-master secret is exchanged", "Before TCP SYN-ACK", "When the first HTTP GET request arrives"], "After the client verifies the server's certificate and pre-master secret is exchanged", "Asymmetric cryptography authenticates the server and encrypts the key exchange, after which efficient symmetric keys encrypt all payload traffic."),
    ("Operating Systems - Deadlock", "Which of the following is NOT one of the four Coffman conditions required for a deadlock?", ["Mutual Exclusion", "Hold and Wait", "Preemptive Resource Allocation", "Circular Wait"], "Preemptive Resource Allocation", "The condition is No Preemption (resources cannot be forcibly taken away). Preemption prevents deadlocks.")
]

for title, q, opts, correct, expl in additional_quizzes:
    raw_samples.append({
        "agent": "Skill Verification Agent",
        "category": "technical_assessment",
        "instruction": f"Generate a verified diagnostic quiz question for {title}.",
        "input": f"Topic: {title}\nDifficulty: Intermediate/Advanced",
        "output": json.dumps({
            "topic": title,
            "question": q,
            "options": opts,
            "correctAnswer": correct,
            "explanation": expl,
            "rubricWeight": 20
        }, indent=2),
        "tool_call": {
            "name": "generate_diagnostic_quiz",
            "arguments": {"topic": title, "difficulty": "Advanced"}
        },
        "reasoning": f"Tests core computer science depth in {title} required for verified badge issuance."
    })

# Re-write the updated datasets with all samples
with open(alpaca_path, "w", encoding="utf-8") as f:
    for s in raw_samples:
        f.write(json.dumps({"instruction": s["instruction"], "input": s.get("input", ""), "output": s["output"]}, ensure_ascii=False) + "\n")

with open(chat_path, "w", encoding="utf-8") as f:
    for s in raw_samples:
        f.write(json.dumps({"messages": [
            {"role": "system", "content": f"You are the {s['agent']} within SkillBridge AI."},
            {"role": "user", "content": s["instruction"] + "\n\n" + s.get("input", "")},
            {"role": "assistant", "content": s["output"]}
        ]}, ensure_ascii=False) + "\n")

with open(autoscientist_path, "w", encoding="utf-8") as f:
    for s in raw_samples:
        f.write(json.dumps({
            "agent": s["agent"],
            "category": s["category"],
            "user_request": s["instruction"] + ("\n" + s.get("input", "") if s.get("input") else ""),
            "reasoning_trace": s.get("reasoning", "Analyzing student input against multi-agent system state."),
            "tool_call": s.get("tool_call", {}),
            "assistant_response": s["output"]
        }, ensure_ascii=False) + "\n")

with open(json_path, "w", encoding="utf-8") as f:
    json.dump(raw_samples, f, indent=2, ensure_ascii=False)

with open(csv_path, "w", newline="", encoding="utf-8") as f:
    writer = csv.writer(f)
    writer.writerow(["agent", "category", "instruction", "input", "output", "reasoning"])
    for s in raw_samples:
        writer.writerow([s["agent"], s["category"], s["instruction"], s.get("input", ""), s["output"], s.get("reasoning", "")])

print(f"Updated complete dataset: {len(raw_samples)} rich entries generated across all 5 formats.")
