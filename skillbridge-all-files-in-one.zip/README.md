# 🚀 SkillBridge AI

> **Connect Skills. Discover Opportunities. Build Your Future.**

[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](https://opensource.org/licenses/MIT)
[![Node.js Version](https://img.shields.io/badge/Node.js-v18%2B-green.svg)](https://nodejs.org/)
[![React Version](https://img.shields.io/badge/React-18-61DAFB.svg)](https://react.dev/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.0-3178C6.svg)](https://www.typescriptlang.org/)
[![Tailwind CSS](https://img.shields.io/badge/TailwindCSS-3.4-38B2AC.svg)](https://tailwindcss.com/)
[![Architecture](https://img.shields.io/badge/Architecture-Multi--Agent%20Hub-8A2BE2.svg)](#-system-architecture)

**SkillBridge AI** is an enterprise-grade, student-centric AI career accelerator and multi-agent orchestration platform. Built to solve the widening gap between college education and industry hiring standards, SkillBridge AI coordinates **six specialized AI agents** through a centralized **Intelligence Hub**. The platform objectively diagnoses skill deficiencies, delivers adaptive learning curricula with automatic weakness recovery, cryptographically audits true technical competency, surfaces vetted student opportunities, shields candidates from predatory recruitment scams, and automates ATS resume and mock interview preparation.

---

## 📑 Table of Contents

- [The Core Problem](#-the-core-problem)
- [The Solution](#-the-solution)
- [System Architecture](#-system-architecture)
- [The Six Specialized AI Agents](#-the-six-specialized-ai-agents)
- [Key Innovations & Differentiators](#-key-innovations--differentiators)
- [Project Directory Structure](#-project-directory-structure)
- [Technology Stack](#-technology-stack)
- [Getting Started](#-getting-started)
  - [Prerequisites](#prerequisites)
  - [Installation](#1-installation)
  - [Environment Configuration](#2-environment-configuration)
  - [Running the Application](#3-running-the-application)
- [API Reference](#-api-reference)
- [Security & Transparency Guardrails](#-security--transparency-guardrails)
- [License](#-license)

---

## 🎯 The Core Problem

Every year, millions of engineering students and fresh graduates encounter three structural bottlenecks:

1. **The Skill Gap Paradox:** Academic curricula often focus on theoretical concepts, leaving students unaware of modern industry toolchains (e.g., containerization, CI/CD, asynchronous architectures) until they face rejection.
2. **Proliferation of Student Scams:** Desperate for early-career credentials, students regularly fall prey to "training-for-fees" rackets, phantom companies, fake offer letters demanding security deposits, and Telegram phishing schemes.
3. **The Unverified Credential Crisis:** Self-reported resume bullet points and superficial online course certificates have lost credibility among employers, yet students have had no transparent, rigorous platform to prove demonstrable mastery.

---

## 💡 The Solution

**SkillBridge AI** replaces disjointed chatbots and generic advice with a synchronized, **multi-agent intelligence collective**:

```
                              ┌────────────────────────────────────────┐
                              │       SkillBridge Web Interface        │
                              │    (React 18 + Tailwind CSS + Vite)    │
                              └───────────────────┬────────────────────┘
                                                  │
                                                  ▼
                              ┌────────────────────────────────────────┐
                              │      SkillBridge Intelligence Hub      │
                              │       Central Orchestration Engine     │
                              └───────────────────┬────────────────────┘
                                                  │
         ┌───────────────┬────────────────┼────────────────┬───────────────┬───────────────┐
         ▼               ▼                ▼                ▼               ▼               ▼
   ┌───────────┐   ┌───────────┐    ┌───────────┐    ┌───────────┐   ┌───────────┐   ┌───────────┐
   │  Agent 1  │   │  Agent 2  │    │  Agent 3  │    │  Agent 4  │   │  Agent 5  │   │  Agent 6  │
   │ Skill Gap │   │ Learning  │    │ Skill     │    │Opportunity│   │   Scam    │   │  Career   │
   │ Detector  │   │   Agent   │    │Verifier   │    │  Finder   │   │ Detection │   │ Guidance  │
   └───────────┘   └───────────┘    └───────────┘    └───────────┘   └───────────┘   └───────────┘
         │               │                │                │               │               │
         └───────────────┴────────────────┼────────────────┴───────────────┴───────────────┘
                                          │
                                          ▼
                              ┌────────────────────────┐
                              │  Shared Student State  │
                              │  & Verification Engine │
                              └────────────────────────┘
```

---

## 🤖 The Six Specialized AI Agents

### 1. Skill Gap Detector
* **Purpose:** Quantifies the precise delta between a student's current proficiencies and the prerequisite benchmark for their target career.
* **Capabilities:**
  - Evaluates student background across technical, tooling, and soft-skill domains.
  - Generates a granular competency breakdown with percentage readiness scores.
  - Automatically derives a **"Learn First" priority queue** based on foundational prerequisites.
  - Tracks competency evolution over time as lessons and assessments are completed.

### 2. Personalized Learning Agent
* **Purpose:** Designs dynamic, individualized curricula tailored to close identified gaps.
* **Capabilities:**
  - Generates structured 4-week modular roadmaps with daily milestones and capstones.
  - **Weakness Recovery System:** When a student struggles with a concept, the agent detects the conceptual blocker, translates abstract logic into concrete analogies, and provides targeted remedial exercises.
  - Recommends verified free video tutorials and interactive coding challenges.
  - Adjusts curriculum pacing based on continuous student performance telemetry.

### 3. Skill Verification Agent
* **Purpose:** Objectively validates whether students possess the capabilities they claim.
* **Capabilities:**
  - Implements timed, diagnostic multiple-choice and scenario-based assessments.
  - Issues cryptographic **SkillBridge Verified Badges** for scores $\ge 80\%$.
  - Strictly audits portfolio claims into three distinct tiers:
    - **Verified Skills:** Confirmed via timed assessments ($\ge 80\%$).
    - **Assessed Skills:** Tested but below benchmark ($50\% - 79\%$).
    - **Self-Reported Skills:** Unverified student claims requiring assessment.
  - *No misleading professional licensure or fake certifications are issued.*

### 4. Opportunity Finder Agent
* **Purpose:** Surfaces vetted internships, hackathons, fellowships, and open-source programs matched to verified student abilities.
* **Capabilities:**
  - Calculates a dynamic **Match Percentage** based on verified skill alignment.
  - Prioritizes beginner-friendly opportunities with zero application or registration fees.
  - Identifies missing prerequisites needed to qualify for competitive programs.
  - **1-Click Safety Bridge:** Allows instant hand-off of any opportunity listing to the Scam Detection Agent.

### 5. Scam Detection Agent
* **Purpose:** Shields students from fraudulent internships, fake recruiters, and financial schemes.
* **Capabilities:**
  - Multi-input forensic analyzer: scans job descriptions, URLs, recruiter emails, or WhatsApp messages.
  - Detects tell-tale markers: upfront registration/kit fees, inflated fresher salaries, pressure tactics, and disposable domains.
  - Categorizes threats into 4 calibrated risk tiers:
    - `Low Risk`
    - `Medium Risk`
    - `High Risk`
    - `Insufficient Information`
  - Explains the **exact rationale** behind risk scores rather than outputting arbitrary numbers.

### 6. Career Guidance Agent
* **Purpose:** Prepares students for technical and behavioral employer evaluation.
* **Capabilities:**
  - **ATS Resume Auditor:** Scores resume text against target job descriptions, identifies missing keywords, and rewrites bullet points using the **Google X-Y-Z formula** (*"Accomplished [X], as measured by [Y], by doing [Z]"*).
  - **Interactive Mock Interviewer:** Conducts simulated technical and HR interviews, evaluating answers using the **STAR method** (Situation, Task, Action, Result) with constructive feedback.

---

## 💎 Key Innovations & Differentiators

| Innovation | Description |
|---|---|
| **Transparent Readiness Score (0-100)** | A weighted, ungameable index: 30% Verified Skills + 25% Roadmap Progress + 20% Gap Closure + 15% Career Assets + 10% Consistency Streaks. |
| **Weakness Recovery System** | Closed-loop pedagogical intervention that re-teaches failed concepts using intuitive real-world analogies before re-testing. |
| **Three-Tier Audited Inventory** | Explicit demarcation between Verified, Assessed, and Self-Reported competencies to maintain industry trust. |
| **Scam Red-Flag Forensics** | Algorithmic detection of predatory student job postings with transparent evidence explanations. |
| **Dual Backend Option** | Fully functional Node.js Express server + alternative Python FastAPI microservice included in the codebase. |
| **High-Fidelity Demo Engine** | Zero-configuration local intelligence engine ensures the entire application runs flawlessly even without an external API key. |

---

## 📁 Project Directory Structure

```text
skillbridge-ai/
├── .env.example             # Clean configuration template with placeholders
├── .gitignore               # Production git exclusion rules (node_modules, dist, .env)
├── index.html               # Main single-page application entry point
├── package.json             # Frontend and backend Node dependencies
├── package-lock.json        # Deterministic dependency lockfile
├── postcss.config.js        # PostCSS configuration for Tailwind CSS
├── tailwind.config.js       # Custom design system configuration
├── tsconfig.json            # Strict TypeScript compiler options
├── vite.config.ts           # Vite bundler and development server configuration
├── start-skillbridge.bat    # Cross-platform Windows launcher script
├── test_suite.js            # Automated 8-step full-stack integration test suite
│
├── backend/                 # Python FastAPI alternative backend
│   ├── main.py              # FastAPI endpoints, CORS, and orchestrator routes
│   └── models.py            # Pydantic data schemas
│
├── data/                    # Generated instruction-tuning datasets & tool-call traces
│   ├── skillbridge_autoscientist_toolcaller.jsonl
│   ├── skillbridge_chat.jsonl
│   ├── skillbridge_dataset.csv
│   ├── skillbridge_dataset.json
│   └── skillbridge_instructions.jsonl
│
├── scripts/                 # Utility scripts
│   └── generate_dataset.py  # Dataset generator for fine-tuning & benchmarking
│
├── server/                  # Primary Node.js / Express Full-Stack Server
│   ├── index.js             # API route registration, static file serving, & auth
│   ├── agents/              # The 6 Specialized AI Agents & Hub
│   │   ├── careerAgent.js
│   │   ├── centralAssistant.js
│   │   ├── learningAgent.js
│   │   ├── opportunityAgent.js
│   │   ├── orchestrator.js
│   │   ├── scamAgent.js
│   │   ├── skillGapAgent.js
│   │   └── verificationAgent.js
│   ├── db/                  # Data layer
│   │   ├── database.js      # Persistent JSON file-backed database engine
│   │   └── skillbridge_data.json # Seeded student, career, and quiz database
│   ├── sample_data/         # Curated reference datasets
│   └── services/            # Shared business logic
│       ├── geminiService.js # Google Gemini LLM bridge with deterministic fallback
│       └── readinessCalculator.js # Transparent readiness algorithm
│
└── src/                     # React 18 TypeScript Frontend
    ├── App.tsx              # Root router and layout shell
    ├── main.tsx             # Application bootstrap
    ├── index.css            # Tailwind directives and custom scrollbars
    ├── types.ts             # Domain-wide TypeScript type definitions
    ├── components/          # Reusable UI widgets
    │   ├── AgentActivityPanel.tsx
    │   ├── CareerReportModal.tsx
    │   ├── DailyMissionsCard.tsx
    │   ├── Navbar.tsx
    │   ├── ReadinessGauge.tsx
    │   ├── Sidebar.tsx
    │   └── WeaknessRecoveryModal.tsx
    ├── context/             # React Context Providers
    │   ├── AgentContext.tsx # Central agent activity stream & state
    │   └── AuthContext.tsx  # User authentication and profile state
    ├── pages/               # Application Views
    │   ├── CareerCenterPage.tsx
    │   ├── DashboardPage.tsx
    │   ├── IntelligenceHubPage.tsx
    │   ├── LandingPage.tsx
    │   ├── LearningCenterPage.tsx
    │   ├── LoginPage.tsx
    │   ├── OnboardingPage.tsx
    │   ├── OpportunityCenterPage.tsx
    │   ├── ProfilePage.tsx
    │   ├── SafetyCenterPage.tsx
    │   ├── SettingsPage.tsx
    │   ├── SkillGapPage.tsx
    │   └── SkillVerificationPage.tsx
    └── services/
        └── api.ts           # Typed Axios/Fetch API client
```

---

## 🛠️ Technology Stack

* **Frontend:** React 18, TypeScript, Tailwind CSS, Lucide React Icons, Vite
* **Backend:** Node.js, Express.js (with optional Python 3.11 FastAPI microservice)
* **AI Orchestration:** Google Gemini 1.5 Flash API with built-in High-Fidelity Demo Fallback Engine
* **Persistence:** Local JSON Document Store with zero external database dependencies
* **Testing:** Custom end-to-end integration test runner (`test_suite.js`)

---

## 🚀 Getting Started

### Prerequisites

* [Node.js](https://nodejs.org/) (v18.0.0 or higher)
* [npm](https://www.npmjs.com/) (v9.0.0 or higher)
* [Python](https://www.python.org/) (v3.10+; optional, only required if using the FastAPI backend)

### 1. Installation

Clone the repository and install all dependencies:

```bash
git clone https://github.com/your-username/skillbridge-ai.git
cd skillbridge-ai
npm install
```

### 2. Environment Configuration

Copy the template configuration file:

```bash
cp .env.example .env
```

Open `.env` in your text editor:

```env
PORT=5000
NODE_ENV=development

# Optional: Add your Google Gemini API key from https://aistudio.google.com/
# If left blank, SkillBridge AI runs in High-Fidelity Demo Mode with zero errors.
GEMINI_API_KEY=
```

### 3. Running the Application

#### Option A: Unified Production Build (Recommended)
Build the frontend and run the full-stack server on a single port:

```bash
npm run build
node server/index.js
```
Open **[http://localhost:5000](http://localhost:5000)** in your browser.

#### Option B: Development Mode (Hot-Reloading)
Run backend and frontend independently for active development:

```bash
# Terminal 1: Backend Server (Port 5000)
node server/index.js

# Terminal 2: Vite Dev Server (Port 3000)
npm run client
```
Open **[http://localhost:3000](http://localhost:3000)** in your browser.

#### Option C: One-Click Windows Launcher
Double-click `start-skillbridge.bat` or run:
```cmd
start-skillbridge.bat
```

---

## 🔑 Demo Evaluator Credentials

A pre-configured student profile is included for immediate evaluation:

* **Email:** `alex@college.edu`
* **Password:** `student123`
* *(Or click the **"Demo Login (Alex Chen)"** button directly on the login screen).*

---

## 📡 API Reference

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/api/health` | System health check and registered agent inventory |
| `POST` | `/api/auth/login` | Student authentication |
| `GET` | `/api/student/profile` | Current student profile, skills, and progress |
| `POST` | `/api/student/onboard` | Complete student onboarding questionnaire |
| `GET` | `/api/student/readiness-score` | Granular breakdown of 0-100 Career Readiness Score |
| `POST` | `/api/agents/skill-gap/analyze` | Invoke Agent 1: Skill Gap Detector |
| `POST` | `/api/agents/learning/roadmap` | Invoke Agent 2: Personalized Learning Agent |
| `POST` | `/api/agents/learning/weakness-recovery` | Invoke Agent 2: Weakness Recovery System |
| `GET` | `/api/agents/verification/quiz` | Invoke Agent 3: Skill Verification diagnostic assessment |
| `POST` | `/api/agents/verification/submit` | Grade assessment and issue verification badge |
| `GET` | `/api/agents/opportunity/matches` | Invoke Agent 4: Opportunity Finder Agent |
| `POST` | `/api/agents/scam/analyze` | Invoke Agent 5: Scam Detection forensic scanner |
| `POST` | `/api/agents/career/resume-audit` | Invoke Agent 6: ATS Resume Auditor |
| `POST` | `/api/agents/career/mock-interview` | Invoke Agent 6: Mock Interview evaluation |
| `POST` | `/api/agents/assistant/message` | Conversational central routing via SkillBridge Assistant |

---

## 🔒 Security & Transparency Guardrails

1. **Zero Secret Leakage:** `.env` and sensitive credentials are unconditionally ignored by version control.
2. **Transparent AI Evidence:** The Scam Detection Agent outputs concrete structural red flags (unrealistic stipends, upfront fees, disposable domains) rather than opaque risk scores, explicitly reminding users that AI assessments should be verified independently.
3. **Anti-Hallucination Opportunity Filtering:** Opportunity listings are marked with explicit verification badges, distinguishing verified external competitions from sample educational listings.
4. **No Deceptive Accreditations:** Skill verification assessments generate skill performance badges, never misleading university degrees or certified legal licenses.

---

## 📄 License

This project is licensed under the [MIT License](LICENSE) - feel free to use, modify, and distribute for educational and commercial purposes.
