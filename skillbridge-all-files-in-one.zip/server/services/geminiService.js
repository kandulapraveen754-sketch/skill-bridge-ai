import dotenv from 'dotenv';
dotenv.config();

/**
 * SkillBridge AI Model Provider Service
 * Connects to Google Gemini API when configured,
 * or gracefully runs in local high-fidelity Demo Mode.
 */

export async function generateAgentResponse({
  agentName,
  systemInstruction,
  prompt,
  studentContext = null,
  structuredFormat = null,
  fallbackGenerator = null
}) {
  const apiKey = process.env.GEMINI_API_KEY || process.env.VITE_GEMINI_API_KEY;

  if (apiKey && apiKey.trim() !== '' && apiKey !== 'YOUR_GEMINI_API_KEY_HERE') {
    try {
      console.log(`[AI Engine] Invoking Gemini API for agent: ${agentName}...`);

      const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`;

      const contents = [
        {
          role: 'user',
          parts: [
            {
              text: `${systemInstruction}\n\n=== STUDENT PROFILE CONTEXT ===\n${JSON.stringify(studentContext, null, 2)}\n\n=== USER REQUEST ===\n${prompt}\n\n${structuredFormat ? `Respond STRICTLY in JSON format matching this schema:\n${structuredFormat}` : ''}`
            }
          ]
        }
      ];

      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents,
          generationConfig: {
            temperature: 0.3,
            maxOutputTokens: 2048,
            ...(structuredFormat ? { responseMimeType: 'application/json' } : {})
          }
        })
      });

      if (!res.ok) {
        const errorText = await res.text();
        console.warn(`[AI Engine] Gemini API returned error (${res.status}): ${errorText}. Falling back to high-fidelity demo engine.`);
      } else {
        const data = await res.json();
        const candidateText = data.candidates?.[0]?.content?.parts?.[0]?.text;
        if (candidateText) {
          let parsedData = candidateText;
          if (structuredFormat) {
            try {
              // Strip code fences if present
              const clean = candidateText.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
              parsedData = JSON.parse(clean);
            } catch (e) {
              console.warn('[AI Engine] Failed to parse JSON from Gemini candidate:', e);
            }
          }

          return {
            success: true,
            isDemoMode: false,
            aiModel: 'Gemini 1.5 Flash (Live API)',
            agentName,
            data: parsedData,
            rawText: candidateText,
            timestamp: new Date().toISOString()
          };
        }
      }
    } catch (err) {
      console.warn(`[AI Engine] Network error calling Gemini API: ${err.message}. Falling back to demo mode.`);
    }
  }

  // High-fidelity fallback / demo mode
  console.log(`[AI Engine] Generating intelligent simulated response for ${agentName} (Demo Mode)...`);
  const demoData = fallbackGenerator ? fallbackGenerator() : generateDefaultDemoResponse(agentName, prompt);

  return {
    success: true,
    isDemoMode: true,
    aiModel: 'SkillBridge Local Intelligence (Demo Mode)',
    demoNotice: 'Running in simulated demonstration mode. Configure GEMINI_API_KEY in .env for live Gemini API.',
    agentName,
    data: demoData,
    timestamp: new Date().toISOString()
  };
}

function generateDefaultDemoResponse(agentName, prompt) {
  return {
    summary: `Processed query with ${agentName}.`,
    details: `Intelligent insights generated for prompt: "${prompt.substring(0, 100)}..."`,
    status: 'completed'
  };
}
