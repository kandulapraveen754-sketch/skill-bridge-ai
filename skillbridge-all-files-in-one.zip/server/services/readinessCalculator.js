/**
 * Student Readiness Score Calculator
 * Calculates a transparent, fair, multidimensional score (0 - 100)
 * reflecting career preparedness.
 *
 * Formula Breakdown:
 * 1. Skill Verification Score (30%): Performance on verified quizzes (>= 80% passing)
 * 2. Learning Roadmap Progress (25%): % of required curriculum lessons completed
 * 3. Skill Gap Closure (20%): Count and depth of core skills acquired vs target career benchmark
 * 4. Career Asset Preparedness (15%): Resume audit score + Mock interview performance
 * 5. Learning Consistency & Streak (10%): Daily streak and mission completion
 */

export function calculateReadinessScore(student, targetCareer, roadmap = null, resumeAudit = null) {
  if (!student) {
    return {
      overallScore: 0,
      tier: 'Novice',
      breakdown: {
        verification: { score: 0, max: 30, percentage: 0 },
        learningRoadmap: { score: 0, max: 25, percentage: 0 },
        skillGapClosure: { score: 0, max: 20, percentage: 0 },
        careerAssets: { score: 0, max: 15, percentage: 0 },
        consistency: { score: 0, max: 10, percentage: 0 }
      },
      explanation: 'No student data available.'
    };
  }

  // 1. Skill Verification (Max 30 pts)
  const studentSkills = student.skills || [];
  const verifiedSkills = studentSkills.filter(s => s.verified && (s.verificationScore || 0) >= 80);
  const assessedSkills = studentSkills.filter(s => s.assessed && !s.verified);
  
  let verificationRaw = 0;
  if (studentSkills.length > 0) {
    const verifiedSum = verifiedSkills.reduce((acc, s) => acc + (s.verificationScore || 85), 0);
    const assessedSum = assessedSkills.reduce((acc, s) => acc + (s.verificationScore || 60), 0);
    const totalAssessedCount = verifiedSkills.length + assessedSkills.length;
    
    if (totalAssessedCount > 0) {
      const avgScore = (verifiedSum + assessedSum) / totalAssessedCount;
      verificationRaw = (avgScore / 100) * 30;
    }
  }
  const verificationScore = Math.min(30, Math.round(verificationRaw));

  // 2. Learning Roadmap Progress (Max 25 pts)
  let roadmapPercentage = 0;
  if (roadmap && roadmap.weeks && roadmap.weeks.length > 0) {
    let totalLessons = 0;
    let completedLessons = 0;
    for (const week of roadmap.weeks) {
      for (const lesson of week.lessons || []) {
        totalLessons++;
        if (lesson.completed) completedLessons++;
      }
    }
    if (totalLessons > 0) {
      roadmapPercentage = (completedLessons / totalLessons);
    }
  } else {
    // Default estimate based on completed lessons
    roadmapPercentage = 0.25;
  }
  const roadmapScore = Math.min(25, Math.round(roadmapPercentage * 25));

  // 3. Skill Gap Closure (Max 20 pts)
  let gapScoreRaw = 0;
  if (targetCareer && targetCareer.skills) {
    const requiredSkills = targetCareer.skills;
    let matchedWeight = 0;
    let totalWeight = 0;

    for (const req of requiredSkills) {
      const weight = req.weight || 10;
      totalWeight += weight;
      const found = studentSkills.find(s => s.name.toLowerCase() === req.name.toLowerCase());
      if (found) {
        if (found.verified) matchedWeight += weight;
        else if (found.assessed) matchedWeight += weight * 0.75;
        else matchedWeight += weight * 0.5; // self-reported only
      }
    }

    if (totalWeight > 0) {
      gapScoreRaw = (matchedWeight / totalWeight) * 20;
    }
  } else {
    gapScoreRaw = 10;
  }
  const skillGapScore = Math.min(20, Math.round(gapScoreRaw));

  // 4. Career Assets Preparedness (Max 15 pts)
  let careerAssetsRaw = 0;
  if (resumeAudit && resumeAudit.overallScore) {
    careerAssetsRaw = (resumeAudit.overallScore / 100) * 15;
  } else {
    careerAssetsRaw = 8; // baseline starter credit
  }
  const careerAssetsScore = Math.min(15, Math.round(careerAssetsRaw));

  // 5. Consistency & Streak (Max 10 pts)
  const streak = student.learningStreakDays || 0;
  const completedMissionsCount = (student.activeDailyMissions || []).filter(m => m.status === 'completed').length;
  
  let consistencyRaw = Math.min(6, (streak / 14) * 6) + Math.min(4, completedMissionsCount * 1.5);
  const consistencyScore = Math.min(10, Math.round(consistencyRaw));

  // Total
  const overallScore = Math.min(100, Math.max(0, verificationScore + roadmapScore + skillGapScore + careerAssetsScore + consistencyScore));

  let tier = 'Early Explorer';
  let tierBadge = 'bg-blue-500/20 text-blue-400 border-blue-500/30';
  if (overallScore >= 85) {
    tier = 'Industry Ready';
    tierBadge = 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
  } else if (overallScore >= 70) {
    tier = 'Internship Qualified';
    tierBadge = 'bg-brand-500/20 text-brand-300 border-brand-500/30';
  } else if (overallScore >= 50) {
    tier = 'Active Builder';
    tierBadge = 'bg-purple-500/20 text-purple-300 border-purple-500/30';
  }

  return {
    overallScore,
    tier,
    tierBadge,
    breakdown: {
      verification: {
        score: verificationScore,
        max: 30,
        percentage: Math.round((verificationScore / 30) * 100),
        label: 'Skill Verification',
        detail: `${verifiedSkills.length} skills verified via objective quizzes`
      },
      learningRoadmap: {
        score: roadmapScore,
        max: 25,
        percentage: Math.round((roadmapScore / 25) * 100),
        label: 'Roadmap Progress',
        detail: `${Math.round(roadmapPercentage * 100)}% of curriculum lessons finished`
      },
      skillGapClosure: {
        score: skillGapScore,
        max: 20,
        percentage: Math.round((skillGapScore / 20) * 100),
        label: 'Skill Gap Closure',
        detail: `Coverage of target career prerequisites`
      },
      careerAssets: {
        score: careerAssetsScore,
        max: 15,
        percentage: Math.round((careerAssetsScore / 15) * 100),
        label: 'Career Assets & Resume',
        detail: `ATS score, project portfolio, interview readiness`
      },
      consistency: {
        score: consistencyScore,
        max: 10,
        percentage: Math.round((consistencyScore / 10) * 100),
        label: 'Habits & Streaks',
        detail: `${streak}-day learning streak + daily missions`
      }
    },
    recommendations: [
      verificationScore < 20 ? 'Take the verification quiz for your unverified skills to boost score by up to 15 points.' : null,
      roadmapScore < 15 ? 'Complete 2 pending lessons this week to advance your roadmap tier.' : null,
      careerAssetsScore < 10 ? 'Submit your resume text to the Career Guidance Agent for ATS optimization.' : null
    ].filter(Boolean)
  };
}
