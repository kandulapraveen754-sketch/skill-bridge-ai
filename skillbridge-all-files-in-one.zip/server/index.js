import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

import { initDatabase, getDb, saveDatabase, logAgentActivity } from './db/database.js';
import { calculateReadinessScore } from './services/readinessCalculator.js';
import { analyzeSkillGap } from './agents/skillGapAgent.js';
import { generatePersonalizedRoadmap, explainConcept, triggerWeaknessRecovery } from './agents/learningAgent.js';
import { getQuizForSkill, evaluateQuizSubmission } from './agents/verificationAgent.js';
import { findOpportunities, prepareOpportunitySafetyCheck } from './agents/opportunityAgent.js';
import { analyzeOpportunityRisk, getScamAnalysisHistory } from './agents/scamAgent.js';
import { auditResume, generateInterviewQuestions, evaluateInterviewAnswer } from './agents/careerAgent.js';
import { runFullCareerLaunchpadWorkflow } from './agents/orchestrator.js';
import { processAssistantMessage } from './agents/centralAssistant.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json({ limit: '10mb' }));

// Initialize persistent DB state
initDatabase();

// Health Check
app.get('/api/health', (req, res) => {
  const db = getDb();
  res.json({
    status: 'ok',
    platform: 'SkillBridge AI',
    version: '1.0.0',
    aiProvider: process.env.GEMINI_API_KEY ? 'Gemini 1.5 Flash (Configured)' : 'Local Intelligence Engine (Demo Mode Active)',
    registeredAgents: [
      'Skill Gap Detector',
      'Personalized Learning Agent',
      'Skill Verification Agent',
      'Opportunity Finder Agent',
      'Scam Detection Agent',
      'Career Guidance Agent',
      'SkillBridge Assistant',
      'SkillBridge Intelligence Hub'
    ],
    timestamp: new Date().toISOString()
  });
});

// AUTH ROUTES
app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  const db = getDb();

  let user = db.users.find(u => u.email.toLowerCase() === (email || '').toLowerCase());
  
  // If demo credentials or unknown user in demo mode, provide or create session
  if (!user && (!email || email.includes('alex'))) {
    user = db.users[0];
  } else if (!user) {
    user = {
      id: `user-${Date.now()}`,
      email: email || 'student@university.edu',
      name: email?.split('@')[0] || 'Student',
      studentId: 'std-alex-chen',
      createdAt: new Date().toISOString()
    };
    db.users.push(user);
    saveDatabase();
  }

  const student = db.students[user.studentId] || Object.values(db.students)[0];

  res.json({
    success: true,
    token: `skb_jwt_${user.id}_${Date.now()}`,
    user: {
      id: user.id,
      email: user.email,
      name: user.name,
      studentId: user.studentId
    },
    student
  });
});

app.post('/api/auth/register', (req, res) => {
  const { name, email, password, college, degree, yearOfStudy, targetCareerId, skills = [] } = req.body;
  const db = getDb();

  const studentId = `std-${Date.now()}`;
  const userId = `user-${Date.now()}`;

  const newStudent = {
    id: studentId,
    name: name || 'Student',
    email: email || `${studentId}@university.edu`,
    college: college || 'University Engineering Campus',
    degree: degree || 'Computer Science & Engineering',
    yearOfStudy: yearOfStudy || '3rd Year',
    targetCareerId: targetCareerId || 'ai-ml-engineer',
    targetCareerTitle: db.careers.find(c => c.id === targetCareerId)?.title || 'AI / Machine Learning Engineer',
    learningGoals: 'Master core skills, pass verification tests, and secure an internship.',
    learningStreakDays: 1,
    weeklyStudyHours: 10,
    preferredPace: 'Standard',
    skills: skills.length > 0 ? skills : [
      { name: "Python", level: "Beginner", verified: false, verificationScore: 0, assessed: false, selfReported: true, verifiedAt: null },
      { name: "Git & GitHub", level: "Beginner", verified: false, verificationScore: 0, assessed: false, selfReported: true, verifiedAt: null }
    ],
    activeDailyMissions: [
      { id: 'm1', agent: 'Skill Gap Detector', task: 'Review your initial skill gap analysis', status: 'pending', xp: 50, skill: 'General' },
      { id: 'm2', agent: 'Personalized Learning Agent', task: 'Complete your first curriculum lesson', status: 'pending', xp: 75, skill: 'Curriculum' },
      { id: 'm3', agent: 'Skill Verification Agent', task: 'Take a diagnostic quiz to earn a verified badge', status: 'pending', xp: 100, skill: 'Verification' }
    ],
    recentActivities: [
      {
        id: `act-${Date.now()}`,
        agent: 'Intelligence Hub',
        action: 'Account Created & Onboarding Completed',
        status: 'success',
        timestamp: new Date().toISOString(),
        summary: `Profile initialized for ${name || 'Student'} aiming for ${targetCareerId || 'Engineering'}.`
      }
    ]
  };

  const newUser = {
    id: userId,
    email: newStudent.email,
    password: password || 'default_pass',
    name: newStudent.name,
    studentId,
    createdAt: new Date().toISOString()
  };

  db.users.push(newUser);
  db.students[studentId] = newStudent;
  saveDatabase();

  res.json({
    success: true,
    token: `skb_jwt_${userId}_${Date.now()}`,
    user: {
      id: userId,
      email: newUser.email,
      name: newUser.name,
      studentId
    },
    student: newStudent
  });
});

// STUDENT PROFILE ROUTES
app.get('/api/student/profile', (req, res) => {
  const db = getDb();
  const studentId = req.query.studentId || 'std-alex-chen';
  const student = db.students[studentId] || Object.values(db.students)[0];
  res.json({ success: true, student });
});

app.put('/api/student/profile', (req, res) => {
  const db = getDb();
  const studentId = req.body.id || req.body.studentId || 'std-alex-chen';
  if (!db.students[studentId]) {
    return res.status(404).json({ error: 'Student not found' });
  }

  db.students[studentId] = {
    ...db.students[studentId],
    ...req.body
  };
  saveDatabase();

  logAgentActivity({
    agent: 'SkillBridge Hub',
    action: 'Student Profile Updated',
    summary: `Updated career goal to ${db.students[studentId].targetCareerTitle || db.students[studentId].targetCareerId}.`,
    studentId
  });

  res.json({ success: true, student: db.students[studentId] });
});

app.get('/api/student/readiness', (req, res) => {
  const db = getDb();
  const studentId = req.query.studentId || 'std-alex-chen';
  const student = db.students[studentId] || Object.values(db.students)[0];
  const career = db.careers.find(c => c.id === student?.targetCareerId) || db.careers[0];
  const roadmap = db.roadmaps[studentId] || Object.values(db.roadmaps)[0];
  const lastResumeAudit = (db.resumeAnalyses || [])[0];

  const readiness = calculateReadinessScore(student, career, roadmap, lastResumeAudit);
  res.json({ success: true, readiness });
});

app.post('/api/student/missions/complete', (req, res) => {
  const { missionId, studentId = 'std-alex-chen' } = req.body;
  const db = getDb();
  const student = db.students[studentId] || Object.values(db.students)[0];

  if (student && student.activeDailyMissions) {
    const mission = student.activeDailyMissions.find(m => m.id === missionId);
    if (mission) {
      mission.status = 'completed';
      student.learningStreakDays = (student.learningStreakDays || 0) + 1;
      saveDatabase();

      logAgentActivity({
        agent: mission.agent || 'Personalized Learning Agent',
        action: 'Completed Daily Mission',
        summary: `Finished task: "${mission.task}". Streak extended to ${student.learningStreakDays} days!`,
        studentId
      });

      return res.json({ success: true, mission, streak: student.learningStreakDays });
    }
  }

  res.status(404).json({ error: 'Mission not found' });
});

// CAREERS CATALOG
app.get('/api/careers', (req, res) => {
  const db = getDb();
  res.json({ success: true, careers: db.careers });
});

// AGENT 1: SKILL GAP DETECTOR
app.post('/api/agents/skill-gap/analyze', async (req, res) => {
  try {
    const { studentId = 'std-alex-chen', targetCareerId } = req.body;
    const db = getDb();
    const student = db.students[studentId] || Object.values(db.students)[0];
    const targetCareer = db.careers.find(c => c.id === (targetCareerId || student?.targetCareerId)) || db.careers[0];

    const report = await analyzeSkillGap({ student, targetCareer });
    res.json({ success: true, report });
  } catch (err) {
    console.error('[Agent 1 Error]:', err);
    res.status(500).json({ error: err.message });
  }
});

// AGENT 2: PERSONALIZED LEARNING AGENT
app.post('/api/agents/learning/roadmap', async (req, res) => {
  try {
    const { studentId = 'std-alex-chen', targetCareerId, durationWeeks = 4 } = req.body;
    const db = getDb();
    const student = db.students[studentId] || Object.values(db.students)[0];
    const targetCareer = db.careers.find(c => c.id === (targetCareerId || student?.targetCareerId)) || db.careers[0];

    // Return cached roadmap if exists and matches career
    if (db.roadmaps[studentId] && db.roadmaps[studentId].careerId === targetCareer.id) {
      return res.json({ success: true, roadmap: db.roadmaps[studentId] });
    }

    const roadmap = await generatePersonalizedRoadmap({ student, targetCareer, durationWeeks });
    db.roadmaps[studentId] = {
      careerId: targetCareer.id,
      generatedAt: new Date().toISOString(),
      ...roadmap
    };
    saveDatabase();

    res.json({ success: true, roadmap: db.roadmaps[studentId] });
  } catch (err) {
    console.error('[Agent 2 Error]:', err);
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/agents/learning/explain', async (req, res) => {
  try {
    const { topic, difficulty = 'Beginner', context = '' } = req.body;
    if (!topic) return res.status(400).json({ error: 'Topic is required' });

    const explanation = await explainConcept({ topic, difficulty, context });
    res.json({ success: true, explanation });
  } catch (err) {
    console.error('[Agent 2 Explain Error]:', err);
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/agents/learning/complete-lesson', (req, res) => {
  const { lessonId, studentId = 'std-alex-chen' } = req.body;
  const db = getDb();
  const roadmap = db.roadmaps[studentId] || Object.values(db.roadmaps)[0];

  let found = false;
  if (roadmap && roadmap.weeks) {
    for (const week of roadmap.weeks) {
      for (const lesson of week.lessons || []) {
        if (lesson.id === lessonId) {
          lesson.completed = !lesson.completed;
          found = true;
          break;
        }
      }
      if (found) break;
    }
  }

  if (found) {
    saveDatabase();
    logAgentActivity({
      agent: 'Personalized Learning Agent',
      action: 'Lesson Progress Updated',
      summary: `Toggled completion for lesson ${lessonId}.`,
      studentId
    });
    return res.json({ success: true, roadmap });
  }

  res.status(404).json({ error: 'Lesson not found' });
});

app.post('/api/agents/learning/weakness-recovery', async (req, res) => {
  try {
    const { weakTopic, studentId = 'std-alex-chen', failedQuestionDetails } = req.body;
    const db = getDb();
    const student = db.students[studentId] || Object.values(db.students)[0];

    const recoveryPlan = await triggerWeaknessRecovery({ student, weakTopic, failedQuestionDetails });
    res.json({ success: true, recoveryPlan });
  } catch (err) {
    console.error('[Agent 2 Recovery Error]:', err);
    res.status(500).json({ error: err.message });
  }
});

// AGENT 3: SKILL VERIFICATION AGENT
app.get('/api/agents/verification/quiz', async (req, res) => {
  try {
    const { skillName = 'Python', difficulty = 'Intermediate' } = req.query;
    const quiz = await getQuizForSkill({ skillName, difficulty });
    res.json({ success: true, quiz });
  } catch (err) {
    console.error('[Agent 3 Quiz Error]:', err);
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/agents/verification/submit', async (req, res) => {
  try {
    const { skillName, answers, quiz, studentId = 'std-alex-chen' } = req.body;
    const evaluation = await evaluateQuizSubmission({ studentId, skillName, answers, quiz });
    res.json({ success: true, evaluation });
  } catch (err) {
    console.error('[Agent 3 Submit Error]:', err);
    res.status(500).json({ error: err.message });
  }
});

// AGENT 4: OPPORTUNITY FINDER AGENT
app.get('/api/agents/opportunities', (req, res) => {
  try {
    const { category, isRemote, isBeginnerFriendly, search, studentId = 'std-alex-chen' } = req.query;
    const db = getDb();
    const student = db.students[studentId] || Object.values(db.students)[0];

    const remoteBool = isRemote !== undefined ? isRemote === 'true' : null;
    const beginnerBool = isBeginnerFriendly !== undefined ? isBeginnerFriendly === 'true' : null;

    const result = findOpportunities({
      student,
      category,
      isRemote: remoteBool,
      isBeginnerFriendly: beginnerBool,
      searchQuery: search || ''
    });

    res.json({ success: true, ...result });
  } catch (err) {
    console.error('[Agent 4 Error]:', err);
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/agents/opportunities/:id/safety-bridge', (req, res) => {
  const { id } = req.params;
  const payload = prepareOpportunitySafetyCheck(id);
  if (!payload) return res.status(404).json({ error: 'Opportunity not found' });
  res.json({ success: true, safetyBridge: payload });
});

// AGENT 5: SCAM DETECTION AGENT
app.post('/api/agents/scam/analyze', async (req, res) => {
  try {
    const { text, url, companyName, studentId = 'std-alex-chen' } = req.body;
    if (!text && !url) {
      return res.status(400).json({ error: 'Please provide job description text or website URL.' });
    }

    const report = await analyzeOpportunityRisk({
      textToAnalyze: text || '',
      url: url || '',
      companyName: companyName || '',
      studentId
    });

    res.json({ success: true, report });
  } catch (err) {
    console.error('[Agent 5 Error]:', err);
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/agents/scam/history', (req, res) => {
  const { studentId = 'std-alex-chen' } = req.query;
  const history = getScamAnalysisHistory(studentId);
  res.json({ success: true, history });
});

// AGENT 6: CAREER GUIDANCE AGENT
app.post('/api/agents/career/resume-audit', async (req, res) => {
  try {
    const { resumeText, targetCareerTitle, studentId = 'std-alex-chen' } = req.body;
    if (!resumeText || resumeText.trim().length < 30) {
      return res.status(400).json({ error: 'Please provide full resume text (at least 30 characters).' });
    }

    const audit = await auditResume({ resumeText, targetCareerTitle, studentId });
    res.json({ success: true, audit });
  } catch (err) {
    console.error('[Agent 6 Resume Error]:', err);
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/agents/career/interview-questions', async (req, res) => {
  try {
    const { targetCareerTitle = 'Software Engineer', questionType = 'technical', count = 3 } = req.body;
    const questions = await generateInterviewQuestions({ targetCareerTitle, questionType, count });
    res.json({ success: true, questions });
  } catch (err) {
    console.error('[Agent 6 Interview Questions Error]:', err);
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/agents/career/evaluate-interview', async (req, res) => {
  try {
    const { question, studentAnswer, targetRole } = req.body;
    if (!question || !studentAnswer) {
      return res.status(400).json({ error: 'Question and answer are required.' });
    }

    const feedback = await evaluateInterviewAnswer({ question, studentAnswer, targetRole });
    res.json({ success: true, feedback });
  } catch (err) {
    console.error('[Agent 6 Interview Eval Error]:', err);
    res.status(500).json({ error: err.message });
  }
});

// INTELLIGENCE HUB & CENTRAL ASSISTANT
app.post('/api/agents/hub/workflow', async (req, res) => {
  try {
    const { studentId = 'std-alex-chen', targetCareerId } = req.body;
    const result = await runFullCareerLaunchpadWorkflow({ studentId, targetCareerId });
    res.json({ success: true, result });
  } catch (err) {
    console.error('[Intelligence Hub Workflow Error]:', err);
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/agents/assistant/chat', async (req, res) => {
  try {
    const { message, studentId = 'std-alex-chen', conversationHistory = [] } = req.body;
    if (!message) return res.status(400).json({ error: 'Message is required' });

    const reply = await processAssistantMessage({ message, studentId, conversationHistory });
    res.json({ success: true, reply });
  } catch (err) {
    console.error('[Central Assistant Chat Error]:', err);
    res.status(500).json({ error: err.message });
  }
});

// REAL-TIME ACTIVITY FEED
app.get('/api/agents/activities', (req, res) => {
  const db = getDb();
  res.json({ success: true, activities: db.activityLogs || [] });
});

// CAREER READINESS REPORT DOWNLOAD / VIEW
app.get('/api/report/career-readiness', (req, res) => {
  const db = getDb();
  const studentId = req.query.studentId || 'std-alex-chen';
  const student = db.students[studentId] || Object.values(db.students)[0];
  const career = db.careers.find(c => c.id === student?.targetCareerId) || db.careers[0];
  const roadmap = db.roadmaps[studentId] || Object.values(db.roadmaps)[0];
  const lastResumeAudit = (db.resumeAnalyses || [])[0];

  const readiness = calculateReadinessScore(student, career, roadmap, lastResumeAudit);

  res.json({
    success: true,
    report: {
      generatedAt: new Date().toISOString(),
      studentProfile: {
        name: student.name,
        email: student.email,
        college: student.college,
        degree: student.degree,
        yearOfStudy: student.yearOfStudy,
        streakDays: student.learningStreakDays
      },
      targetCareer: {
        title: career.title,
        category: career.category,
        averageSalary: career.averageSalary,
        outlook: career.jobOutlook
      },
      readinessScore: readiness.overallScore,
      tier: readiness.tier,
      scoreBreakdown: readiness.breakdown,
      skillsInventory: {
        verifiedSkills: (student.skills || []).filter(s => s.verified),
        assessedSkills: (student.skills || []).filter(s => s.assessed && !s.verified),
        selfReportedSkills: (student.skills || []).filter(s => s.selfReported)
      },
      recommendations: readiness.recommendations,
      disclaimer: "SkillBridge AI Career Readiness Reports are compiled using objective assessment rubrics and student activity logs. No misleading professional certifications are claimed."
    }
  });
});

// Serve compiled frontend production bundle if exists
const distPath = path.join(__dirname, '../dist');
if (fs.existsSync(distPath)) {
  app.use(express.static(distPath));
  app.get('*', (req, res, next) => {
    if (req.path.startsWith('/api')) return next();
    res.sendFile(path.join(distPath, 'index.html'));
  });
}

app.listen(PORT, () => {
  console.log(`[SkillBridge Backend] Server running on http://localhost:${PORT}`);
  console.log(`[SkillBridge Hub] 6 Specialized AI Agents Ready & Orchestrated.`);
});
