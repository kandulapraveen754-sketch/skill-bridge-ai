import { generateAgentResponse } from '../services/geminiService.js';
import { analyzeSkillGap } from './skillGapAgent.js';
import { generatePersonalizedRoadmap, explainConcept } from './learningAgent.js';
import { findOpportunities } from './opportunityAgent.js';
import { analyzeOpportunityRisk } from './scamAgent.js';
import { auditResume, generateInterviewQuestions } from './careerAgent.js';
import { getDb, logAgentActivity } from '../db/database.js';

/**
 * Central AI Assistant: SkillBridge Assistant
 * Intelligent conversational router and compound query synthesizer.
 */

export async function processAssistantMessage({ message, studentId = 'std-alex-chen', conversationHistory = [] }) {
  const db = getDb();
  const student = db.students[studentId] || Object.values(db.students)[0];
  const targetCareer = db.careers.find(c => c.id === student?.targetCareerId) || db.careers[0];

  const msgLower = message.toLowerCase().trim();

  // 1. Intent Detection & Routing Engine
  let routedAgent = 'Intelligence Hub';
  let agentResponse = null;
  let compoundAction = false;

  // Check for Scam / Safety intent
  if (msgLower.includes('scam') || msgLower.includes('fake') || msgLower.includes('deposit') || msgLower.includes('legit') || msgLower.includes('fee') || msgLower.includes('suspicious') || msgLower.includes('fraud')) {
    routedAgent = 'Scam Detection Agent';
    agentResponse = await analyzeOpportunityRisk({
      textToAnalyze: message,
      studentId
    });
  }
  // Check for Quiz / Verification intent
  else if (msgLower.includes('test') || msgLower.includes('quiz') || msgLower.includes('verify') || msgLower.includes('assess') || msgLower.includes('challenge')) {
    routedAgent = 'Skill Verification Agent';
    let targetSkill = 'Python';
    if (msgLower.includes('react') || msgLower.includes('ui')) targetSkill = 'React & Modern UI';
    else if (msgLower.includes('machine learning') || msgLower.includes('ml')) targetSkill = 'Machine Learning (Scikit-Learn)';

    agentResponse = {
      action: 'start_quiz',
      skillName: targetSkill,
      message: `I've routed your request to the Skill Verification Agent! Ready to assess your **${targetSkill}** proficiency? Click below to begin the 4-question interactive assessment and earn your verified badge.`
    };
  }
  // Check for Opportunities intent
  else if (msgLower.includes('internship') || msgLower.includes('hackathon') || msgLower.includes('job') || msgLower.includes('opportunity') || msgLower.includes('scholarship') || msgLower.includes('fellowship')) {
    routedAgent = 'Opportunity Finder Agent';
    const isBeginner = msgLower.includes('beginner') || msgLower.includes('fresher') || msgLower.includes('no experience');
    const matched = findOpportunities({ student, isBeginnerFriendly: isBeginner || true });
    agentResponse = {
      action: 'view_opportunities',
      topOpportunities: matched.opportunities.slice(0, 3),
      message: `I searched genuine student listings for you! Found **${matched.totalCount} matches**, prioritizing beginner-friendly programs with active stipend or mentorship support.`
    };
  }
  // Check for Resume / Interview intent
  else if (msgLower.includes('resume') || msgLower.includes('cv') || msgLower.includes('interview') || msgLower.includes('ats')) {
    routedAgent = 'Career Guidance Agent';
    if (msgLower.includes('interview')) {
      const qType = msgLower.includes('behavioral') ? 'behavioral' : 'technical';
      const questions = await generateInterviewQuestions({ targetCareerTitle: targetCareer.title, questionType: qType, count: 2 });
      agentResponse = {
        action: 'interview_practice',
        questions,
        message: `I've prepared 2 tailored ${qType} interview questions for the **${targetCareer.title}** role. Try answering one and I will evaluate your response with STAR feedback!`
      };
    } else {
      agentResponse = {
        action: 'resume_audit_ready',
        message: `You can paste your complete resume text into the Career Guidance Center for a line-by-line ATS match, missing section flags, and metric-driven bullet point rewrites.`
      };
    }
  }
  // Check for "Where to start / Career Roadmap" compound intent
  else if (msgLower.includes('start') || msgLower.includes('roadmap') || msgLower.includes('become') || msgLower.includes('how to learn') || msgLower.includes('skill gap')) {
    routedAgent = 'Intelligence Hub (Multi-Agent Compound)';
    compoundAction = true;

    // Call Skill Gap Detector + Learning Agent
    const gap = await analyzeSkillGap({ student, targetCareer });
    const roadmap = await generatePersonalizedRoadmap({ student, targetCareer, durationWeeks: 4 });

    agentResponse = {
      action: 'compound_career_plan',
      gapAnalysis: {
        career: targetCareer.title,
        matchPercentage: gap.overallMatchPercentage,
        prioritySkills: gap.priorityToLearn
      },
      roadmapPreview: {
        title: roadmap.title,
        week1: roadmap.weeks?.[0]?.title,
        week1Objective: roadmap.weeks?.[0]?.objective
      }
    };
  }
  // Default concept explanation or general career Q&A
  else {
    routedAgent = 'Personalized Learning Agent';
    const explanation = await explainConcept({ topic: message.substring(0, 50), difficulty: 'Beginner' });
    agentResponse = explanation;
  }

  // Synthesize conversational response via Gemini / Fallback
  const systemInstruction = `You are "SkillBridge Assistant", the central conversational AI guide for SkillBridge AI.
The student asked: "${message}".
You coordinated with specialized agent: "${routedAgent}".
Data gathered: ${JSON.stringify(agentResponse, null, 2)}.
Craft an inspiring, friendly, highly clear response.
Use bullet points, bold highlights, and direct next steps.
Do not talk like a generic robot; talk like a brilliant, empathetic career mentor!`;

  const fallback = () => {
    if (compoundAction) {
      return `Welcome! Here is your step-by-step career path for **${targetCareer.title}**:

1. **Skill Gap Analysis (via Skill Gap Detector)**:
   - Current readiness match: **${agentResponse.gapAnalysis.matchPercentage}%**
   - Critical skills to learn first: **${agentResponse.gapAnalysis.prioritySkills.join(', ')}**

2. **Personalized Learning Plan (via Learning Agent)**:
   - **Week 1 Focus**: ${agentResponse.roadmapPreview.week1}
   - ${agentResponse.roadmapPreview.week1Objective}

3. **Recommended Next Action**:
   - Head over to the **Learning Center** to start Lesson 1 or visit **Skill Verification** to certify your Python knowledge!`;
    }

    if (routedAgent === 'Scam Detection Agent') {
      return `⚠️ **Safety Warning from Scam Detection Agent:**

I analyzed the message you shared. Risk Classification: **${agentResponse.riskCategory}** (${agentResponse.riskScore}/100 Risk).

**Identified Red Flags:**
${(agentResponse.detectedRedFlags || []).map(rf => `- **${rf.name}**: ${rf.explanation}`).join('\n') || '- Inconclusive or missing company data.'}

**Mentor Advice:**
${agentResponse.whySuspicious}

Never pay upfront deposits or share private OTPs to secure an internship!`;
    }

    if (routedAgent === 'Opportunity Finder Agent') {
      return `🎯 **Curated Opportunities Found!**

I discovered **${agentResponse.topOpportunities?.length || 3} top matches** tailored to your current profile:

${(agentResponse.topOpportunities || []).map(o => `• **${o.title}** at *${o.organization}*\n  - Match: **${o.matchPercentage}%** | Stipend: ${o.stipend} | Location: ${o.location}`).join('\n\n')}

You can view details and run 1-click safety checks in the **Opportunity Center**!`;
    }

    return `Here are the insights from the **${routedAgent}**:

${agentResponse.message || agentResponse.simpleExplanation || 'Ready to assist your career journey.'}

Feel free to ask a follow-up question or explore the specialized tools in the sidebar!`;
  };

  const aiResult = await generateAgentResponse({
    agentName: 'SkillBridge Assistant',
    systemInstruction,
    prompt: `Synthesize answer for: "${message}"\nRouted agent: ${routedAgent}\nAgent Data: ${JSON.stringify(agentResponse)}`,
    studentContext: student,
    fallbackGenerator: fallback
  });

  const finalResponse = {
    messageId: `msg-${Date.now()}`,
    sender: 'assistant',
    text: typeof aiResult.data === 'string' ? aiResult.data : fallback(),
    routedAgent,
    agentData: agentResponse,
    isDemoMode: aiResult.isDemoMode,
    aiModel: aiResult.aiModel,
    timestamp: new Date().toISOString()
  };

  logAgentActivity({
    agent: 'SkillBridge Assistant',
    action: `Answered question via ${routedAgent}`,
    summary: `Routed to ${routedAgent}: "${message.substring(0, 45)}..."`,
    studentId
  });

  return finalResponse;
}
