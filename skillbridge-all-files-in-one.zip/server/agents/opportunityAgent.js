import { getDb, logAgentActivity } from '../db/database.js';

/**
 * Agent 4: Opportunity Finder Agent
 * Discovers and matches internships, hackathons, scholarships, and fellowships
 * based on the student's verified and self-reported skill profile.
 */

export function findOpportunities({
  student,
  category = 'all',
  isRemote = null,
  isBeginnerFriendly = null,
  searchQuery = ''
}) {
  const db = getDb();
  let list = db.opportunities || [];

  // Filter category
  if (category && category !== 'all') {
    list = list.filter(opp => opp.category.toLowerCase().includes(category.toLowerCase()));
  }

  // Filter remote
  if (isRemote !== null && isRemote !== undefined) {
    list = list.filter(opp => opp.isRemote === isRemote);
  }

  // Filter beginner-friendly
  if (isBeginnerFriendly !== null && isBeginnerFriendly !== undefined) {
    list = list.filter(opp => opp.isBeginnerFriendly === isBeginnerFriendly);
  }

  // Search keyword query
  if (searchQuery && searchQuery.trim() !== '') {
    const q = searchQuery.toLowerCase().trim();
    list = list.filter(opp =>
      opp.title.toLowerCase().includes(q) ||
      opp.organization.toLowerCase().includes(q) ||
      opp.description.toLowerCase().includes(q) ||
      (opp.requiredSkills || []).some(s => s.toLowerCase().includes(q))
    );
  }

  // Calculate Match Score for each opportunity against the student profile
  const studentSkills = (student?.skills || []).map(s => ({
    name: s.name.toLowerCase(),
    verified: !!s.verified,
    level: s.level
  }));

  const matchedOpportunities = list.map(opp => {
    const required = opp.requiredSkills || [];
    let matchedCount = 0;
    let verifiedMatchCount = 0;
    const missingPrerequisites = [];

    required.forEach(req => {
      const match = studentSkills.find(s => s.name.includes(req.toLowerCase()) || req.toLowerCase().includes(s.name));
      if (match) {
        matchedCount++;
        if (match.verified) verifiedMatchCount++;
      } else {
        missingPrerequisites.push(req);
      }
    });

    const matchPercentage = required.length > 0
      ? Math.round(((matchedCount * 0.7 + verifiedMatchCount * 0.3) / required.length) * 100)
      : 100;

    let qualificationTier = 'Strong Fit';
    if (matchPercentage < 50) qualificationTier = 'Reach Opportunity';
    else if (matchPercentage < 80) qualificationTier = 'Skill Gaps Exist';

    return {
      ...opp,
      matchPercentage: Math.min(100, matchPercentage),
      qualificationTier,
      matchedCount,
      totalRequiredCount: required.length,
      missingPrerequisites,
      actionTip: missingPrerequisites.length > 0
        ? `Learn ${missingPrerequisites.slice(0, 2).join(' & ')} to increase your acceptance odds by 3x.`
        : 'Your verified skill profile directly fulfills all listed requirements!'
    };
  });

  // Sort by match percentage descending, with beginner-friendly prioritized for beginners
  matchedOpportunities.sort((a, b) => {
    if (student?.yearOfStudy?.includes('1st') || student?.yearOfStudy?.includes('2nd')) {
      if (a.isBeginnerFriendly && !b.isBeginnerFriendly) return -1;
      if (!a.isBeginnerFriendly && b.isBeginnerFriendly) return 1;
    }
    return b.matchPercentage - a.matchPercentage;
  });

  logAgentActivity({
    agent: 'Opportunity Finder Agent',
    action: 'Matched opportunities for student',
    summary: `Found ${matchedOpportunities.length} opportunities. Top match: ${matchedOpportunities[0]?.title || 'None'}.`
  });

  return {
    totalCount: matchedOpportunities.length,
    opportunities: matchedOpportunities,
    curatedNotice: "All listings are curated sample programs or verified official student portals. Always verify active deadlines at the official link."
  };
}

/**
 * Prepares safety payload to bridge directly from Opportunity Finder to Agent 5 (Scam Detection)
 */
export function prepareOpportunitySafetyCheck(opportunityId) {
  const db = getDb();
  const opp = (db.opportunities || []).find(o => o.id === opportunityId);
  if (!opp) return null;

  return {
    targetId: opp.id,
    targetTitle: opp.title,
    organization: opp.organization,
    payloadText: `Title: ${opp.title}\nCompany: ${opp.organization}\nType: ${opp.type}\nStipend/Offer: ${opp.stipend}\nURL: ${opp.url}\nDescription: ${opp.description}\nEligibility: ${opp.eligibility}`,
    url: opp.url,
    knownSafetyScore: opp.safetyScore,
    knownSafetyTag: opp.safetyTag
  };
}
