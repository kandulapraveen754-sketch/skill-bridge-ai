import { generateAgentResponse } from '../services/geminiService.js';
import { getDb, saveDatabase, logAgentActivity } from '../db/database.js';

/**
 * Agent 5: Scam Detection Agent
 * Detects fake internships, upfront fee scams, phishing recruiters, and pressure tactics.
 * Provides risk classification (Low, Medium, High, Insufficient Info), granular evidence,
 * and safety precautions with transparent uncertainty notices.
 */

export async function analyzeOpportunityRisk({ textToAnalyze, url = '', companyName = '', studentId = 'std-alex-chen' }) {
  const db = getDb();
  const patterns = db.scamPatterns || [];

  const textLower = (textToAnalyze + ' ' + (url || '') + ' ' + (companyName || '')).toLowerCase();

  // Rule-based heuristic pattern matching
  const detectedRedFlags = [];
  let computedRiskScore = 15; // baseline healthy baseline (0-100 where 100 = critical fraud)

  if (textLower.trim().length < 40) {
    // Insufficient Information
    return {
      id: `scam-${Date.now()}`,
      riskCategory: "INSUFFICIENT_INFORMATION",
      riskBadge: "bg-slate-700/60 text-slate-300 border-slate-600",
      riskScore: 25,
      confidenceScore: 30,
      summary: "Too little text was provided to make a conclusive assessment.",
      redFlags: ["Short or vague input lacking company details, recruiter contact, or compensation structure."],
      whySuspicious: "Authentic corporate job postings provide detailed team descriptions, legal entity registrations, and clear scope of work.",
      safetyRecommendations: [
        "Ask the sender for an official job specification sheet.",
        "Request their corporate email address ending in the company domain name.",
        "Verify if the company exists on official government company registries (e.g. MCA, SEC, Companies House)."
      ],
      disclaimer: "Advisory analysis only. An absence of identified red flags does not guarantee an opportunity is genuine.",
      analyzedAt: new Date().toISOString()
    };
  }

  // Scan against known malicious patterns
  for (const pat of patterns) {
    const matchedKeywords = pat.keywords.filter(kw => textLower.includes(kw.toLowerCase()));
    if (matchedKeywords.length > 0) {
      if (pat.severity === 'CRITICAL_RED_FLAG') {
        computedRiskScore += 45;
      } else if (pat.severity === 'HIGH_RED_FLAG') {
        computedRiskScore += 25;
      } else {
        computedRiskScore += 15;
      }

      detectedRedFlags.push({
        name: pat.patternName,
        severity: pat.severity,
        triggerKeywords: matchedKeywords,
        explanation: pat.explanation,
        recommendation: pat.recommendation
      });
    }
  }

  // Domain checks
  if (url) {
    if (url.includes('telegram.me') || url.includes('t.me') || url.includes('wa.me')) {
      computedRiskScore += 30;
      detectedRedFlags.push({
        name: "Anonymous Direct Messaging Application",
        severity: "HIGH_RED_FLAG",
        triggerKeywords: ["telegram / whatsapp recruitment link"],
        explanation: "Scammers frequently route communication through encrypted chat services where accounts can be deleted instantly.",
        recommendation: "Never conduct professional onboarding exclusively through messaging bots or group chats."
      });
    }
    if (url.includes('bit.ly') || url.includes('tinyurl.com') || url.includes('cutt.ly')) {
      computedRiskScore += 15;
      detectedRedFlags.push({
        name: "Obfuscated Shortened URL",
        severity: "MEDIUM_RED_FLAG",
        triggerKeywords: ["URL shortener"],
        explanation: "Shortened links hide the actual destination domain, commonly used in phishing attacks.",
        recommendation: "Use a URL expander tool or check the destination preview before entering personal details."
      });
    }
  }

  // Upfront fee check specifically
  const feeRegex = /(₹|\$|rs\.?|inr|usd)\s*([0-9,]+)/i;
  const hasFeeMention = textLower.includes('deposit') || textLower.includes('fee') || textLower.includes('pay') || textLower.includes('charge');
  if (hasFeeMention && (textLower.includes('refundable') || textLower.includes('security') || textLower.includes('registration') || textLower.includes('laptop'))) {
    computedRiskScore += 35;
  }

  // Normalize risk score to 0 - 100
  computedRiskScore = Math.min(100, Math.max(5, computedRiskScore));

  let riskCategory = "LOW_RISK";
  let riskBadge = "bg-emerald-500/20 text-emerald-400 border-emerald-500/30";
  if (computedRiskScore >= 70) {
    riskCategory = "HIGH_RISK";
    riskBadge = "bg-rose-500/20 text-rose-400 border-rose-500/30";
  } else if (computedRiskScore >= 40) {
    riskCategory = "MEDIUM_RISK";
    riskBadge = "bg-amber-500/20 text-amber-400 border-amber-500/30";
  }

  // Generate deeper AI reasoning via Gemini / Fallback
  const systemInstruction = `You are the Scam Detection Agent for SkillBridge AI.
Analyze the provided job/internship posting with critical skepticism.
Explain clearly WHY this opportunity looks suspicious or safe. Do not just output a number.
Categorize into Low Risk, Medium Risk, High Risk, or Insufficient Information.
IMPORTANT: Never claim that an opportunity is definitely genuine or fraudulent based only on AI analysis. Always explain uncertainty and guide the student on how to independently verify.`;

  const fallback = () => ({
    whySuspiciousExplanation: riskCategory === "HIGH_RISK"
      ? `This posting exhibits classic hallmark traits of employment fraud. Most critically, legitimate companies absorb onboarding and hardware costs as operating expenses; requiring candidate deposits or training fees is a universal warning sign. Additionally, conducting recruitment solely over anonymous messaging channels prevents corporate accountability.`
      : (riskCategory === "MEDIUM_RISK"
        ? `While this opportunity may be a small startup or third-party staffing firm, certain elements—such as ambiguous compensation metrics, compressed response deadlines, or generic email addresses—warrant careful verification before signing documents or sharing sensitive personal data.`
        : `No alarming red flags were detected in the text provided. The language appears consistent with standard internship postings, containing professional prerequisites and realistic role requirements.`),
    safetyChecklist: [
      "Check company domain registration date on whois.com (new domains < 6 months are high risk).",
      "Look up the recruiter's official profile on LinkedIn to see if they work for the claimed company.",
      "Check Glassdoor and Reddit (r/scams or r/developersIndia) for community reports.",
      "Never share Aadhaar/SSN, bank credentials, or OTPs during an interview phase."
    ]
  });

  const aiResult = await generateAgentResponse({
    agentName: 'Scam Detection Agent',
    systemInstruction,
    prompt: `Analyze risk for posting:\n${textToAnalyze}\nURL: ${url}\nCompany: ${companyName}`,
    fallbackGenerator: fallback
  });

  const analysisReport = {
    id: `scam-${Date.now()}`,
    studentId,
    targetText: textToAnalyze.substring(0, 500),
    url,
    companyName: companyName || 'Unspecified Entity',
    riskScore: computedRiskScore,
    safetyScore: 100 - computedRiskScore,
    riskCategory,
    riskBadge,
    confidencePercentage: 88,
    detectedRedFlags,
    whySuspicious: aiResult.data.whySuspiciousExplanation,
    safetyChecklist: aiResult.data.safetyChecklist || fallback().safetyChecklist,
    disclaimer: "IMPORTANT: This AI risk assessment is advisory only and not legal verification. SkillBridge AI cannot guarantee whether an entity is genuine or fraudulent. Always conduct independent verification before sharing personal details or signing agreements.",
    analyzedAt: new Date().toISOString()
  };

  // Save to database
  if (!db.scamAnalyses) db.scamAnalyses = [];
  db.scamAnalyses.unshift(analysisReport);
  if (db.scamAnalyses.length > 30) db.scamAnalyses.pop();
  saveDatabase();

  logAgentActivity({
    agent: 'Scam Detection Agent',
    action: `Scanned opportunity: ${companyName || 'Unknown Entity'}`,
    summary: `Risk: ${riskCategory} (${computedRiskScore}/100). Red flags detected: ${detectedRedFlags.length}.`,
    studentId
  });

  return analysisReport;
}

export function getScamAnalysisHistory(studentId) {
  const db = getDb();
  return (db.scamAnalyses || []).filter(a => !studentId || a.studentId === studentId);
}
