import { generateAgentResponse } from '../services/geminiService.js';
import { getDb, saveDatabase, logAgentActivity } from '../db/database.js';

/**
 * Agent 3: Skill Verification Agent
 * Verifies whether students actually possess claimed skills through objective tests.
 * Issues verified badges for score >= 80%, flags weak topics, and separates
 * verified vs assessed vs self-reported skills.
 */

export async function getQuizForSkill({ skillName, difficulty = 'Intermediate' }) {
  const db = getDb();
  const existingQuiz = (db.quizzes || []).find(
    q => q.skillName.toLowerCase() === skillName.toLowerCase()
  );

  if (existingQuiz) {
    return existingQuiz;
  }

  // Generate dynamic quiz via Gemini / fallback
  const systemInstruction = `You are the Skill Verification Agent for SkillBridge AI.
Generate a rigorous 4-question technical quiz for skill: "${skillName}" at "${difficulty}" difficulty.
Mix conceptual multiple choice with practical code analysis questions.
Provide 4 options for each, designate the correct index (0-3), provide an explanation, and label the subtopic.`;

  const fallback = () => ({
    id: `quiz-${skillName.toLowerCase().replace(/[^a-z0-9]/g, '-')}`,
    skillName,
    difficulty,
    category: "Technical Assessment",
    passingScore: 80,
    timeLimitMinutes: 10,
    questions: [
      {
        id: `${skillName}-q1`,
        type: "mcq",
        question: `What is the standard best practice when handling errors in ${skillName}?`,
        options: [
          "Suppress all exceptions silently with empty catch blocks",
          "Log contextual details, handle specific exception types, and fail fast",
          "Restart the entire operating system",
          "Never throw errors in production code"
        ],
        correctIndex: 1,
        explanation: "Handling specific exceptions with contextual logging ensures system stability and simplifies debugging.",
        subtopic: "Error Handling & Robustness"
      },
      {
        id: `${skillName}-q2`,
        type: "code-analysis",
        question: `When optimizing performance in ${skillName}, which operation generally incurs the highest computational cost?`,
        options: [
          "Stack variable allocation",
          "Uncached I/O disk and network roundtrips",
          "Bitwise bit shifts",
          "Arithmetic addition"
        ],
        correctIndex: 1,
        explanation: "Network roundtrips and disk I/O are orders of magnitude slower than in-memory or CPU register operations.",
        subtopic: "Performance & Architecture"
      },
      {
        id: `${skillName}-q3`,
        type: "mcq",
        question: `How does immutability benefit concurrent execution in ${skillName}?`,
        options: [
          "It eliminates race conditions by guaranteeing shared state cannot be modified",
          "It doubles CPU clock speed",
          "It disables garbage collection",
          "It converts single-threaded code to distributed clusters automatically"
        ],
        correctIndex: 0,
        explanation: "Immutable data structures are inherently thread-safe because no thread can alter state out from under another.",
        subtopic: "Concurrency & State Safety"
      },
      {
        id: `${skillName}-q4`,
        type: "problem-solving",
        question: `Which architectural pattern is best suited for decoupling microservices producing and consuming ${skillName} events?`,
        options: [
          "Direct hardcoded IP addresses",
          "Event-driven message broker / Pub-Sub pattern",
          "Monolithic shared memory",
          "Polling every millisecond via FTP"
        ],
        correctIndex: 1,
        explanation: "Pub-Sub message queues decouple service lifecycles, buffer traffic spikes, and allow horizontal scaling.",
        subtopic: "System Design & Patterns"
      }
    ]
  });

  const aiResult = await generateAgentResponse({
    agentName: 'Skill Verification Agent',
    systemInstruction,
    prompt: `Generate quiz for skill: "${skillName}" at ${difficulty} level.`,
    fallbackGenerator: fallback
  });

  return aiResult.data;
}

export async function evaluateQuizSubmission({ studentId, skillName, answers, quiz }) {
  const db = getDb();
  const student = db.students[studentId];

  let totalQuestions = quiz.questions.length;
  let correctCount = 0;
  const questionResults = [];
  const weakTopics = [];

  quiz.questions.forEach((q, idx) => {
    const studentAnswerIndex = answers[q.id] !== undefined ? answers[q.id] : -1;
    const isCorrect = studentAnswerIndex === q.correctIndex;

    if (isCorrect) {
      correctCount++;
    } else {
      if (q.subtopic && !weakTopics.includes(q.subtopic)) {
        weakTopics.push(q.subtopic);
      }
    }

    questionResults.push({
      questionId: q.id,
      question: q.question,
      selectedOptionIndex: studentAnswerIndex,
      correctOptionIndex: q.correctIndex,
      isCorrect,
      explanation: q.explanation,
      subtopic: q.subtopic || 'General'
    });
  });

  const scorePercentage = Math.round((correctCount / totalQuestions) * 100);
  const isPassed = scorePercentage >= (quiz.passingScore || 80);

  // Update student profile state
  if (student) {
    let existingSkill = student.skills.find(s => s.name.toLowerCase() === skillName.toLowerCase());
    if (!existingSkill) {
      existingSkill = {
        name: skillName,
        level: scorePercentage >= 85 ? 'Advanced' : (scorePercentage >= 65 ? 'Intermediate' : 'Beginner'),
        verified: isPassed,
        verificationScore: scorePercentage,
        assessed: true,
        selfReported: false,
        verifiedAt: isPassed ? new Date().toISOString() : null
      };
      student.skills.push(existingSkill);
    } else {
      existingSkill.assessed = true;
      existingSkill.verificationScore = Math.max(existingSkill.verificationScore || 0, scorePercentage);
      if (isPassed) {
        existingSkill.verified = true;
        existingSkill.verifiedAt = new Date().toISOString();
        if (scorePercentage >= 85) existingSkill.level = 'Advanced';
        else existingSkill.level = 'Intermediate';
      }
    }

    saveDatabase();
  }

  // Generate cryptographic-style Verification Badge if passed
  const badgeId = `SKB-${skillName.substring(0, 3).toUpperCase()}-${Date.now().toString(36).toUpperCase()}`;
  const verificationBadge = isPassed ? {
    badgeId,
    skillName,
    verificationTier: scorePercentage >= 90 ? 'Gold Verification' : 'Silver Verification',
    score: scorePercentage,
    verifiedAt: new Date().toISOString(),
    issuer: 'SkillBridge Verification Authority',
    verificationHash: `sha256_${Math.random().toString(36).substring(2)}${Math.random().toString(36).substring(2)}`,
    status: 'ACTIVE_VERIFIED'
  } : null;

  logAgentActivity({
    agent: 'Skill Verification Agent',
    action: `Evaluated quiz for ${skillName}`,
    summary: `Score: ${scorePercentage}% (${correctCount}/${totalQuestions} correct). Status: ${isPassed ? 'VERIFIED' : 'ASSESSED (Practice Recommended)'}.`,
    studentId
  });

  return {
    skillName,
    scorePercentage,
    passingScore: quiz.passingScore || 80,
    isPassed,
    correctCount,
    totalQuestions,
    questionResults,
    weakTopics,
    verificationBadge,
    weaknessRecoveryTriggered: !isPassed && weakTopics.length > 0,
    evaluatedAt: new Date().toISOString()
  };
}
