import { analyzeSkillGap } from './skillGapAgent.js';
import { generatePersonalizedRoadmap } from './learningAgent.js';
import { findOpportunities } from './opportunityAgent.js';
import { auditResume } from './careerAgent.js';
import { getDb, logAgentActivity } from '../db/database.js';

/**
 * SkillBridge Intelligence Hub
 * Central multi-agent coordinator that manages execution flows across all 6 specialized agents.
 */

export async function runFullCareerLaunchpadWorkflow({ studentId, targetCareerId }) {
  const db = getDb();
  const student = db.students[studentId];
  const career = db.careers.find(c => c.id === targetCareerId) || db.careers[0];

  const workflowSteps = [];
  const startTimestamp = new Date().toISOString();

  // Step 1: Skill Gap Detector
  logAgentActivity({
    agent: 'Intelligence Hub',
    action: 'Initiated Multi-Agent Career Launchpad Workflow',
    summary: `Target Career: ${career.title}. Orchestrating Agent 1 -> Agent 2 -> Agent 4 -> Agent 6.`,
    studentId
  });

  const gapAnalysis = await analyzeSkillGap({ student, targetCareer: career });
  workflowSteps.push({
    agent: 'Skill Gap Detector',
    task: `Analyze knowledge differentials for ${career.title}`,
    status: 'success',
    result: {
      overallMatch: `${gapAnalysis.overallMatchPercentage}%`,
      missingSkills: gapAnalysis.summaryMetrics.missingCount,
      priorityToLearn: gapAnalysis.priorityToLearn
    }
  });

  // Step 2: Personalized Learning Agent
  const roadmap = await generatePersonalizedRoadmap({ student, targetCareer: career, durationWeeks: 4 });
  workflowSteps.push({
    agent: 'Personalized Learning Agent',
    task: 'Synthesize custom 4-week structured curriculum with free resources',
    status: 'success',
    result: {
      roadmapTitle: roadmap.title,
      totalWeeks: roadmap.weeks?.length || 4,
      firstWeekFocus: roadmap.weeks?.[0]?.title || 'Fundamentals'
    }
  });

  // Step 3: Opportunity Finder Agent
  const matchingOpps = findOpportunities({ student, isBeginnerFriendly: true });
  workflowSteps.push({
    agent: 'Opportunity Finder Agent',
    task: 'Scan active genuine student fellowships and internships',
    status: 'success',
    result: {
      totalFound: matchingOpps.totalCount,
      topMatches: matchingOpps.opportunities.slice(0, 3).map(o => o.title)
    }
  });

  // Step 4: Career Guidance Agent (Initial Roadmap & Portfolio blueprint)
  workflowSteps.push({
    agent: 'Career Guidance Agent',
    task: 'Formulate interview preparation timeline and project portfolio strategy',
    status: 'success',
    result: {
      recommendedAction: `Focus on building 1 capstone project showcasing ${gapAnalysis.priorityToLearn.slice(0, 2).join(' & ')} before cold outreach.`
    }
  });

  logAgentActivity({
    agent: 'Intelligence Hub',
    action: 'Completed Career Launchpad Workflow',
    summary: `Multi-agent collaboration finished successfully in 4 steps.`,
    studentId
  });

  return {
    workflowName: 'End-to-End Career Launchpad',
    studentId,
    targetCareer: career.title,
    startedAt: startTimestamp,
    completedAt: new Date().toISOString(),
    status: 'SUCCESS',
    steps: workflowSteps,
    consolidatedInsights: {
      readinessMatch: gapAnalysis.overallMatchPercentage,
      priorityFocus: gapAnalysis.priorityToLearn,
      firstLessonToStart: roadmap.weeks?.[0]?.lessons?.[0]?.title || 'Foundation Review',
      topMatchingOpportunities: matchingOpps.opportunities.slice(0, 2)
    }
  };
}
