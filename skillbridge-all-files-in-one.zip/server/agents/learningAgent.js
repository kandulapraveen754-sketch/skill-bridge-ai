import { generateAgentResponse } from '../services/geminiService.js';
import { logAgentActivity } from '../db/database.js';

/**
 * Agent 2: Personalized Learning Agent
 * Generates custom learning roadmaps, teaches concepts in simple terms,
 * provides free curated resources, coding challenges, and runs the Weakness Recovery System.
 */

export async function generatePersonalizedRoadmap({ student, targetCareer, durationWeeks = 4 }) {
  const careerTitle = targetCareer.title;
  const missingSkills = (targetCareer.skills || []).filter(req => {
    const found = (student.skills || []).find(s => s.name.toLowerCase() === req.name.toLowerCase());
    return !found || found.level === 'Beginner';
  });

  const systemInstruction = `You are the Personalized Learning Agent for SkillBridge AI.
Create a structured, highly actionable ${durationWeeks}-week roadmap for a college student aiming to become a ${careerTitle}.
Include realistic lessons, direct free resources (YouTube channels like freeCodeCamp, 3Blue1Brown, Sentdex, Traversy), and practical coding tasks.`;

  const fallback = () => {
    return {
      title: `${durationWeeks}-Week Career Accelerator: ${careerTitle}`,
      paceRecommendation: "10-12 hours per week (2 hours daily + weekend project)",
      weeks: [
        {
          weekNumber: 1,
          title: "Core Foundations & Modern Tooling",
          objective: "Establish unbreakable fundamentals with clean syntax, data structures, and idiomatic patterns.",
          lessons: [
            {
              id: "w1-l1",
              title: "Modern Language Fundamentals & Performance Gotchas",
              duration: "45 min",
              type: "Interactive Reading & Exercises",
              resourceUrl: "https://www.youtube.com/watch?v=rfscVS0vtbw",
              resourceTitle: "freeCodeCamp - Modern Software Engineering Foundations",
              summary: "Master memory allocation, references vs values, and idiomatic clean coding patterns.",
              keyTakeaways: ["Avoid premature optimization", "Understand big-O space vs time tradeoffs"],
              completed: true
            },
            {
              id: "w1-l2",
              title: "Vectorization, Linear Algebra, and Matrix Transformations",
              duration: "60 min",
              type: "Video & Visual Lab",
              resourceUrl: "https://www.youtube.com/watch?v=fNk_zzaMoSs",
              resourceTitle: "3Blue1Brown - Essence of Linear Algebra",
              summary: "Grasp geometric intuition of matrix multiplications and linear combinations.",
              keyTakeaways: ["Matrices are linear space transformations", "Dot product measures directional similarity"],
              completed: true
            },
            {
              id: "w1-l3",
              title: "Hands-on Challenge: Build an In-Memory Data Pipeline",
              duration: "90 min",
              type: "Coding Challenge",
              resourceUrl: "https://github.com",
              resourceTitle: "SkillBridge Lab Challenge #1",
              summary: "Implement a generator-based pipeline filtering and transforming 100,000 JSON records without exceeding 50MB RAM.",
              keyTakeaways: ["Use lazy generators over eager lists", "Stream processing prevents OOM crashes"],
              completed: false
            }
          ]
        },
        {
          weekNumber: 2,
          title: "Intermediate Architecture & Machine Learning Pipelines",
          objective: "Build modular systems and robust data pre-processing workflows.",
          lessons: [
            {
              id: "w2-l1",
              title: "Scikit-Learn Architecture & Custom Estimators",
              duration: "50 min",
              type: "Code Walkthrough",
              resourceUrl: "https://www.youtube.com/watch?v=0B5eIE_1vpU",
              resourceTitle: "StatQuest - Scikit-Learn Pipelines Step-by-Step",
              summary: "Learn to chain transforms and estimators to prevent data leakage.",
              keyTakeaways: ["Never fit scaler on test split", "Use ColumnTransformer for heterogeneous data"],
              completed: false
            },
            {
              id: "w2-l2",
              title: "Model Validation & Robust Cross-Validation Schemes",
              duration: "45 min",
              type: "Theory & Practice",
              resourceUrl: "https://www.youtube.com/watch?v=fSytzGwwBVw",
              resourceTitle: "StatQuest - Cross Validation Explained Clearly",
              summary: "K-Fold, Stratified K-Fold, and TimeSeries splits.",
              keyTakeaways: ["Stratified folds preserve target ratios", "Evaluation metrics must match domain impact"],
              completed: false
            }
          ]
        },
        {
          weekNumber: 3,
          title: "Deep Learning Foundations & Neural Architectures",
          objective: "Build, train, and diagnose neural networks from scratch using PyTorch.",
          lessons: [
            {
              id: "w3-l1",
              title: "PyTorch Mechanics: Tensors, Compute Graph & Autograd",
              duration: "60 min",
              type: "Interactive Workshop",
              resourceUrl: "https://www.youtube.com/watch?v=V_xro1bcAuA",
              resourceTitle: "freeCodeCamp - PyTorch for Deep Learning in 24 Hours",
              summary: "How backpropagation calculates gradients automatically through tensor operations.",
              keyTakeaways: ["Tensors run seamlessly on CUDA GPUs", "Zero gradients before backward pass"],
              completed: false
            },
            {
              id: "w3-l2",
              title: "Debugging Vanishing Gradients and Training Instabilities",
              duration: "40 min",
              type: "Diagnostic Lab",
              resourceUrl: "https://www.youtube.com/watch?v=qoz3ZFuq12g",
              resourceTitle: "Andrej Karpathy - Building Micrograd from Scratch",
              summary: "Inspect loss curves, learning rate scheduling, and batch normalization.",
              keyTakeaways: ["Check initial loss equals -ln(1/num_classes)", "Track gradient norms per layer"],
              completed: false
            }
          ]
        },
        {
          weekNumber: 4,
          title: "Production Deployment & Portfolio Showcase",
          objective: "Ship a live containerized web application that recruiters and users can test directly.",
          lessons: [
            {
              id: "w4-l1",
              title: "Production API Design with FastAPI & Pydantic Validation",
              duration: "55 min",
              type: "Project Build",
              resourceUrl: "https://www.youtube.com/watch?v=0sOvCWFmrtA",
              resourceTitle: "freeCodeCamp - FastAPI Full Course",
              summary: "Create async endpoints with typed schemas, error middleware, and Swagger docs.",
              keyTakeaways: ["Pydantic handles automatic validation and serialization", "Async handlers prevent thread blocking"],
              completed: false
            },
            {
              id: "w4-l2",
              title: "Deploying Live Cloud Demos on Hugging Face & Render",
              duration: "40 min",
              type: "Deployment Guide",
              resourceUrl: "https://www.youtube.com/watch?v=3z_pW9Q2iX4",
              resourceTitle: "Hugging Face Spaces Quickstart",
              summary: "Connect GitHub repo, configure environment variables, and get a public live URL.",
              keyTakeaways: ["A live working URL increases recruiter callback rate by 4x", "Pin package versions in requirements.txt"],
              completed: false
            }
          ]
        }
      ]
    };
  };

  const aiResult = await generateAgentResponse({
    agentName: 'Personalized Learning Agent',
    systemInstruction,
    prompt: `Generate a personalized learning curriculum for target career: ${careerTitle}.\nStudent weak/missing skills: ${missingSkills.map(s => s.name).join(', ')}`,
    studentContext: student,
    fallbackGenerator: fallback
  });

  logAgentActivity({
    agent: 'Personalized Learning Agent',
    action: `Created customized roadmap for ${careerTitle}`,
    summary: `Curated ${durationWeeks}-week roadmap with free video tutorials, notes, and lab challenges.`
  });

  return aiResult.data;
}

/**
 * Concept Explainer: Teaches complex topics in simple English with real-world analogies
 */
export async function explainConcept({ topic, difficulty = 'Beginner', context = '' }) {
  const systemInstruction = `You are the Concept Explainer in SkillBridge AI's Personalized Learning Agent.
Explain the requested topic in simple, conversational English.
Use a memorable real-world analogy. Provide a clean, minimal code example, and test the student with 1 quick check-for-understanding question.`;

  const fallback = () => {
    return {
      topic,
      difficulty,
      simpleExplanation: `${topic} is a method in computer science designed to break down a difficult, repetitive task into clean, predictable steps. Think of it like a smart factory assembly line where each worker focuses on one exact operation before passing the result along.`,
      realWorldAnalogy: `Imagine ordering food at a busy coffee shop: rather than one barista taking the order, grinding beans, steaming milk, and serving the cup one customer at a time, an async pipeline allows one barista to steam milk while the register processes the next customer's order.`,
      codeExample: `# Practical example of ${topic}\ndef demonstrate_concept(items):\n    # Process data cleanly and efficiently\n    return [item.strip().title() for item in items if item]\n\nprint(demonstrate_concept(["  python ", "react", "ml  "]))`,
      practiceChallenge: `Write a short 3-line function that takes a list of numbers and returns only the squares of even numbers using this concept.`,
      hints: [
        "Use a list comprehension or generator expression for brevity.",
        "Check remainder with the modulo operator (n % 2 == 0)."
      ]
    };
  };

  const aiResult = await generateAgentResponse({
    agentName: 'Personalized Learning Agent',
    systemInstruction,
    prompt: `Explain topic: "${topic}" for a ${difficulty} student. Context: ${context}`,
    fallbackGenerator: fallback
  });

  return aiResult.data;
}

/**
 * Weakness Recovery System:
 * Triggered when a student fails a quiz or struggles with a concept.
 * Breaks down the bottleneck into simpler concepts, gives additional practice, and prepares for re-test.
 */
export async function triggerWeaknessRecovery({ student, weakTopic, failedQuestionDetails = null }) {
  const systemInstruction = `You are the Weakness Recovery System in SkillBridge AI.
The student struggled with: "${weakTopic}".
Do not simply repeat the textbook answer. Identify the core mental model disconnect, provide a simpler explanation with a step-by-step breakdown, recommend 2 focused free tutorials, and generate 2 easier diagnostic practice questions to rebuild their confidence before re-testing.`;

  const fallback = () => {
    return {
      weakTopic,
      recoveryStatus: "Active Recovery Plan Generated",
      diagnosis: `The common stumbling block with ${weakTopic} is confusing the static definition phase with runtime execution. Students often assume operations happen immediately rather than lazily or asynchronously.`,
      simplifiedBreakdown: [
        "Step 1: Understand that memory references point to objects, not raw values.",
        "Step 2: Trace code execution line-by-line using a paper-and-pencil table before running it.",
        "Step 3: Test with tiny 2-item arrays rather than large complex datasets to isolate bugs."
      ],
      targetedFreeResources: [
        {
          title: `Visualizing ${weakTopic} Step-by-Step on PythonTutor`,
          url: "https://pythontutor.com",
          type: "Interactive Execution Visualizer"
        },
        {
          title: `StatQuest / freeCodeCamp: ${weakTopic} Demystified`,
          url: "https://www.youtube.com/results?search_query=" + encodeURIComponent(`${weakTopic} explained easily`),
          type: "Curated Video Tutorial"
        }
      ],
      easierPracticeQuestions: [
        {
          id: "rec-q1",
          question: `What will be the result of a basic 1-element test case in ${weakTopic}?`,
          options: ["Throws an error", "Returns the transformed element", "Returns None", "Loops indefinitely"],
          correctIndex: 1,
          explanation: "In the baseline case, operations resolve cleanly on single items."
        },
        {
          id: "rec-q2",
          question: `Which fundamental principle ensures safety when working with ${weakTopic}?`,
          options: ["Always mutate variables globally", "Prefer immutability and pure functions", "Never write unit tests", "Hardcode file paths"],
          correctIndex: 1,
          explanation: "Immutability guarantees predictable behavior and prevents accidental side effects."
        }
      ],
      readinessToRetest: "Complete these 2 practice questions, then retake the skill quiz to claim your verified badge."
    };
  };

  const aiResult = await generateAgentResponse({
    agentName: 'Personalized Learning Agent',
    systemInstruction,
    prompt: `Weakness Recovery Triggered for: "${weakTopic}". Details: ${JSON.stringify(failedQuestionDetails)}`,
    studentContext: student,
    fallbackGenerator: fallback
  });

  logAgentActivity({
    agent: 'Personalized Learning Agent',
    action: `Weakness Recovery Plan for ${weakTopic}`,
    summary: `Identified learning hurdle in ${weakTopic}. Provided visual breakdown and 2 targeted practice questions.`
  });

  return aiResult.data;
}
