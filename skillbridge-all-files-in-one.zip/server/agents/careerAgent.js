import { generateAgentResponse } from '../services/geminiService.js';
import { getDb, saveDatabase, logAgentActivity } from '../db/database.js';

/**
 * Agent 6: Career Guidance Agent
 * Provides Resume Auditing (ATS matching, bullet metric rewrites),
 * Mock Interview practice with automated STAR evaluation, and portfolio advice.
 */

export async function auditResume({ resumeText, targetCareerTitle = 'Software Engineer', studentId = 'std-alex-chen' }) {
  const systemInstruction = `You are the Career Guidance Agent for SkillBridge AI specializing in technical resume optimization and ATS parsing.
Audit the provided resume for target role: "${targetCareerTitle}".
Identify:
1. ATS Keyword Match & Missing Keywords.
2. Missing or weak sections (e.g. Projects, GitHub links, Measurable Metrics).
3. Action Verb & Impact Score (e.g., did they use X-Y-Z formula: "Accomplished [X] as measured by [Y] by doing [Z]").
4. Provide 3 specific Before-and-After bullet point rewrites showing how to add real metrics.`;

  const fallback = () => {
    // Algorithmic checks on the resume text
    const textLower = resumeText.toLowerCase();
    const hasGitHub = textLower.includes('github.com');
    const hasLinkedIn = textLower.includes('linkedin.com');
    const hasMetrics = /[0-9]+%|[0-9]+x|\$[0-9]+|[0-9]+ms/.test(textLower);

    const missingSections = [];
    if (!hasGitHub) missingSections.push("Public GitHub profile link (essential for engineering roles)");
    if (!hasLinkedIn) missingSections.push("Custom LinkedIn profile URL");
    if (!textLower.includes('project')) missingSections.push("Dedicated 'Technical Projects' section with live demo URLs");
    if (!textLower.includes('education')) missingSections.push("Education & expected graduation date");

    const atsKeywords = [
      { keyword: "Python", present: textLower.includes("python"), importance: "High" },
      { keyword: "REST APIs", present: textLower.includes("api") || textLower.includes("rest"), importance: "High" },
      { keyword: "Git / CI/CD", present: textLower.includes("git") || textLower.includes("ci/cd"), importance: "Medium" },
      { keyword: "Docker / Cloud", present: textLower.includes("docker") || textLower.includes("aws") || textLower.includes("cloud"), importance: "Medium" },
      { keyword: "SQL / Database", present: textLower.includes("sql") || textLower.includes("database"), importance: "High" },
      { keyword: "Unit Testing", present: textLower.includes("test") || textLower.includes("pytest") || textLower.includes("jest"), importance: "Medium" }
    ];

    const presentKeywordsCount = atsKeywords.filter(k => k.present).length;
    const atsScore = Math.min(95, Math.round((presentKeywordsCount / atsKeywords.length) * 80 + (hasMetrics ? 15 : 0)));

    return {
      overallScore: atsScore,
      atsSummary: `Your resume demonstrates good technical exposure but lacks quantified business impact. Adding hard numbers, benchmark metrics, and links to live deployed projects will boost your recruiter response rate.`,
      keywordAnalysis: {
        matchedCount: presentKeywordsCount,
        totalChecked: atsKeywords.length,
        keywords: atsKeywords
      },
      missingSections,
      bulletRewrites: [
        {
          before: "Worked on an AI model to detect emotions in text messages.",
          after: "Engineered a BERT-based NLP classifier achieving 92.4% F1-score across 50,000 text samples; deployed as a low-latency FastAPI microservice serving <40ms inferences.",
          critique: "Added model architecture, specific benchmark metric (92.4% F1-score), dataset volume, and production latency."
        },
        {
          before: "Built a website for student course management using React and Node.",
          after: "Architected a responsive full-stack student portal in React and Express with JWT authentication, serving 300+ daily peer reviews with 99.9% uptime.",
          critique: "Quantified active user base, highlighted security architecture, and demonstrated reliability."
        },
        {
          before: "Helped optimize database queries in team project.",
          after: "Indexed 4 high-traffic PostgreSQL foreign keys and refactored N+1 queries, slashing average API response latency by 45%.",
          critique: "Specified database engine, exact technical mechanism (indexing, eliminating N+1 queries), and measured performance gain."
        }
      ],
      formattingTips: [
        "Use single-column clean layout for optimal ATS parser compatibility.",
        "Save and submit strictly in PDF format with selectable UTF-8 text.",
        "Keep total resume length to exactly 1 page for college students and freshers."
      ]
    };
  };

  const aiResult = await generateAgentResponse({
    agentName: 'Career Guidance Agent',
    systemInstruction,
    prompt: `Audit this resume text for target role "${targetCareerTitle}":\n\n${resumeText}`,
    fallbackGenerator: fallback
  });

  const auditReport = {
    id: `audit-${Date.now()}`,
    targetRole: targetCareerTitle,
    analyzedAt: new Date().toISOString(),
    ...aiResult.data
  };

  // Save audit in database
  const db = getDb();
  if (!db.resumeAnalyses) db.resumeAnalyses = [];
  db.resumeAnalyses.unshift(auditReport);
  saveDatabase();

  logAgentActivity({
    agent: 'Career Guidance Agent',
    action: `Audited resume for ${targetCareerTitle}`,
    summary: `ATS Score: ${auditReport.overallScore}/100. Generated 3 metric bullet rewrites.`,
    studentId
  });

  return auditReport;
}

/**
 * Mock Interview Questions Generator
 */
export async function generateInterviewQuestions({ targetCareerTitle, questionType = 'technical', count = 3 }) {
  const systemInstruction = `You are the Career Guidance Agent for SkillBridge AI conducting mock interview prep.
Generate ${count} realistic interview questions for a student interviewing for a ${targetCareerTitle} internship.
Question type: ${questionType} (e.g. technical, behavioral STAR, system design).
Provide the question, what the interviewer is evaluating, and a hint on what to emphasize.`;

  const fallback = () => {
    if (questionType === 'behavioral') {
      return [
        {
          id: "int-b1",
          type: "behavioral",
          question: "Tell me about a challenging technical bug you encountered in a project. How did you diagnose it, and what did you learn?",
          evaluating: "Problem-solving methodology, resilience, systematic debugging tools, and self-awareness.",
          idealStructure: "Use the STAR method: Situation (project context), Task (what failed), Action (profiler, logs, hypothesis testing), Result (resolution and post-mortem prevention).",
          sampleAnswerHint: "Mention using unit tests, logging, or git bisect rather than guessing."
        },
        {
          id: "int-b2",
          type: "behavioral",
          question: "Describe a situation where you had to collaborate with a teammate who had a fundamentally different technical opinion.",
          evaluating: "Communication, emotional intelligence, technical compromise, and data-driven decision making.",
          idealStructure: "Show that you listened to their perspective, benchmarked the two approaches objectively, and prioritized project delivery.",
          sampleAnswerHint: "Emphasize measuring performance or creating a quick proof-of-concept rather than arguing opinions."
        }
      ];
    }

    return [
      {
        id: "int-t1",
        type: "technical",
        question: `How would you handle significant class imbalance in a production machine learning classification problem?`,
        evaluating: "Understanding of metric skew, sampling techniques, loss function reweighting, and real-world evaluation.",
        idealStructure: "1) Explain why accuracy is deceptive, 2) Resampling strategies (SMOTE vs downsampling), 3) Cost-sensitive loss weighting, 4) Metric selection (Precision-Recall curve / F1).",
        sampleAnswerHint: "Always tie technical techniques back to business risk: e.g. false negatives are 10x more costly than false positives in fraud detection."
      },
      {
        id: "int-t2",
        type: "technical",
        question: `Walk me through what happens under the hood when a client sends an HTTP POST request to a FastAPI backend.`,
        evaluating: "Networking fundamentals, ASGI event loop, serialization, middleware lifecycle, and async request handling.",
        idealStructure: "DNS resolution -> TCP Handshake -> TLS -> Uvicorn ASGI socket -> Middleware stack -> Pydantic parsing -> Dependency injection -> Handler execution -> Response serialization.",
        sampleAnswerHint: "Show that you understand non-blocking I/O and how asynchronous workers keep response times low."
      }
    ];
  };

  const aiResult = await generateAgentResponse({
    agentName: 'Career Guidance Agent',
    systemInstruction,
    prompt: `Generate ${count} ${questionType} interview questions for ${targetCareerTitle}`,
    fallbackGenerator: fallback
  });

  return aiResult.data;
}

/**
 * Evaluate Student's Mock Interview Response
 */
export async function evaluateInterviewAnswer({ question, studentAnswer, targetRole = 'Software Engineer' }) {
  const systemInstruction = `You are the Career Guidance Agent for SkillBridge AI evaluating a student's mock interview response.
Evaluate the answer constructively on:
1. Technical Accuracy / Depth (0-100)
2. Structure & Clarity (STAR method usage if behavioral) (0-100)
3. Constructive Feedback (what was strong, what was missing)
4. Exemplary Model Answer showing how a senior candidate would phrase it.`;

  const fallback = () => {
    const wordCount = (studentAnswer || '').trim().split(/\s+/).length;
    let score = 75;
    if (wordCount < 20) score = 45;
    else if (wordCount > 60) score = 88;

    return {
      score,
      verdict: score >= 80 ? "Strong Response" : (score >= 60 ? "Promising - Needs More Structure" : "Too Brief - Lacks Depth"),
      strengths: [
        "Directly addressed the prompt without dodging the core question.",
        "Demonstrated familiarity with foundational terminology."
      ],
      areasForImprovement: [
        "Include more concrete quantitative results (e.g. 'reduced latency by 30%', 'served 500 concurrent requests').",
        "Adopt the STAR structure (Situation -> Task -> Action -> Result) to guide the interviewer seamlessly through your thought process."
      ],
      modelAnswer: `In my university capstone project, we faced a similar situation where our backend API would timeout under burst loads. I first profiled the bottleneck using cProfile and identified unindexed foreign key lookups. I refactored the ORM queries, implemented Redis caching for static lookups, and added database connection pooling. This reduced 95th percentile latency from 680ms down to 42ms under a simulated 1,000 request load test.`
    };
  };

  const aiResult = await generateAgentResponse({
    agentName: 'Career Guidance Agent',
    systemInstruction,
    prompt: `Question: "${question}"\nStudent Answer: "${studentAnswer}"\nTarget Role: "${targetRole}"`,
    fallbackGenerator: fallback
  });

  return aiResult.data;
}
