import { generateAgentResponse } from '../services/geminiService.js';
import { logAgentActivity } from '../db/database.js';

/**
 * Agent 1: Skill Gap Detector
 * Analyzes difference between student skills and career requirements.
 */

export async function analyzeSkillGap({ student, targetCareer, customQuery = '' }) {
  const careerTitle = targetCareer.title;
  const careerSkills = targetCareer.skills || [];
  const studentSkills = student.skills || [];

  // Local algorithmic calculation for fast and 100% reliable baseline
  const evaluatedSkills = careerSkills.map(req => {
    const existing = studentSkills.find(s => s.name.toLowerCase() === req.name.toLowerCase());
    
    let currentLevel = 'Missing';
    let proficiencyScore = 0;
    let status = 'Missing'; // 'Verified' | 'Acquired' | 'Weak' | 'Missing'
    let verified = false;

    if (existing) {
      currentLevel = existing.level || 'Beginner';
      verified = !!existing.verified;

      if (currentLevel === 'Advanced') proficiencyScore = 90;
      else if (currentLevel === 'Intermediate') proficiencyScore = 65;
      else if (currentLevel === 'Beginner') proficiencyScore = 35;

      if (verified && existing.verificationScore) {
        proficiencyScore = existing.verificationScore;
      }

      if (proficiencyScore >= 80) status = 'Verified';
      else if (proficiencyScore >= 50) status = 'Acquired';
      else status = 'Weak';
    }

    // Benchmark score target
    let targetScore = 85;
    if (req.benchmark === 'Advanced') targetScore = 90;
    else if (req.benchmark === 'Intermediate') targetScore = 70;
    else if (req.benchmark === 'Beginner') targetScore = 40;

    const gap = Math.max(0, targetScore - proficiencyScore);
    const priority = req.importance === 'Core' && gap > 30 ? 'HIGH' : (req.importance === 'Core' ? 'MEDIUM' : 'LOW');

    return {
      name: req.name,
      importance: req.importance,
      benchmark: req.benchmark,
      currentLevel,
      proficiencyScore,
      targetScore,
      gap,
      priority,
      status,
      verified,
      weight: req.weight || 10
    };
  });

  const totalRequiredWeight = evaluatedSkills.reduce((sum, s) => sum + s.weight, 0);
  const earnedWeight = evaluatedSkills.reduce((sum, s) => sum + (s.proficiencyScore / 100) * s.weight, 0);
  const overallMatchPercentage = Math.round((earnedWeight / (totalRequiredWeight || 1)) * 100);

  const missingSkills = evaluatedSkills.filter(s => s.status === 'Missing');
  const weakSkills = evaluatedSkills.filter(s => s.status === 'Weak');
  const acquiredSkills = evaluatedSkills.filter(s => s.status === 'Acquired' || s.status === 'Verified');
  const priorityToLearn = evaluatedSkills
    .filter(s => s.priority === 'HIGH' || s.status === 'Missing')
    .sort((a, b) => b.gap - a.gap)
    .slice(0, 3)
    .map(s => s.name);

  // Generate qualitative AI summary via Gemini / Fallback
  const systemInstruction = `You are the Skill Gap Detector Agent for SkillBridge AI.
Your job is to provide honest, encouraging, and highly specific career gap analysis for a student aiming for: "${careerTitle}".
Highlight what they do well, identify critical missing skills, and clearly prioritize what they must learn first.`;

  const fallback = () => ({
    executiveSummary: `Your current skill profile shows a ${overallMatchPercentage}% match for the ${careerTitle} role. While you have a solid start with foundational competencies, closing gaps in ${priorityToLearn.join(', ')} is essential to qualify for top-tier internships.`,
    priorityRecommendations: [
      `Priority 1: Dive straight into ${priorityToLearn[0] || 'core technologies'} with hands-on mini-projects.`,
      `Priority 2: Bridge theoretical knowledge in ${priorityToLearn[1] || 'foundational theory'} using interactive practice.`,
      `Priority 3: Take verification quizzes on acquired skills to prove capability to recruiters.`
    ],
    projectedTimeToReadiness: "6 to 8 weeks with 10 hours/week dedicated study",
    keyMilestone: "Build 1 production-grade full-stack / machine learning application demonstrating end-to-end integration."
  });

  const aiResult = await generateAgentResponse({
    agentName: 'Skill Gap Detector',
    systemInstruction,
    prompt: `Analyze the student's profile for target career: ${careerTitle}.\nEvaluated gaps: ${JSON.stringify(evaluatedSkills, null, 2)}`,
    studentContext: student,
    fallbackGenerator: fallback
  });

  const report = {
    targetCareer: careerTitle,
    category: targetCareer.category,
    overallMatchPercentage,
    evaluatedSkills,
    summaryMetrics: {
      totalRequired: evaluatedSkills.length,
      verifiedCount: evaluatedSkills.filter(s => s.verified).length,
      acquiredCount: acquiredSkills.length,
      weakCount: weakSkills.length,
      missingCount: missingSkills.length
    },
    priorityToLearn,
    qualitativeAnalysis: aiResult.data,
    isDemoMode: aiResult.isDemoMode,
    aiModel: aiResult.aiModel,
    generatedAt: new Date().toISOString()
  };

  logAgentActivity({
    agent: 'Skill Gap Detector',
    action: `Evaluated skill gap for ${careerTitle}`,
    summary: `Match: ${overallMatchPercentage}%. Missing: ${missingSkills.length} skills. Top priority: ${priorityToLearn.slice(0, 2).join(', ')}.`
  });

  return report;
}
