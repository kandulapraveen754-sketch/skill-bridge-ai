import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DB_FILE = path.join(__dirname, 'skillbridge_data.json');
const SAMPLE_STUDENT_FILE = path.join(__dirname, '../sample_data/sample_student.json');
const CAREERS_FILE = path.join(__dirname, '../sample_data/careers.json');
const OPPORTUNITIES_FILE = path.join(__dirname, '../sample_data/opportunities.json');
const QUIZZES_FILE = path.join(__dirname, '../sample_data/quizzes.json');
const SCAM_PATTERNS_FILE = path.join(__dirname, '../sample_data/scam_patterns.json');

// In-memory cache + file sync persistence
let dbState = {
  users: [],
  students: {},
  careers: [],
  opportunities: [],
  quizzes: [],
  scamPatterns: [],
  scamAnalyses: [],
  resumeAnalyses: [],
  interviewSessions: [],
  roadmaps: {},
  activityLogs: [],
  chatHistory: []
};

export function initDatabase() {
  try {
    if (fs.existsSync(DB_FILE)) {
      const raw = fs.readFileSync(DB_FILE, 'utf-8');
      dbState = JSON.parse(raw);
    } else {
      // Seed initial data from sample files
      const careers = JSON.parse(fs.readFileSync(CAREERS_FILE, 'utf-8'));
      const opportunities = JSON.parse(fs.readFileSync(OPPORTUNITIES_FILE, 'utf-8'));
      const quizzes = JSON.parse(fs.readFileSync(QUIZZES_FILE, 'utf-8'));
      const scamPatterns = JSON.parse(fs.readFileSync(SCAM_PATTERNS_FILE, 'utf-8'));
      const sampleStudent = JSON.parse(fs.readFileSync(SAMPLE_STUDENT_FILE, 'utf-8'));

      dbState = {
        users: [
          {
            id: 'user-demo-1',
            email: 'alex.chen@university.edu',
            password: 'demo_password_123',
            name: 'Alex Chen',
            studentId: sampleStudent.id,
            createdAt: new Date().toISOString()
          }
        ],
        students: {
          [sampleStudent.id]: sampleStudent
        },
        careers,
        opportunities,
        quizzes,
        scamPatterns,
        scamAnalyses: [
          {
            id: 'scam-initial-1',
            studentId: sampleStudent.id,
            targetText: "Urgent Remote Data Entry & AI Labeler. Free laptop provided upon payment of ₹2,500 refundable security deposit. Telegram contact.",
            riskCategory: "HIGH_RISK",
            riskScore: 92,
            safetyScore: 8,
            timestamp: "2026-11-03T11:20:00Z",
            redFlags: [
              "Upfront ₹2,500 security deposit required for hardware delivery",
              "Recruitment conducted exclusively via Telegram channel",
              "Unrealistically high hourly wage with no prerequisites"
            ]
          }
        ],
        resumeAnalyses: [],
        interviewSessions: [],
        roadmaps: {
          [sampleStudent.id]: {
            careerId: "ai-ml-engineer",
            generatedAt: "2026-11-04T18:30:00Z",
            weeks: [
              {
                weekNumber: 1,
                title: "Foundations: Advanced Python & Vector Math",
                summary: "Master NumPy broadcasting, matrix operations, and efficient Python generator workflows.",
                lessons: [
                  { id: "w1-l1", title: "List & Dict Comprehensions Under the Hood", completed: true, duration: "35 min", resourceUrl: "https://www.youtube.com/watch?v=3dt4xovU2F4" },
                  { id: "w1-l2", title: "Linear Algebra: Eigenvectors & Matrix Multiplication (3Blue1Brown)", completed: true, duration: "50 min", resourceUrl: "https://www.youtube.com/watch?v=PFDu9oVAE-g" },
                  { id: "w1-l3", title: "NumPy Vectorization vs Python For Loops", completed: false, duration: "40 min", resourceUrl: "https://www.youtube.com/watch?v=QUT1VHiLmmI" }
                ]
              },
              {
                weekNumber: 2,
                title: "Classic Machine Learning & Scikit-Learn Pipelines",
                summary: "Implement Regression, Decision Trees, and prevent Data Leakage with Pipelines.",
                lessons: [
                  { id: "w2-l1", title: "Bias-Variance Tradeoff & Cross-Validation Strategy", completed: false, duration: "45 min", resourceUrl: "https://www.youtube.com/watch?v=EuBBz3bI-aA" },
                  { id: "w2-l2", title: "Building Robust Scikit-Learn Preprocessing Pipelines", completed: false, duration: "55 min", resourceUrl: "https://www.youtube.com/watch?v=0B5eIE_1vpU" }
                ]
              },
              {
                weekNumber: 3,
                title: "Deep Learning Foundations with PyTorch",
                summary: "Tensors, Autograd, Backpropagation, and Training your first Multi-Layer Perceptron.",
                lessons: [
                  { id: "w3-l1", title: "PyTorch Tensors, GPU Acceleration, and Autograd Mechanics", completed: false, duration: "60 min", resourceUrl: "https://www.youtube.com/watch?v=V_xro1bcAuA" },
                  { id: "w3-l2", title: "Writing a Training Loop with Adam Optimizer and CrossEntropyLoss", completed: false, duration: "65 min", resourceUrl: "https://www.youtube.com/watch?v=c36lUUr864M" }
                ]
              },
              {
                weekNumber: 4,
                title: "End-to-End AI Project Deployment (Hugging Face & FastAPI)",
                summary: "Package your trained neural network into a live containerized REST API with interactive frontend.",
                lessons: [
                  { id: "w4-l1", title: "Deploying Models as REST Endpoints with FastAPI", completed: false, duration: "45 min", resourceUrl: "https://www.youtube.com/watch?v=0sOvCWFmrtA" },
                  { id: "w4-l2", title: "Publishing Live Interactive Demos on Hugging Face Spaces", completed: false, duration: "35 min", resourceUrl: "https://www.youtube.com/watch?v=3z_pW9Q2iX4" }
                ]
              }
            ]
          }
        },
        activityLogs: sampleStudent.recentActivities || [],
        chatHistory: []
      };

      saveDatabase();
    }
    console.log('[DB] SkillBridge database initialized successfully.');
  } catch (err) {
    console.error('[DB] Error initializing database:', err);
  }
}

export function saveDatabase() {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(dbState, null, 2), 'utf-8');
  } catch (err) {
    console.error('[DB] Failed to save database to disk:', err);
  }
}

export function getDb() {
  return dbState;
}

export function logAgentActivity({ agent, action, status, summary, studentId = 'std-alex-chen' }) {
  const logEntry = {
    id: `act-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    agent,
    action,
    status: status || 'success',
    timestamp: new Date().toISOString(),
    summary,
    studentId
  };

  dbState.activityLogs.unshift(logEntry);
  if (dbState.activityLogs.length > 50) {
    dbState.activityLogs.pop();
  }

  // Also append to student's recent activities
  if (dbState.students[studentId]) {
    if (!dbState.students[studentId].recentActivities) {
      dbState.students[studentId].recentActivities = [];
    }
    dbState.students[studentId].recentActivities.unshift(logEntry);
    if (dbState.students[studentId].recentActivities.length > 20) {
      dbState.students[studentId].recentActivities.pop();
    }
  }

  saveDatabase();
  return logEntry;
}
