import { spawn } from 'child_process';

const server = spawn(process.execPath, ['server/index.js'], { stdio: 'pipe' });

async function runTests() {
  await new Promise(r => setTimeout(r, 2000));

  console.log('\n========================================');
  console.log('🧪 RUNNING SKILLBRIDGE AI TEST SUITE');
  console.log('========================================\n');

  try {
    // 1. Health API
    const hRes = await fetch('http://localhost:5000/api/health');
    const health = await hRes.json();
    console.log('✅ [1/8] Health Check:', health.platform, health.aiProvider);

    // 2. Student Profile & Readiness Score
    const rRes = await fetch('http://localhost:5000/api/student/readiness');
    const readiness = await rRes.json();
    console.log(`✅ [2/8] Student Readiness Index: ${readiness.readiness.overallScore}/100 (${readiness.readiness.tier})`);

    // 3. Agent 1: Skill Gap Detector
    const gRes = await fetch('http://localhost:5000/api/agents/skill-gap/analyze', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ studentId: 'std-alex-chen' })
    });
    const gap = await gRes.json();
    console.log(`✅ [3/8] Agent 1 (Skill Gap): Target = ${gap.report.targetCareer}, Match = ${gap.report.overallMatchPercentage}%, Missing = ${gap.report.summaryMetrics.missingCount}`);

    // 4. Agent 2: Personalized Learning Agent
    const lRes = await fetch('http://localhost:5000/api/agents/learning/roadmap', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ studentId: 'std-alex-chen' })
    });
    const roadmap = await lRes.json();
    console.log(`✅ [4/8] Agent 2 (Learning Agent): Curated ${roadmap.roadmap.weeks.length}-week roadmap: "${roadmap.roadmap.title}"`);

    // 5. Agent 3: Skill Verification Agent
    const vRes = await fetch('http://localhost:5000/api/agents/verification/quiz?skillName=Python');
    const quiz = await vRes.json();
    console.log(`✅ [5/8] Agent 3 (Verification): Generated ${quiz.quiz.questions.length}-question diagnostic quiz for ${quiz.quiz.skillName} (${quiz.quiz.difficulty})`);

    // 6. Agent 4: Opportunity Finder Agent
    const oRes = await fetch('http://localhost:5000/api/agents/opportunities?isBeginnerFriendly=true');
    const opps = await oRes.json();
    console.log(`✅ [6/8] Agent 4 (Opportunity Finder): Discovered ${opps.totalCount} matching student listings. Top fit: "${opps.opportunities[0].title}" (${opps.opportunities[0].matchPercentage}% match)`);

    // 7. Agent 5: Scam Detection Agent
    const sRes = await fetch('http://localhost:5000/api/agents/scam/analyze', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        text: 'Urgent Remote Data Entry. Laptop provided upon ₹2,500 security deposit. Telegram contact only.',
        url: 'https://t.me/fake_recruiter'
      })
    });
    const scam = await sRes.json();
    console.log(`✅ [7/8] Agent 5 (Scam Detector): Flagged Category = ${scam.report.riskCategory}, Risk Score = ${scam.report.riskScore}/100, Red Flags = ${scam.report.detectedRedFlags.length}`);

    // 8. SkillBridge Assistant (Compound Orchestration)
    const cRes = await fetch('http://localhost:5000/api/agents/assistant/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        message: 'I want to become an AI Engineer, where should I start?'
      })
    });
    const chat = await cRes.json();
    console.log(`✅ [8/8] Central Assistant: Routed to "${chat.reply.routedAgent}". Response generated successfully.`);

    // 9. Static Frontend SPA Serving
    const fRes = await fetch('http://localhost:5000/');
    const html = await fRes.text();
    const hasRoot = html.includes('id="root"');
    console.log(`✅ [Frontend SPA]: Serving index.html on port 5000: ${hasRoot ? 'CONFIRMED' : 'FAILED'}`);

    console.log('\n========================================');
    console.log('🎉 ALL 8 TESTS PASSED WITH 100% SUCCESS!');
    console.log('========================================\n');
  } catch (err) {
    console.error('❌ Test failed:', err);
  } finally {
    server.kill();
    process.exit(0);
  }
}

runTests();
